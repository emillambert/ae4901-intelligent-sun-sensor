# AE4901 Intelligent Sun Sensor — V3 computational redesign

**Status:** Research-grade algorithm prototype; NOT a physically validated Sun sensor and NOT flight code. No measured GL5537-1 angular-response or real calibration has been incorporated.

## What is included

- `validate_v3.py`: matched 12-LDR simulations across **four synthetic sensor populations (seeds 701–704)**, each with **1,100 held-out Sun directions**. Same electrical noise draw and input counts are used by the estimators within each scenario. Includes angle-dependent face self-shadowing and the selected ±10° rotations about the [1,1,1] body diagonal.
- `engineering_study.py`: imported V2 baseline synthetic instrument and lookup estimator. Preserved for reproducibility.
- `ablation.py`, `ablation_results.csv`: isolates angular least-squares refinement from per-frame common-background compensation on four synthetic sensor populations and 750 held-out directions per population.
- `comparison_summary.csv`: **median of four per-seed** statistics (not pooled p95). `per_seed_results.csv`: inspect every trial population.
- `v3_host_engine.py`: two-board packet ingestion, lookup/least-squares estimation, ambient correction, conservative sensor-isolation states, and board timeout handling. Requires a *real calibrated* JSON file. Its default JSON has placeholders and therefore outputs `valid_for_control=false`.
- `firmware/`: Arduino acquisition starter and placeholder calibration template (copied from V2, NOT compiled or bench-tested); the more sophisticated estimator lives on the PC, not on an Uno.
- `electronics/`: V2 mathematical divider table and unexecuted SPICE netlist. Values are *not* a KiCad-verified schematic.
- `test_v3.py`: numerical + host smoke tests.
- `normal_and_ambient_comparison.png`, `safe_accuracy_and_availability.png`: summary figures.

## Headline results (median per-seed p95 degrees)

| Scenario | V2 calibrated + auto ADC | V3 full estimate | V4 accepted-only estimate | V4 acceptance |
|---|---:|---:|---:|---:|
| Normal, 80 lux | 2.129° | 1.763° | 1.728° | 99.1% |
| Dim, 20 lux | 2.411° | 2.330° | 2.293° | 99.5% |
| Bright, 300 lux | 2.506° | 2.162° | 2.137° | 99.0% |
| Uniform additional background, +4 lux | 4.988° | 2.043° | 1.842° | 97.6% |
| Uneven additional background, 1–7 lux | 6.488° | 4.557° | 4.084° | 67.9% |
| Assumed change in angular response | 4.793° | 4.706° | 4.537° | 97.0% |
| One LDR +40% corruption | 18.079° | 16.746° | 2.155° | 54.6% |
| Coherent second light, 30% | 22.565° | 20.054° | 14.483° | 22.7% |
| Arduino A offline | 3.977° | 3.803° | – | One board still estimating |
| Arduino B offline | 3.424° | 3.321° | – | One board still estimating |

**Interpretation caution:** Acceptance means the algorithm's *synthetic* quality gate accepted a result, not a guarantee that result is correct. In the 30% secondary-light scenario, **17.1% of all directions were accepted despite >5° angular error**, and only **4.6% of all directions** were both accepted and within 5°. Such coherent interference cannot be considered resolved.

## What changed

1. **Individual sensor calibration:** Already implemented as part of V2. V3 retains independent electrical gamma, 10-lux resistance, optical exponent, and offset parameters. Calibration parameters are hypothetical approximations to synthetic truth, not measured. Relative to uncalibrated B0, B2 already reduced normal p95 from ~10.2° to ~2.13°.
2. **ADC measurement range:** V2 already selected 5-V or nominal internal 1.1-V ADC references. This helps extrapolated very-bright cases but made nearly no difference at 20–300 lux. Keep it optional until the actual resistor kit and MCU are checked. Internal reference value, AVcc, sample-and-hold settling and 30k||R_LDR source impedance must be validated.
3. **Vector refinement:** V3 adds iterative spherical least-squares fitting with nuisance brightness, starting from the V2 pattern dictionary. Under synthetic normal illumination, it reduces p95 from ~2.13° to ~1.76°. This may create a small number of outliers, which is why error distribution and accepted-within-5° are both reported.
4. **Diffuse ambient handling:** V3 uses sensors on physically shaded faces to estimate and subtract a per-frame common additive light offset. *Ablation shows this only matters when there is an ambient shift*: normal-light performance barely changes; +4 lux common offset p95 reduces ~4.94° to ~1.99°; uneven background improves less (6.36° to 4.46°). It can bias estimates when shaded-face sensors see reflected directional illumination.
5. **Single-sensor failure:** V4 tries twelve leave-one-out hypotheses, retains the strongest only if the other eleven fit, and cross-checks controller-level residuals. `RECOVERED_ONE_SENSOR` and `TENTATIVE_SENSOR` are separate statuses; only the former is accepted by the conservative output. Across the four populations, about 54.6% of corrupted cases were accepted, 98% of high-confidence isolated sensor IDs matched the injected fault among accepted recoveries. Accepted p95 ~2.15°; **~45% rejected**. This is a validity/availability trade-off, not a universal accuracy gain.
6. **Controller failure:** With one whole board offline, the host uses the six-sensor surviving array. Mathematical output remains possible; real failover, independent power and communications are untested. The host itself is currently a single point of failure.
7. **Two-source illumination:** Coherent second-source error is generally NOT solvable from intensity readings alone. A one-source residual gate can often flag it but misses dangerous ambiguous cases. It does not reliably recover the true Sun direction. Optical masks were already worse in prior full-sphere synthetic sweeps.

## Critical assumptions

- GL5537-1 response outside **10–100 lux** in the power-law formula is an extrapolation; bright-light results are not reliable hardware predictions.
- Angular response is approximated by a per-sensor cosine raised to a hypothetical exponent. The real device may exhibit scattering, lens/package effects, temperature/hysteresis, source-spectrum dependence, near-field lamp geometry and ADC nonidealities not covered.
- The 1.1V reference is modeled as individually calibrated, with 0.65 ADC-count synthetic noise. It is not a magic increase in ADC dynamic range. Physical settling is not simulated.
- Thresholds .095, .08 and 1.5 are unqualified preliminary decision gates. Their false-alarm/false-isolation rates can change dramatically on real hardware. No genuinely empirical confidence interval exists.
- The sim assumes each controller's data reach the host. A failed common supply or host makes both estimates unavailable.

## Reproduce

With Python >=3.10, NumPy, SciPy, Pandas, Matplotlib:

```bash
python test_v3.py
python validate_v3.py
python ablation.py
python create_figures.py
python v3_host_engine.py --demo
```

The default `firmware/calibration_TEMPLATE.json` includes **placeholder values only** and `real_calibration_verified=false`. Never treat live outputs as calibrated until independently verified.

## Decision

Keep six faces, 12 bare GL5537-1 LDRs, dual Arduino readout, and small ±10° rotated six-sensor geometries. Prioritize real calibration and a physical controlled-light experiment next. Retain V3 angular refinement and common-background correction as **algorithm candidates**; retain the conservative V4 status distinctions. Do not claim the secondary-light problem is solved, and do not buy extra automatic-range hardware solely on this simulation.

## Independent external grounding

- TU Delft AE4901 practical manual (11 Nov 2026), assignment 3, section 4.4.
- Manufacturer GL5537-1 specification: https://www.nysenba.com/cds/5mm.html
- ATmega328P ADC reference and settling: https://docs.arduino.cc/resources/datasheets/Atmel-42735-8-bit-AVR-Microcontroller-ATmega328-328P_Datasheet.pdf
- ATmega ADC source impedance: https://docs.arduino.cc/resources/datasheets/ATmega328P-datasheet.pdf
