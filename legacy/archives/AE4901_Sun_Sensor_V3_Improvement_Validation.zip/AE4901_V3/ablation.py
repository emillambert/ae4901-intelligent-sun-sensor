#!/usr/bin/env python3
"""Separate benefit of background-compensation from angular refinement.
All variants operate on identical ADC counts and deterministic held-out vectors.
"""
import numpy as np,pandas as pd
from validate_v3 import Model,Estimator,sphere,acquire,angular,stats,P
rows=[]
s=sphere(750,.437)
for seed in [701,702,703,704]:
 m=Model(seed);e=Estimator(m)
 for name,args in [('Normal',{'lux':80}),('Dim',{'lux':20}),('Bright',{'lux':300}),
                   ('Uniform +4 lux',{'lux':80,'ambient_shift':4}),
                   ('Uneven +1..7 lux',{'lux':80,'transient_bg':np.linspace(1,7,12)})]:
  d=acquire(m,s,np.random.default_rng(91000+seed),**args)[1]
  for method in ['B2','V3 no adaptive background','V3 adaptive background']:
   if method=='B2':pred,_,ok,_,_,_=e.estimate(*d,'B2')
   else:pred,_,ok,_,_,_=e.estimate(*d,'V3',common_bg=(method=='V3 adaptive background'))
   rows.append(dict(seed=seed,scenario=name,method=method,**stats(angular(pred,s),ok)))
D=pd.DataFrame(rows)
D.to_csv(P/'ablation_results.csv',index=False)
print(D.groupby(['scenario','method'],sort=False)[['p95_deg','success_le5_pct']].median().to_string())
