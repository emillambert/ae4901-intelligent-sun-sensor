#!/usr/bin/env python3
"""Host-side AE4901 v3 estimator using a supplied calibration JSON.

This is host-side reference implementation (Python + scipy), not an AVR-portable
algorithm or a qualified instrument. No physical outputs are trustworthy until
sensor calibration values have been measured, installed and verified.

Usage:
    python v3_host_engine.py --demo
    python v3_host_engine.py --port-a /dev/cu.usbmodemA --port-b /dev/cu.usbmodemB --config path.json
"""
from pathlib import Path
import argparse,json,sys,time
import numpy as np
from validate_v3 import Estimator,BOARD
HERE=Path(__file__).resolve().parent
def parse(line):
    fields=line.strip().split(',')
    if len(fields)!=16 or fields[0]!='SUN2':return None
    try:
        board=int(fields[1]);seq=int(fields[2]);tm=int(fields[3])
        adc=np.asarray([int(v) for v in fields[4:10]],float)
        if board not in (0,1) or adc.min()<0 or adc.max()>1023:return None
        return {'id':board,'seq':seq,'time_ms':tm,'adc':adc,
            'lowmask':int(fields[10]),'rail':int(fields[11]),
            'receive':time.monotonic()}
    except ValueError:return None

class ConfigModel:
    def __init__(self,c):
        self.est_r10=np.array([x['resistance_at_10lux_ohms'] for x in c['sensors']],float)
        self.est_gamma=np.array([x['electrical_gamma'] for x in c['sensors']],float)
        self.est_p=np.array([x['angular_exponent'] for x in c['sensors']],float)
        self.est_bg=np.array([x['ambient_offset_lux'] for x in c['sensors']],float)
        self.rfixed=np.array([x['fixed_resistor_ohms'] for x in c['sensors']],float)
        self.est_vcc=np.array([c['controller'][i%2]['avcc_volts'] for i in range(12)],float)
        self.est_aref=np.array([c['controller'][i%2]['internal_ref_volts'] for i in range(12)],float)
        self.vcc=self.est_vcc.copy()
        assert len(c['sensors'])==12
        assert np.all(self.est_r10>0) and np.all(self.est_gamma>0)

class LiveSunEstimator:
    def __init__(self,c,ngrid=26000):
        self.config=c;self.model=ConfigModel(c)
        self.est=Estimator(self.model,ngrid)
        self.last={}
    def ingest(self,p):
        if p is not None:self.last[p['id']]=p
    def compute(self, now=None):
        if now is None:now=time.monotonic()
        online=[b for b in (0,1) if b in self.last and now-self.last[b]['receive']<self.config.get('timeout_seconds',1.2)]
        if not online:return {'state':'NO_DATA','valid_for_control':False}
        code=np.full((1,12),np.nan)
        refs=np.broadcast_to(self.model.est_vcc,(1,12)).copy()
        for b in online:
            pack=self.last[b]
            for f in range(6):
                j=2*f+b
                if pack['rail']&(1<<f):continue
                code[0,j]=pack['adc'][f]
                if pack['lowmask']&(1<<f):refs[0,j]=self.model.est_aref[j]
        if len(online)==2:
            vec,dist,state,failed=self.est.diagnose_and_recover(code,refs)
            status=str(state[0]);bad_sensor=int(failed[0]) if failed[0]>=0 else None
        else:
            lost=1-online[0]
            vec,dist,valid,_,_,_=self.est.estimate(code,refs,'V3',boardlost=lost)
            status='DEGRADED_CONTROLLER' if valid[0] else 'INSUFFICIENT'
            bad_sensor=None
        safe_state=status in ('NORMAL','RECOVERED_ONE_SENSOR','DEGRADED_CONTROLLER')
        return {'state':status,'vector':vec[0].tolist() if np.all(np.isfinite(vec[0])) else None,
                'residual':float(dist[0]),'isolated_sensor_index':bad_sensor,
                'real_calibration_verified':bool(self.config.get('real_calibration_verified',False)),
                'valid_for_control':bool(safe_state and self.config.get('real_calibration_verified',False)),
                'warning':'Quality thresholds, power-rail independence and optical model are not physically validated'}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--demo',action='store_true');ap.add_argument('--port-a');ap.add_argument('--port-b')
    ap.add_argument('--config',default=str(HERE/'firmware'/'calibration_TEMPLATE.json'))
    args=ap.parse_args()
    c=json.loads(Path(args.config).read_text());host=LiveSunEstimator(c)
    if args.demo:
        # Synthetic packets to exercise both-board and one-board integration.
        from engineering_study import Model
        true=Model(701);s=np.array([[.62,-.21,.76]]);s/=np.linalg.norm(s,axis=1)[:,None]
        counts,ref=true.read(s,np.random.default_rng(17),80,adc_mode='auto')
        for b in (0,1):
            idx=np.where(BOARD==b)[0]
            lowmask=sum((1<<f) for f,i in enumerate(idx) if ref[0,i]<2.)
            host.ingest(dict(id=b,seq=1,time_ms=1000,adc=counts[0,idx],lowmask=lowmask,
                rail=0,receive=time.monotonic()))
        print('Two boards, placeholder calibration:',json.dumps(host.compute()))
        host.last[0]['receive']-=10
        print('After board A timeout:',json.dumps(host.compute()))
        return
    if not (args.port_a or args.port_b):ap.error('Provide --demo or at least one serial port')
    try:import serial
    except ImportError:sys.exit('Install pyserial for USB serial acquisition')
    ports={b:serial.Serial(path,115200,timeout=.05) for b,path in [(0,args.port_a),(1,args.port_b)] if path}
    try:
        while True:
            for b,ser in ports.items():
                p=parse(ser.readline().decode(errors='replace'))
                if p is not None and p['id']==b:host.ingest(p)
            print(json.dumps(host.compute()))
            time.sleep(.2)
    finally:
        for p in ports.values():p.close()

if __name__=='__main__':main()
