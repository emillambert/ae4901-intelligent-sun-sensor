/* AE4901 V2 acquisition prototype -- UNO R3 or Mega2560 only.
 * Uncompiled and untested on physical hardware. Set BOARD_ID to 0 on Arduino A
 * and 1 on Arduino B. Supports 6 analog inputs per board (one per CubeSat face).
 * +5V -> fixed resistor -> A0..A5 -> GL5537-1 -> GND.
 * IMPORTANT: DO NOT drive AREF externally when switching internal references.
 * Placeholder calibration values below MUST be replaced with sensor results.
 */
#include <Arduino.h>
#ifdef __AVR__
#include <avr/wdt.h>
#endif
#if defined(__AVR_ATmega2560__)
const uint8_t ADC_LOW_REF = INTERNAL1V1;
#elif defined(__AVR_ATmega328P__)
const uint8_t ADC_LOW_REF = INTERNAL;
#else
#error "This ADC reference switching code needs a port for your board."
#endif
#define BOARD_ID 0
const uint8_t PIN[6] = {A0,A1,A2,A3,A4,A5}; // faces +X,-X,+Y,-Y,+Z,-Z
const float FIXED_OHMS[6]={30000,30000,30000,30000,30000,30000}; // replace as supplied
const float R_AT_10_LUX[6]={25000,25000,25000,25000,25000,25000}; // placeholders
const float GAMMA[6]={0.60,0.60,0.60,0.60,0.60,0.60}; // placeholders
const float BACKGROUND_LUX[6]={0,0,0,0,0,0}; // placeholders
const float AVCC_ACTUAL_VOLTS=5.000; // measure/calibrate, especially for internal ref
const float INTERNAL_REF_ACTUAL_VOLTS=1.100; // must calibrate actual reference
const unsigned long PERIOD_MS=200; // 5 Hz, conservative reference-switch settling
unsigned long prev=0;
unsigned long seq=0;

uint16_t readMedian3(uint8_t pin) {
  (void)analogRead(pin);  // discard after MUX/ref changes
  uint16_t x=analogRead(pin),y=analogRead(pin),z=analogRead(pin);
  if(x>y){uint16_t t=x;x=y;y=t;}
  if(y>z){uint16_t t=y;y=z;z=t;}
  if(x>y){uint16_t t=x;x=y;y=t;}
  return y;
}
struct Sample {uint16_t counts;bool lowRef;bool nearRail;float lux;};
Sample sample(uint8_t i) {
  // First measure ratiometrically with AVcc; no reference calibration is needed
  // for the ratio when the voltage-divider supply is the same AVcc.
  analogReference(DEFAULT);
  delay(3);
  const uint16_t primary=readMedian3(PIN[i]);
  const float voltage=AVCC_ACTUAL_VOLTS*primary/1023.0f;
  bool low=(voltage<0.90f); // safety margin below nominal 1.1V reference
  uint16_t count=primary;
  if(low) {
    analogReference(ADC_LOW_REF);
    delay(3);
    count=readMedian3(PIN[i]);
  }
  float ref=low?INTERNAL_REF_ACTUAL_VOLTS:AVCC_ACTUAL_VOLTS;
  const bool clipped=(count<2 || count>1021);
  const float adcVolts=ref*float(constrain(count,1,1022))/1023.0f;
  const float rLdr=FIXED_OHMS[i]*adcVolts/max(1e-5f,AVCC_ACTUAL_VOLTS-adcVolts);
  float flux=10.0f*powf(rLdr/R_AT_10_LUX[i],-1.0f/GAMMA[i]);
  flux=max(0.f,flux-BACKGROUND_LUX[i]);
  return {count,low,clipped,flux};
}
void rotateBody(float v[3]) {
  const float k=0.57735026919f;
  const float cs=0.98480775301f;
  const float sn=(BOARD_ID==0? 0.17364817767f:-0.17364817767f);
  const float d=k*(v[0]+v[1]+v[2]);
  const float c[3]={k*(v[2]-v[1]),k*(v[0]-v[2]),k*(v[1]-v[0])};
  for(int j=0;j<3;j++)v[j]=cs*v[j]+sn*c[j]+k*d*(1-cs);
}
void setup(){
  Serial.begin(115200);
  analogReference(DEFAULT);
  for(int i=0;i<6;i++)pinMode(PIN[i],INPUT);
#ifdef __AVR__
  wdt_enable(WDTO_2S);
#endif
}
void loop(){
#ifdef __AVR__
  wdt_reset();
#endif
  const unsigned long now=millis();
  if(now-prev<PERIOD_MS)return;
  prev=now;
  Sample sm[6]; uint8_t lowmask=0,railmask=0;
  for(int j=0;j<6;j++){
    sm[j]=sample(j);
    if(sm[j].lowRef)lowmask|=1<<j;
    if(sm[j].nearRail)railmask|=1<<j;
  }
  float v[3]={sm[0].lux-sm[1].lux,sm[2].lux-sm[3].lux,sm[4].lux-sm[5].lux};
  const float n=sqrtf(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
  bool valid=n>2.f;
  if(valid){for(int j=0;j<3;j++)v[j]/=n;rotateBody(v);}
  else {v[0]=v[1]=v[2]=0;}
  // Format: SUN2,id,seq,time,6 ADC counts,low_ref_mask,rail_mask,x,y,z,valid
  Serial.print("SUN2,");Serial.print(BOARD_ID);Serial.print(',');Serial.print(seq++);
  Serial.print(',');Serial.print(now);
  for(int j=0;j<6;j++){Serial.print(',');Serial.print(sm[j].counts);}
  Serial.print(',');Serial.print(lowmask);Serial.print(',');Serial.print(railmask);
  for(int j=0;j<3;j++){Serial.print(',');Serial.print(v[j],5);}
  Serial.print(',');Serial.println(valid?1:0);
}
