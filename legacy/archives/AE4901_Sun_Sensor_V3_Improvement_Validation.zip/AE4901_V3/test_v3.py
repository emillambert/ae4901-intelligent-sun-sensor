"""Automated mathematics, quality-gate and host-integration smoke checks."""
import sys,time,json
from pathlib import Path
import numpy as np
from validate_v3 import Model,Estimator,acquire,recover,angular,sphere,N,PHYS,BOARD,local_refine
from v3_host_engine import LiveSunEstimator,parse
P=Path(__file__).resolve().parent

def test():
    assert np.allclose(N.T@N,4*np.eye(3),atol=1e-10)
    assert np.allclose(np.linalg.norm(N,axis=1),1.)
    m=Model(701);est=Estimator(m,n_grid=18000)
    dirs=sphere(800,.731)
    adc=acquire(m,dirs,np.random.default_rng(45),lux=80)[1]
    y,flags=recover(m,*adc)
    assert y.shape==(800,12) and not flags.any()
    naive,_,_,_,_,_=est.estimate(*adc,'B2')
    refined,_,v,_,_,_=est.estimate(*adc,'V3')
    assert np.isfinite(refined).all()
    assert np.max(np.abs(np.linalg.norm(refined,axis=1)-1))<1e-10
    assert np.quantile(angular(refined,dirs),.95)<2.8
    # A controlled uniform offset should be suppressed without access to truth.
    dif=acquire(m,dirs,np.random.default_rng(45),lux=80,ambient_shift=4)[1]
    a,_,_,_,_,_=est.estimate(*dif,'V3',common_bg=False)
    b,_,_,_,_,_=est.estimate(*dif,'V3',common_bg=True)
    assert np.quantile(angular(b,dirs),.95) < np.quantile(angular(a,dirs),.95)
    # Rejecting a coherent second source is allowed; asserting it is corrected is not.
    c=json.loads((P/'firmware'/'calibration_TEMPLATE.json').read_text())
    host=LiveSunEstimator(c,ngrid=10000)
    assert host.compute()['state']=='NO_DATA'
    assert parse('invalid packet') is None
    assert parse('SUN2,0,1,1000,100,200,300,400,500,600,0,0,0,0,1,1') is not None
    assert host.config['real_calibration_verified'] is False
    print('PASS: geometry, numeric recovery, unit vectors, ambient ablation, host parsing, placeholder safety guard')
if __name__=='__main__':test()
