from pathlib import Path
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
z=pd.read_csv(P/'comparison_summary.csv')
chosen=['Normal 80 lux','Dim 20 lux','Bright 300 lux','Diffuse ambient +4 lux','Uneven ambient 1-7 lux','Angular-response change (assumed)']
labels=['Normal','Dim','Bright','Uniform ambient','Uneven ambient','Optical drift']
def val(s,m,k):return float(z[(z.scenario==s)&(z.method==m)][k].iloc[0])
x=np.arange(len(chosen));w=.35
fig,ax=plt.subplots(figsize=(10,5),layout='constrained')
a=[val(s,'B2','p95_deg') for s in chosen];b=[val(s,'V3','p95_deg') for s in chosen]
ax.bar(x-w/2,a,w,label='V2 calibrated + auto ADC')
ax.bar(x+w/2,b,w,label='V3 refined + ambient correction')
ax.set_ylabel('95th-percentile angular error (degrees)')
ax.set_title('Matched synthetic comparison: 4 sensor populations × 1,100 directions each')
ax.set_xticks(x,labels,rotation=20,ha='right');ax.grid(axis='y',alpha=.2);ax.legend()
fig.savefig(P/'normal_and_ambient_comparison.png',dpi=180);plt.close(fig)
chosen=['One LDR +40% corruption','Coherent second light +30%','Bright 10000 lux (extrapolated)']
labels=['One faulty LDR','Second source +30%','Very bright (extrap.)']
fig,ax=plt.subplots(figsize=(8,5),layout='constrained')
x=np.arange(3);width=.35
b=[val(s,'B2','success_le5_pct') for s in chosen];v=[val(s,'V4 trusted only','success_le5_pct') for s in chosen]
ax.bar(x-width/2,b,width,label='V2: always reports estimate')
ax.bar(x+width/2,v,width,label='V4: confidence-gated estimate')
for i,(bb,vv) in enumerate(zip(b,v)):
 ax.text(i-width/2,bb+1,f'{bb:.0f}%',ha='center',fontsize=9)
 ax.text(i+width/2,vv+1,f'{vv:.0f}%',ha='center',fontsize=9)
ax.set_xticks(x,labels);ax.set_ylim(0,105);ax.set_ylabel('All test directions: accepted AND ≤5° accuracy (%)')
ax.set_title('A lower error among accepted estimates may hide rejected directions')
ax.grid(axis='y',alpha=.2);ax.legend(loc='upper center',fontsize=9)
fig.savefig(P/'safe_accuracy_and_availability.png',dpi=180);plt.close(fig)
print('Figures written')
