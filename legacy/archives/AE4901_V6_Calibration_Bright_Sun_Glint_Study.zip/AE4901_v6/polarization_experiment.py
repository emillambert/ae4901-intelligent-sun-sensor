#!/usr/bin/env python3
"""OPTIONAL conceptual polarimetric discriminant using opposite filters on each pair.
Polarized glint is a hypothesis; not a validated GL5537 technique. No polarizer
has been measured or furnished; model ignores polarizer angular/spectral effects.
Unpolarized direct Sun is normalized to a common post-filter gain. This test is
NOT a recommendation to install polarizers without physical characterization.
"""
from pathlib import Path
import sys
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from run_v6 import Model,Estimator,scenarios,earth_disk_albedo,resp,LUX,BOARD,flux_to_r,divider_voltage,compute_diagnostics,v5_gate,metrics,angular

def observe(m,c,seed,degree=.0,glint_frac=.25):
    rng=np.random.default_rng(seed)
    sun,nadir,direct=c['sun'],c['nadir'],c['direct']
    alb,_=earth_disk_albedo(sun,nadir,c['cloud_seed'],c['label'],npatch=80)
    E=LUX*direct[:,None]*resp(sun,exponent=m.p)+LUX*alb+m.ambient[None,:]
    direction=.3*sun+.95*nadir;direction/=np.linalg.norm(direction,axis=1)[:,None]
    # Six independent face planes; linear polarization basis depends on incidence.
    # Randomly oriented effective polarization relative to each polarizer pair.
    phi=rng.uniform(0,np.pi,6)
    sign=np.where(BOARD==0,1.,-1.)
    factor=1+degree*sign*np.repeat(np.cos(2*phi),2)
    E+=LUX*glint_frac*resp(direction,exponent=m.p)*factor[None,:]
    E=np.maximum(E,.01)*(1+rng.normal(0,.008,E.shape))
    R=flux_to_r(E,m.r10,m.gamma); V=divider_voltage(R,m.rfixed,m.vcc)
    refs=np.where(V<.98,m.aref[None,:],m.vcc[None,:])
    code=np.clip(np.rint(1023*V/refs+rng.normal(0,.65,V.shape)),0,1023)
    return code,refs

if __name__=='__main__':
    rows=[]
    for seed in (1601,1602,1603,1604):
        m=Model(seed);est=Estimator(m,n_grid=4300)
        cases=[c for c in scenarios(10000+seed,6,24) if c['label']=='specular_glint']
        for i,c in enumerate(cases):
            for degree in (0,.3,.7,.9):
                codes,refs=observe(m,c,seed*1000+i,degree)
                dg=compute_diagnostics(m,est,codes,refs)
                valid=v5_gate(dg)
                s=dg['sun'].copy();resc=(dg['recovered_states']=='ISOLATED_PROVISIONAL')&valid
                s[resc]=dg['recovered_sun'][resc]
                rows.append(dict(seed=seed,case=i,polarization_degree=degree,**metrics(s,c['sun'],c['direct'],valid)))
        print('polarization seed',seed,flush=True)
    f=pd.DataFrame(rows);f.to_csv(HERE/'polarization_stress.csv',index=False)
    print(f.groupby('polarization_degree').agg(n=('case','size'),good5=('day_good5_pct','mean'),wrong5=('day_wrong5_pct','mean'),accept=('day_accept_pct','mean')).round(2).to_string())
