#!/usr/bin/env python3
"""V6 reference quality rules for a 12-LDR CubeSat coarse Sun sensor.

Never claim a coherent glint is uniquely identified from 12 scalar light values.
Strict absolute-brightness rejection is disabled unless a solar photometric
reference and the installed attenuator are verified. No flight certification.
"""
from dataclasses import dataclass
from typing import Optional
from math import isfinite

@dataclass(frozen=True)
class Decision:
    state:str
    display_vector:bool
    control_eligible:bool
    warnings:tuple[str,...]

@dataclass(frozen=True)
class Input:
    v5_valid:bool
    fitted_primary_illuminance:float
    reported_controller_error_deg:Optional[float]=None
    optical_calibration_verified:bool=False
    solar_reference_illuminance:Optional[float]=None
    max_calibrated_flux_mismatch_fraction:float=.08
    live_controller_count:int=2


def review(x:Input, strict_glint_rejection:bool=False)->Decision:
    """Only amplitude plausibility; V5's eclipse, cross-face, and fault checks
    operate upstream. Returned warning is NOT proof that a glint occurred.

    Sun brightness and gain must be independently bounded before a strict gate
    can be used. If reference is missing, the system must not silently infer it.
    """
    warnings=[]
    if x.live_controller_count<2:warnings.append('Degraded: only one controller online')
    if not x.v5_valid:return Decision('NO_VALID_VECTOR',False,False,tuple(warnings))
    if not isfinite(x.fitted_primary_illuminance) or x.fitted_primary_illuminance<0:
        return Decision('INVALID_PHOTOMETRY',False,False,tuple(warnings))
    if not x.optical_calibration_verified or x.solar_reference_illuminance is None:
        warnings.append('No independently validated solar photometric reference; glint cannot be excluded')
        return Decision('UNVERIFIED',True,False,tuple(warnings))
    if not isfinite(x.solar_reference_illuminance) or x.solar_reference_illuminance<=0:
        return Decision('INVALID_REFERENCE',False,False,tuple(warnings))
    if not (0.01<=x.max_calibrated_flux_mismatch_fraction<=.50):
        return Decision('INVALID_TOLERANCE',False,False,tuple(warnings))
    ratio=x.fitted_primary_illuminance/x.solar_reference_illuminance
    excessive=ratio>1+x.max_calibrated_flux_mismatch_fraction
    if excessive:
        warnings.append(f'Unexpectedly high source amplitude ({ratio:.3f}x reference); possible glint or calibration drift')
        if strict_glint_rejection:
            return Decision('EXCESS_LIGHT_SUSPECT',False,False,tuple(warnings))
        return Decision('EXCESS_LIGHT_WARNING',True,False,tuple(warnings))
    # Passing this test does NOT imply no glint. System-level ADCS use would
    # require other qualification tests, so no automatic control authorization.
    return Decision('PHOTOMETRICALLY_PLAUSIBLE',True,False,tuple(warnings))

if __name__=='__main__':
    for amp in (80.,87.,90.):
        print(amp,review(Input(True,amp,optical_calibration_verified=True,solar_reference_illuminance=80.),True))
