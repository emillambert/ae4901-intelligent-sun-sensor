#!/usr/bin/env python3
"""Per-channel film-transmission and angular-response uncertainties.
Film transmittances ~0.001 with independent Gaussian 5% relative differences;
angle exponent shifted by per-channel ~0.10 SD. These are hypotheses.
Offline correction uses a known Sun direction and calibrated illuminance.
"""
import sys
from pathlib import Path
import numpy as np,pandas as pd
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H))
from run_v6 import Model,Estimator,resp,flux_to_r,divider_voltage,sphere,N,PHYS,estimate_new,angular,recover

def readings(m,s,solar,filter_trans,exp,seed):
    rng=np.random.default_rng(seed)
    flux=solar*filter_trans[None,:]*resp(s,exponent=exp)+m.ambient[None,:]
    R=flux_to_r(flux,m.r10,m.gamma);V=divider_voltage(R,m.rfixed,m.vcc)
    refs=np.where(V<.98,m.aref[None,:],m.vcc[None,:])
    c=np.clip(np.rint(1023*V/refs+rng.normal(0,.65,V.shape)),0,1023)
    return c,refs

def fit_filters(m,dirs,codes,refs,nominal_after_filter=80.):
    flux,clip=recover(m,codes,refs,cal=True,keep_negative=True)
    dots=dirs@N.T;faces=(dirs@PHYS.T)>0
    p=m.est_p.copy();gain=np.ones(12)
    for j in range(12):
        v=(dots[:,j]>.16)&(dots[:,j]<.94)&faces[:,j]&(~clip[:,j])&(flux[:,j]>3)
        if v.sum()<20:continue
        x=np.log(dots[v,j]); y=np.log(flux[v,j]/nominal_after_filter)
        X=np.column_stack((np.ones(len(x)),x))
        beta=np.linalg.lstsq(X,y,rcond=None)[0]
        for _ in range(5):
            e=y-X@beta;sig=max(.02,1.4826*np.median(np.abs(e-np.median(e))))
            w=np.minimum(1.,1.5*sig/np.maximum(np.abs(e),1e-7))
            beta=np.linalg.lstsq(X*np.sqrt(w)[:,None],y*np.sqrt(w),rcond=None)[0]
        gain[j]=np.clip(np.exp(beta[0]),.7,1.3)
        p[j]=np.clip(beta[1],.6,1.9)
    return p,gain

if __name__=='__main__':
    rows=[]
    for seed in (1701,1702,1703,1704):
        m=Model(seed); rng=np.random.default_rng(seed)
        trans=.001*np.clip(1+rng.normal(0,.05,12),.7,1.3)
        optical_p=np.clip(m.p+rng.normal(0,.1,12),.6,1.9)
        train=sphere(850,.158); test=sphere(650,.843)
        tr,ref=readings(m,train,80000.,trans,optical_p,seed*13)
        te,te_ref=readings(m,test,80000.,trans,optical_p,seed*13+1)
        fit_p,fit_g=fit_filters(m,train,tr,ref)
        original=m.est_p.copy();orig_r10=m.est_r10.copy();orig_bg=m.est_bg.copy()
        for meth in ('assume_nominal_film','known_angle_calibrated_film'):
            if meth=='known_angle_calibrated_film':
                m.est_p=fit_p
                m.est_r10=orig_r10*fit_g**(-m.est_gamma)
                m.est_bg=orig_bg/fit_g
            else:
                m.est_p=original;m.est_r10=orig_r10;m.est_bg=orig_bg
            est=Estimator(m,n_grid=4800)
            z=estimate_new(m,est,te,te_ref,mode='common',robust=True)
            a=angular(z['s'],test)
            rows.append(dict(seed=seed,method=meth,p95=np.percentile(a,95),within5=100*np.mean(a<=5),med=np.median(a),
                             p_mae=np.mean(np.abs(m.est_p-optical_p))))
        print('filter sensitivity seed',seed,flush=True)
    f=pd.DataFrame(rows); f.to_csv(H/'nd_filter_calibration_sensitivity.csv',index=False)
    print(f.groupby('method').agg(p95=('p95','mean'),within5=('within5','mean'),p_mae=('p_mae','mean')).round(2))
