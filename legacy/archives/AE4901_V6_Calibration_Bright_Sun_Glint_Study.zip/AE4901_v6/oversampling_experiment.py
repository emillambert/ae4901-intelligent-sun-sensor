#!/usr/bin/env python3
"""Oversampling experiment: identical idealized LDR response, fixed 30k, 1.1V ref.
Assumes independent 0.65-ADC-count read noise. Not a measured ADC noise model.
"""
from pathlib import Path
import sys
import numpy as np, pandas as pd
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from run_v6 import Model,Estimator,sphere,resp,flux_to_r,divider_voltage,estimate_new,angular

def evaluate(seed,solar=80000., K=1, nd=1.0, rf=30000., n=350):
    m=Model(seed);m.rfixed[:]=rf;m.est_ref_rfixed[:]=rf
    est=Estimator(m,n_grid=4100)
    s=sphere(n,.713)
    E=solar*nd*resp(s,exponent=m.p)+m.ambient[None,:]
    R=flux_to_r(E,m.r10,m.gamma)
    V=divider_voltage(R,m.rfixed,m.vcc)
    refs=np.where(V<.98,m.aref[None,:],m.vcc[None,:])
    expected=1023*V/refs
    rng=np.random.default_rng(seed*100+K+int(nd*100))
    if K==1:
        codes=np.clip(np.rint(expected+rng.normal(0,.65,expected.shape)),0,1023)
    else:
        # physical independent conversions with dither then average as float;
        # do not claim extra resolution when correlated noise dominates.
        noise=rng.normal(0,.65,(K,*expected.shape))
        codes=np.mean(np.clip(np.rint(expected[None,:,:]+noise),0,1023),axis=0)
    e=estimate_new(m,est,codes,refs,mode='common',robust=True)
    a=angular(e['s'],s)
    return {'seed':seed,'illumination_lux_EXTRAPOLATED':solar,'K':K,'rfixed_ohm':rf,
            'transmittance':nd,'p95_deg':np.quantile(a,.95),'within5':100*np.mean(a<=5),
            'median_lit_adc':np.median(codes[(s@np.array([[1.,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]).T).max(axis=1)>.3])}

if __name__=='__main__':
    rows=[]
    for seed in (1501,1502,1503):
        for ill in (30000.,80000.,120000.):
            for k in (1,16,64,256):rows.append(evaluate(seed,ill,k))
            rows.append(evaluate(seed,ill,1,nd=.001))
            rows.append(evaluate(seed,ill,1,rf=1000.))
        print('seed',seed,flush=True)
    pd.DataFrame(rows).to_csv(HERE/'oversampling_vs_attenuator.csv',index=False)
    s=pd.DataFrame(rows).groupby(['illumination_lux_EXTRAPOLATED','K','rfixed_ohm','transmittance'],as_index=False).agg(p95_mean=('p95_deg','mean'),within5_mean=('within5','mean'))
    print(s.round(2).to_string(index=False))
