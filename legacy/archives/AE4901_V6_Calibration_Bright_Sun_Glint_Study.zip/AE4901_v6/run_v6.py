#!/usr/bin/env python3
"""V6 computational robustness attempts on original V5 physical/algorithmic surrogate.

No GL5537-1 samples or real flight data; amplitude and angular responses hypothetical.
DO NOT infer flight performance from synthetic populations. All new model and
algorithms use only ADC observations and assumed/calibrated signal strength,
unless a known lab Sun vector is explicitly supplied for recalibration.
"""
import sys, argparse, math
from pathlib import Path
import numpy as np, pandas as pd
HERE=Path(__file__).resolve().parent
V5=HERE/'reference_v5' if (HERE/'reference_v5').exists() else HERE.parent/'AE4901_v5'
sys.path.insert(0,str(V5));sys.path.insert(0,str(V5/'reference'))
from engineering_study import Model,N,PHYS,BOARD,sphere,angular,resp,flux_to_r,divider_voltage
from validate_v3 import Estimator,recover
from leo_gating_study import scenarios,acquire_environment,compute_diagnostics,decide,evaluate,EARTH_RADIUS_DEG,LUX,earth_disk_albedo
from compare_v4 import estimate_new

DEFAULTS={'brightness':.30,'resid':2.9,'boards_deg':14.,'step_deg':4.,'margin_deg':3.,'reacq':.35}

def v5_gate(diag):
    return decide(diag,('brightness','consistency','recover_fault'), DEFAULTS)

def amp_threshold(diag, limit=1.12, nominal=80.):
    return np.isfinite(diag['amp']) & (diag['amp'] <= nominal*limit)

def transition_warning(diag, high_flux_limit=1.07, jumps_deg=5.0, max_tumble_deg=3.5):
    """Warn only on abrupt changes combined with unexpectedly increased fitted flux.
    No Sun-direction truth used. Guard is disabled if observed angular change
    indicates sustained rapid motion, so fast tumble isn't automatically rejected.
    """
    s=diag['sun']; a=diag['amp']; n=len(a)
    flag=np.zeros(n,bool)
    for i in range(2,n):
        prev1=angular(s[i-1:i],s[i-2:i-1])[0]
        d=angular(s[i:i+1],s[i-1:i])[0]
        if prev1 < max_tumble_deg and d > max(jumps_deg,prev1*2.5) and a[i]>LUX*high_flux_limit:
            flag[i]=True
    return flag

def metrics(s, truth, direct, accept):
    err=angular(s,truth)
    day=direct.astype(bool)
    good=day & accept & (err<=5)
    wrong=day & accept & (err>5)
    vals=err[day & accept]
    return {'day_n':int(day.sum()),'day_accept_pct':100*accept[day].mean() if day.any() else float('nan'),
            'day_good5_pct':100*good.sum()/day.sum() if day.any() else float('nan'),
            'day_wrong5_pct':100*wrong.sum()/day.sum() if day.any() else float('nan'),
            'p95_accepted_deg':np.percentile(vals,95) if len(vals) else float('nan'),
            'p95_all_day_deg':np.percentile(err[day],95) if day.any() else float('nan'),
            'eclipse_false_pct':100*accept[~day].mean() if (~day).any() else float('nan')}

def evaluate_case(m,est,case,seed):
    codes,refs,rho=acquire_environment(m,case,seed)
    dg=compute_diagnostics(m,est,codes,refs)
    v5=v5_gate(dg)
    direction=np.array(dg['sun']).copy()
    rescue=(dg['recovered_states']=='ISOLATED_PROVISIONAL')&v5
    direction[rescue]=dg['recovered_sun'][rescue]
    candidates={
        'V5_existing':v5,
        'amp_1.08': v5 & amp_threshold(dg,1.08),
        'amp_1.12': v5 & amp_threshold(dg,1.12),
        'amp_1.18': v5 & amp_threshold(dg,1.18),
        'transient_warning':v5 & (~transition_warning(dg)),
        'amp112_and_transient':v5 & amp_threshold(dg,1.12) & (~transition_warning(dg))
    }
    return {k:metrics(direction,case['sun'],case['direct'],v) for k,v in candidates.items()}, dg

def run_gates(seeds, nseq, frames, outfile):
    labels=['sun_only','earth_typical','bright_clouds','specular_glint','eclipse_transition','angular_drift','fast_tumble','corrupt_channel']
    rows=[];signals=[]
    for seed in seeds:
        m=Model(seed); est=Estimator(m,n_grid=4300)
        cases=[c for c in scenarios(10000+seed,nseq,frames) if c['label'] in labels]
        for ix,case in enumerate(cases):
            comps,diag=evaluate_case(m,est,case,seed*10000+ix)
            for algo,score in comps.items():rows.append({'seed':seed,'scenario':case['label'],'case':case['case'],'method':algo,**score})
            signals.append({'seed':seed,'scenario':case['label'],'case':case['case'],
                            'amp_p50':float(np.median(diag['amp'])),
                            'amp_p95':float(np.quantile(diag['amp'],.95)),
                            'max_flux_p50':float(np.median(diag['max_flux']))})
        print('gating seed',seed,'complete',flush=True)
    pd.DataFrame(rows).to_csv(HERE/f'{outfile}_rows.csv',index=False)
    pd.DataFrame(signals).to_csv(HERE/f'{outfile}_signals.csv',index=False)
    summary=pd.DataFrame(rows).groupby(['scenario','method'],as_index=False).agg(n=('case','size'),
        good5=('day_good5_pct','mean'),wrong5=('day_wrong5_pct','mean'),accept=('day_accept_pct','mean'),
        p95_mean_case=('p95_accepted_deg','mean'),eclipse_false=('eclipse_false_pct','mean'))
    summary.to_csv(HERE/f'{outfile}_summary.csv',index=False)
    return summary

def acquire_custom(m,dirs,rng,lux=80,nd_transmit=1.0,p_override=None):
    n=len(dirs)
    p=m.p if p_override is None else p_override
    Ee=np.maximum(.01,lux*nd_transmit*resp(dirs,exponent=p)+m.ambient[None,:])
    Ee=Ee*np.clip(1+rng.normal(0,.008,Ee.shape),.9,1.1)
    R=flux_to_r(Ee,m.r10,m.gamma)
    V=divider_voltage(R,m.rfixed,m.vcc)
    references=np.where(V<.98,m.aref[None,:],m.vcc[None,:])
    codes=np.clip(np.rint(1023*V/references+rng.normal(0,.65,V.shape)),0,1023)
    return codes,references

def fit_angular_p_from_ground_reference(m, train_dirs, codes, refs, nominal_lux):
    """Offline *ground* calibration using known source direction and intensity.
    No validation truth passed to online reconstruction. Only fit angular exponents;
    electrical parameters remain imperfect. 20+ distinct known directions required.
    """
    E,clip=recover(m,codes,refs,cal=True,keep_negative=True)
    dots=train_dirs@N.T; face=(train_dirs@PHYS.T)>0
    pnew=m.est_p.copy(); trained=[]
    for j in range(12):
        good=face[:,j] & (dots[:,j]>.16) & (dots[:,j]<.94) & (~clip[:,j]) & (E[:,j]>3)
        if good.sum()<12:continue
        x=np.log(np.maximum(dots[good,j],1e-9))
        y=np.log(np.maximum(E[good,j],1e-9)/nominal_lux)
        # Robust slope through the origin assumes separately calibrated gain.
        # Optionally fit nuisance offset to handle gain mismatch.
        X=np.column_stack((np.ones(len(x)),x))
        w=np.ones(len(x))
        beta=np.linalg.lstsq(X,y,rcond=None)[0]
        for _ in range(5):
            e=y-X@beta;scale=max(.015,1.4826*np.median(np.abs(e-np.median(e))))
            w=np.minimum(1,1.5*scale/np.maximum(np.abs(e),1e-7))
            beta=np.linalg.lstsq(X*np.sqrt(w)[:,None],y*np.sqrt(w),rcond=None)[0]
        pnew[j]=np.clip(beta[1],.6,1.85)
        trained.append(j)
    return pnew, trained

def run_drift(seeds=(1001,1002,1003,1004),ngrid=4500):
    rows=[]
    for seed in seeds:
        m=Model(seed)
        true_p=np.clip(m.p + .20*np.sin(np.arange(12)+.31),.6,1.85)
        train=sphere(800,.245); test=sphere(600,.812)
        codes,refs=acquire_custom(m,train,np.random.default_rng(seed*10),p_override=true_p)
        pfit,trained=fit_angular_p_from_ground_reference(m,train,codes,refs,80)
        tcode,tref=acquire_custom(m,test,np.random.default_rng(seed*10+1),p_override=true_p)
        for label,px in [('stale_calibration',m.est_p.copy()),('known_angle_ground_recalibration',pfit)]:
            m.est_p=px
            est=Estimator(m,n_grid=ngrid)
            e=estimate_new(m,est,tcode,tref,mode='common',robust=True)
            a=angular(e['s'],test)
            rows.append({'seed':seed,'method':label,'p95_deg':np.quantile(a,.95),'median_deg':np.median(a),
                         'within5_pct':100*np.mean(a<=5),'trained_sensors':len(trained),
                         'p_mae':np.mean(np.abs(px-true_p))})
        print('drift seed',seed,'complete',flush=True)
    f=pd.DataFrame(rows);f.to_csv(HERE/'drift_recalibration.csv',index=False)
    return f

def run_solar_range(seeds=(1101,1102,1103),ngrid=4100):
    rows=[]; test=sphere(350,.123)
    for seed in seeds:
        m=Model(seed);est=Estimator(m,n_grid=ngrid)
        for solar in [30000.,80000.,120000.]:
            for trans,name in [(1.,'bare_supplied_30k'),(.003,'ND_2.52'),(.001,'ND_3.00'),(.0003,'ND_3.52')]:
                code,ref=acquire_custom(m,test,np.random.default_rng(seed+int(solar)),lux=solar,nd_transmit=trans)
                _,clips=recover(m,code,ref,cal=True,keep_negative=True)
                # E in model after attenuator represents sensor lux, not real solar lux.
                e=estimate_new(m,est,code,ref,mode='common',robust=True)
                a=angular(e['s'],test)
                dots=np.maximum(0.,test@N.T);face=(test@PHYS.T)>0
                lit=(dots>.15)&face
                rows.append({'seed':seed,'solar_lux_ASSUMED':solar,'front_optics':name,'transmission':trans,
                             'incident_lux_peak':solar*trans,
                             'median_adc_on_lit':float(np.median(code[lit])),
                             'lit_adc_le_10_pct':100*np.mean(code[lit]<=10),
                             'all_channels_clipped_pct':100*np.mean(clips),
                             'p95_deg_SYNTHETIC':np.quantile(a,.95),'within5_pct_SYNTHETIC':100*np.mean(a<=5)})
        print('solar range seed',seed,'complete',flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(HERE/'solar_dynamic_range.csv',index=False)
    return frame

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--part',choices=['gates','drift','solar','all'],default='all');ap.add_argument('--dev',action='store_true');ap.add_argument('--glint-stress',action='store_true');a=ap.parse_args()
    if not a.glint_stress and a.part in ('gates','all'):
        seeds=(901,902,903) if a.dev else (1101,1102,1103,1104)
        x=run_gates(seeds,3 if a.dev else 4,24,'development' if a.dev else 'heldout')
        print(x[x.scenario.isin(['specular_glint','sun_only','angular_drift'])].to_string(index=False))
    if not a.glint_stress and a.part in ('drift','all'):print(run_drift().to_string(index=False))
    if not a.glint_stress and a.part in ('solar','all'):print(run_solar_range().to_string(index=False))

# Extended stress tests for the non-identifiability of strong glints: the
# detector must see both more realistic intermittent glints and changes to
# calibrated clear-Sun strength, which a strict amplitude gate can confuse.
def acquire_with_scale_and_glint(m,case,seed,solar_scale=1.,glint_scale=0.,pulse=False):
    rng=np.random.default_rng(seed)
    sun,nadir,direct=case['sun'],case['nadir'],case['direct']
    n=len(sun)
    alb,_=earth_disk_albedo(sun,nadir,case['cloud_seed'],case['label'],npatch=80)
    alb=alb*np.clip(1+.09*np.sin(np.arange(12)*1.8+.3),.65,1.35)[None,:]
    E=LUX*solar_scale*(direct[:,None]*resp(sun,exponent=m.p)+alb)+m.ambient[None,:]
    if glint_scale:
        light_dir=(.3*sun+.95*nadir)
        light_dir/=np.linalg.norm(light_dir,axis=1)[:,None]
        activity=np.ones(n)
        if pulse:
            activity[:]=0
            start=max(3,n//3)
            activity[start:start+max(3,n//5)]=1
        E+=LUX*solar_scale*glint_scale*activity[:,None]*resp(light_dir,exponent=m.p)
    E=np.maximum(E,.01)*(1+rng.normal(0,.008,E.shape))
    R=flux_to_r(E,m.r10,m.gamma)
    V=divider_voltage(R,m.rfixed,m.vcc)
    refs=np.where(V<.98,m.aref[None,:],m.vcc[None,:])
    codes=np.clip(np.rint(1023*V/refs+rng.normal(0,.65,V.shape)),0,1023)
    return codes,refs

def rolling_bright_flags(d,ratio=1.10,history=6):
    """Use historically calibrated brightness, not the true illumination.
    This is diagnostic only: if a glint is present at start, it becomes the reference.
    """
    aa=np.asarray(d['amp']);f=np.zeros(len(aa),bool)
    for i in range(history,len(aa)):
        finite=aa[max(0,i-history):i]
        finite=finite[np.isfinite(finite)]
        if len(finite)>=3:
            lower=np.quantile(finite,.2)
            if lower>10 and aa[i]>lower*ratio:f[i]=True
    return f

def run_glint_and_scale(seeds=(1301,1302,1303),nseq=4,frames=30):
    rows=[]
    for seed in seeds:
        m=Model(seed);est=Estimator(m,n_grid=4300)
        cases=[c for c in scenarios(10000+seed,nseq,frames) if c['label'] in ('sun_only','earth_typical','specular_glint')]
        for ix,c in enumerate(cases):
            settings=[]
            if c['label']=='sun_only':
                settings=[('direct_90pct',.90,0,False),('direct_100pct',1,0,False),
                          ('direct_106pct',1.06,0,False),('direct_112pct',1.12,0,False)]
            elif c['label']=='earth_typical': settings=[('earth_nominal',1,0,False)]
            else:settings=[('glint_25pct_continuous',1,.25,False),
                           ('glint_25pct_pulsed',1,.25,True),('glint_40pct_pulsed',1,.4,True)]
            for name,scale,g,pulse in settings:
                code,ref=acquire_with_scale_and_glint(m,c,seed*10000+ix,solar_scale=scale,glint_scale=g,pulse=pulse)
                dg=compute_diagnostics(m,est,code,ref)
                v5=v5_gate(dg)
                direction=np.array(dg['sun']).copy()
                rescue=(dg['recovered_states']=='ISOLATED_PROVISIONAL')&v5
                direction[rescue]=dg['recovered_sun'][rescue]
                masks={'V5':v5,'abs_amp_108':v5&amp_threshold(dg,1.08),
                       'abs_amp_112':v5&amp_threshold(dg,1.12),
                       'rolling_amp_110':v5&~rolling_bright_flags(dg),
                       'transient_bright_jump':v5&~transition_warning(dg)}
                for meth,accepted in masks.items():
                    rows.append(dict(seed=seed,scenario=name,case=c['case'],method=meth,
                                     amp_med=float(np.median(dg['amp'])),
                                     **metrics(direction,c['sun'],c['direct'],accepted)))
        print('glint sensitivity seed',seed,'complete',flush=True)
    f=pd.DataFrame(rows);f.to_csv(HERE/'glint_and_brightness_stress.csv',index=False)
    s=f.groupby(['scenario','method'],as_index=False).agg(n=('case','size'),good5=('day_good5_pct','mean'),
      wrong5=('day_wrong5_pct','mean'),accept=('day_accept_pct','mean'),p95_mean_case=('p95_accepted_deg','mean'))
    s.to_csv(HERE/'glint_brightness_summary.csv',index=False)
    return s

if __name__=='__main__':
    if '--glint-stress' in sys.argv:
        run_glint_and_scale()
