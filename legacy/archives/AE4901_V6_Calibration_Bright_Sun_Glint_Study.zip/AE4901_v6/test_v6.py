import unittest
import numpy as np
from quality_layer import review, Input
from run_v6 import amp_threshold, rolling_bright_flags, metrics

class V6GuardsTest(unittest.TestCase):
    def test_no_reference_never_strictly_accepts_for_control(self):
        x=review(Input(True,80.),True)
        self.assertFalse(x.control_eligible)
        self.assertTrue(x.display_vector)
        self.assertEqual(x.state,'UNVERIFIED')
    def test_amplitude_warning_and_strict_reject(self):
        obs=Input(True,90.,optical_calibration_verified=True,solar_reference_illuminance=80.)
        self.assertEqual(review(obs,True).state,'EXCESS_LIGHT_SUSPECT')
        self.assertFalse(review(obs,True).display_vector)
        self.assertEqual(review(obs,False).state,'EXCESS_LIGHT_WARNING')
    def test_normal_amplitude_is_candidate_only(self):
        obs=Input(True,81.,optical_calibration_verified=True,solar_reference_illuminance=80.)
        d=review(obs,True)
        self.assertEqual(d.state,'PHOTOMETRICALLY_PLAUSIBLE')
        self.assertFalse(d.control_eligible)
    def test_invalid_photometry_rejected(self):
        self.assertEqual(review(Input(True,float('nan'))).state,'INVALID_PHOTOMETRY')
    def test_v5_invalid_is_not_revived(self):
        self.assertEqual(review(Input(False,80.)).state,'NO_VALID_VECTOR')
    def test_absolute_gate_tolerance(self):
        d={'amp':np.array([80.,85.,88.])}
        self.assertEqual(amp_threshold(d,1.08).tolist(),[True,True,False])
    def test_rolling_needs_history(self):
        d={'amp':np.array([80.,80.,80.,80.,80.,80.,96.])}
        self.assertEqual(rolling_bright_flags(d).tolist(),[False]*6+[True])
    def test_rejected_does_not_count_as_correct(self):
        s=np.array([[1.,0,0],[0,1,0]])
        ans=metrics(s,s,np.array([True,True]),np.array([True,False]))
        self.assertEqual(ans['day_good5_pct'],50.)
        self.assertEqual(ans['day_accept_pct'],50.)

if __name__=='__main__': unittest.main()
