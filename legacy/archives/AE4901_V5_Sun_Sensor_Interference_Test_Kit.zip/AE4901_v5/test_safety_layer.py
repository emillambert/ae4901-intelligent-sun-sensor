from safety_layer import Observation,SunSafetyLayer

def sample(t,flux=70.,vec=(1.,0.,0.),resid=1.,delta=2.,boards=True,**kw):
    return Observation(vec,flux,resid,delta,t,boards,**kw)

def test_states():
    s=SunSafetyLayer(80.)
    assert s.update(sample(0)).status=='VALID_CANDIDATE'
    assert s.update(sample(1,.1)).status=='NO_SUN'
    assert s.update(sample(2,70.)).status=='REACQUIRING'
    assert s.update(sample(3,70.)).status=='VALID_CANDIDATE'
    assert not s.update(sample(4,70.,resid=4.)).valid_for_display
    assert not s.update(sample(5,70.,delta=24.)).valid_for_display
    assert s.update(sample(6,70.,boards=False)).status=='DEGRADED'
    assert not s.update(sample(7,70.,isolated_sensor_id=5,isolation_independently_verified=False)).valid_for_autonomous_control

def test_temporal_advisory():
    s=SunSafetyLayer(80.)
    s.update(sample(0,vec=(1,0,0)))
    d=s.update(sample(1,vec=(0,1,0)),max_plausible_rate_deg_per_s=1.)
    assert d.valid_for_display
    assert any('angular-rate' in w for w in d.warnings)

def test_default_never_flight_qualified():
    s=SunSafetyLayer(80.)
    assert s.update(sample(1)).valid_for_display
    assert not s.update(sample(2)).valid_for_autonomous_control

if __name__=='__main__':
    for f in [test_states,test_temporal_advisory,test_default_never_flight_qualified]:
        f();print('PASS',f.__name__)
