from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
s=pd.read_csv(ROOT/'summary.csv')
methods={'baseline':'V4 baseline','threshold':'Brightness','cross_recover':'Cross-face + recovery','conservative_recover':'Strict + recovery','temporal':'Temporal hard gate'}
scenarios=[('eclipse_only','Eclipse: incorrect valid Sun detections','eclipse_false_valid_pct','% falsely accepted'),
('corrupt_channel','One failed LDR: correct accepted directions','day_good5_pct','% valid within 5°'),
('specular_glint','Strong glint: wrong accepted directions','day_wrong5_pct','% valid but >5° wrong'),
('fast_tumble','Fast tumble: correct accepted directions','day_good5_pct','% valid within 5°')]
for label,title,key,ylabel in scenarios:
    data=s[s.scenario==label]
    ys=[float(data[data.method==k][key].iloc[0]) for k in methods]
    plt.figure(figsize=(8,4.2))
    bars=plt.bar(range(len(ys)),ys)
    plt.xticks(range(len(ys)),list(methods.values()),rotation=15,ha='right')
    plt.ylim(0,106)
    plt.ylabel(ylabel)
    plt.title(title+' (synthetic held-out validation)')
    for b,y in zip(bars,ys):plt.text(b.get_x()+b.get_width()/2,y+1,f'{y:.1f}%',ha='center',fontsize=9)
    plt.tight_layout()
    plt.savefig(ROOT/f'figure_{label}.png',dpi=165,bbox_inches='tight')
    plt.close()
