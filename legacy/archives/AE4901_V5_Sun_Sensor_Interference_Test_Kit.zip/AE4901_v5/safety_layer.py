#!/usr/bin/env python3
"""AE4901 Sun Sensor V5: reference health/validity state machine.

This implements low-complexity safeguards for a host/GSE demonstrator. It is not
flight software. A GL5537-1 hardware calibration and thresholds verification
are mandatory before trusting the flag for autonomous control.

Direction and residuals come from the existing V4 estimator. This class NEVER
uses the simulated true Sun direction and NEVER invents a Sun estimate.
"""
from dataclasses import dataclass
from math import acos, degrees, sqrt, isfinite
from typing import Optional, Tuple

Vec = Tuple[float,float,float]

@dataclass
class Observation:
    vector: Optional[Vec]
    max_calibrated_flux: float
    normalized_fit_residual: float
    board_disagreement_degrees: Optional[float]
    timestamp_s: float
    both_boards_online: bool=True
    isolated_sensor_id: Optional[int]=None
    # An isolated sensor is only a hypothesis unless independently confirmed.
    isolation_independently_verified: bool=False

@dataclass
class Decision:
    status: str
    valid_for_display: bool
    valid_for_autonomous_control: bool
    vector: Optional[Vec]
    warnings: Tuple[str,...]

class SunSafetyLayer:
    def __init__(self, sun_reference_flux:float, direct_fraction:float=.30,
                 residual_max:float=2.9, board_disagreement_max_degrees:float=14.,
                 reacquisition_samples:int=2, verified_hardware:bool=False):
        assert sun_reference_flux>0
        self.sun_reference_flux=sun_reference_flux
        self.direct_fraction=direct_fraction
        self.residual_max=residual_max
        self.board_disagreement_max_degrees=board_disagreement_max_degrees
        self.reacquisition_samples=reacquisition_samples
        self.verified_hardware=verified_hardware
        self.last_vector:Optional[Vec]=None
        self.last_timestamp:Optional[float]=None
        self.seen_dark=False
        self.reacquisition_streak=0
        self.mode='UNINITIALIZED'

    @staticmethod
    def angular_distance(a:Vec,b:Vec)->float:
        da=sqrt(sum(x*x for x in a));db=sqrt(sum(x*x for x in b))
        if da==0 or db==0:return float('inf')
        return degrees(acos(min(1.,max(-1.,sum(x*y for x,y in zip(a,b))/(da*db)))))

    def update(self,obs:Observation,max_plausible_rate_deg_per_s:Optional[float]=None)->Decision:
        warnings=[]
        if obs.vector is None or not all(isfinite(x) for x in obs.vector):
            self.mode='NO_DATA';self.reacquisition_streak=0
            return Decision('NO_DATA',False,False,None,('Missing Sun-vector estimate',))
        if not isfinite(obs.max_calibrated_flux) or obs.max_calibrated_flux < self.direct_fraction*self.sun_reference_flux:
            self.mode='NO_SUN';self.seen_dark=True;self.reacquisition_streak=0
            self.last_vector=None;self.last_timestamp=None
            return Decision('NO_SUN',False,False,None,('Below calibrated direct-Sun threshold; eclipse or dark condition',))
        if not obs.both_boards_online:
            warnings.append('Single-controller degraded mode')
        residual_ok=isfinite(obs.normalized_fit_residual) and obs.normalized_fit_residual<=self.residual_max
        disagreement_ok=(not obs.both_boards_online) or (
            obs.board_disagreement_degrees is not None and isfinite(obs.board_disagreement_degrees) and
            obs.board_disagreement_degrees<=self.board_disagreement_max_degrees)
        if not residual_ok:warnings.append('One-source optical model has a poor fit')
        if not disagreement_ok:warnings.append('Independent board estimates disagree')
        # Conservative unverified isolation: allow provisional UI indication but
        # do not turn it into a qualified actuator command.
        tentative=obs.isolated_sensor_id is not None and not obs.isolation_independently_verified
        if tentative:warnings.append(f'Sensor {obs.isolated_sensor_id} isolated provisionally; ID not independently verified')
        if self.last_vector is not None and max_plausible_rate_deg_per_s is not None and self.last_timestamp is not None:
            dt=obs.timestamp_s-self.last_timestamp
            if dt>0 and self.angular_distance(self.last_vector,obs.vector)>max_plausible_rate_deg_per_s*dt+3.0:
                warnings.append('Change exceeds independently provided angular-rate bound')
                # This is deliberately an ADVISORY, not a hard gate.
        if not residual_ok or not disagreement_ok:
            if not obs.isolation_independently_verified:
                self.mode='SUSPECT'
                return Decision('SUSPECT',False,False,None,tuple(warnings))
        if self.seen_dark:
            self.reacquisition_streak+=1
            if self.reacquisition_streak<self.reacquisition_samples:
                self.mode='REACQUIRING'
                return Decision('REACQUIRING',False,False,None,tuple(warnings+['Confirmation sample required after darkness']))
            self.seen_dark=False;self.reacquisition_streak=0
        self.last_vector=obs.vector;self.last_timestamp=obs.timestamp_s
        self.mode='DEGRADED' if not obs.both_boards_online or tentative else 'VALID_CANDIDATE'
        # State names and validity are separated: real calibration and system verification
        # cannot be inferred from self-consistency on synthetic data.
        qualified=self.verified_hardware and self.mode=='VALID_CANDIDATE' and not tentative
        return Decision(self.mode,True,qualified,obs.vector,tuple(warnings))

if __name__=='__main__':
    gate=SunSafetyLayer(80.)
    for t,flux in enumerate([75.,75.,.5,.5,70.,70.,70.]):
        obs=Observation((1.,0.,0.),flux,1.0,2.0,float(t))
        print(t,gate.update(obs))
