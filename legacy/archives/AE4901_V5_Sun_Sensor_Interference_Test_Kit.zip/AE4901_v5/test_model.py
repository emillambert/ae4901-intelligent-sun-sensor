import numpy as np
from leo_gating_study import earth_disk_albedo, scenarios, EARTH_RADIUS_DEG, acquire_environment, compute_diagnostics, decide, MODES, LUX
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'reference'))
from engineering_study import Model
from validate_v3 import Estimator

def test_earth_geometry():
    assert 69<EARTH_RADIUS_DEG<72
    c=scenarios(811,1,12)
    for x in c:
        assert np.allclose(np.linalg.norm(x['sun'],axis=1),1.,atol=1e-9)
        assert np.allclose(np.linalg.norm(x['nadir'],axis=1),1.,atol=1e-9)
        a,_=earth_disk_albedo(x['sun'],x['nadir'],x['cloud_seed'],x['label'],npatch=50)
        assert np.all(np.isfinite(a)) and np.all(a>=0)
    print('PASS earth disk geometry and nonnegative radiance')

def test_eclipse_and_threshold():
    m=Model(811);est=Estimator(m,n_grid=1500)
    c=[x for x in scenarios(10811,1,15) if x['label']=='eclipse_only'][0]
    codes,refs,_=acquire_environment(m,c,811123)
    d=compute_diagnostics(m,est,codes,refs)
    par=dict(brightness=.30,resid=2.9,boards_deg=14,step_deg=4,margin_deg=3,reacq=.35)
    assert decide(d,MODES['baseline'],par).all()
    assert not decide(d,MODES['threshold'],par).any()
    print('PASS eclipse threshold synthetic regression')
if __name__=='__main__':
    test_earth_geometry();test_eclipse_and_threshold()
