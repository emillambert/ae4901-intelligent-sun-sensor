# AE4901 Intelligent Sun Sensor — V5 space-light robustness experiment

**21 November 2026 · Computational reference, not hardware or flight qualification**

## Summary / decision

Keep:
- **Calibrated solar-strength detection** (from at least one valid, calibrated channel), with the threshold derived from a *real solar calibration* before field use. Simulation setpoint: 0.30 × 80-lux-equivalent full-direct-Sun response.
- **Cross-controller model-consistency monitoring**, with the V4 **provisional single-channel fault-isolation** candidate. The threshold only decides whether the result is suspect; it does not establish a validated false-alarm rate.
- **Eclipse/reacquisition state machine**. Confirm at least two consecutive good readings after actual darkness. It adds one-sample reacquisition latency. The default benchmark does **not** impose this after every independent test sequence, because that artificially reduces availability.
- **Temporal-rate warnings** when an independently measured/guaranteed angular-rate bound is available. Never automatically reject a true rapid rotation just because the Sun estimate moved quickly.

Do not adopt as defaults:
- Strong model-fit thresholds (they reject too much valid data and do not resolve structured glints).
- Hard temporal rejection (dramatically loses true Sun during rapid tumbling).
- A fixed Earth-albedo correction without external Earth-direction and reliable environmental data (can make results worse with little or no albedo).
- Two-source labeling that arbitrarily assumes the brighter source is the Sun, or optical masks, without evidence they work in the real environment.

## Test method

The experiment reuses the V2/V3/V4 synthetic, approximately-calibrated 12-LDR/dual-Arduino forward and inverse measurement model, and adds:

1. The apparent **Earth disk at 400 km**, angular radius 70.207°. Visible surface points receive direct Sun via a cosine incidence factor and emit Lambertian reflected radiance proportional to a synthetic geographic reflectivity map. Each LDR integrates radiation arriving from 80 disk directions, with its body-face and sensor-axis visibility applied.
2. Orbital day/night assignment via geometric Earth occultation (no penumbra/atmosphere); eclipse ingress/egress angles are deliberately scripted, not produced by a precise orbit propagator.
3. Synthetic cloud reflectivity, secondary coherent glint, one failed LDR, angular-response drift, and a fast-tumbling spacecraft.
4. Identical generated 10-bit ADC inputs for all software variants. The simulated solar illumination is **80 lux equivalent**; this is a laboratory-intensity normalization, **not the intensity of unattenuated sunlight in orbit**. GL5537-1 electrical response outside its characterized illumination range is not established.
5. Two separately seeded populations for development (701–704; 5 sequences × 24 frames × 11 scenarios each) and hold-out validation (811–814; 6 sequences × 24 frames × 11 scenarios). Per-channel calibration is synthetic and approximate. The reported numbers are average per-sequence results, not pooled p95 or on-orbit error bounds.

No true Sun vector is used in the onboard decision rules. The truth directions are used ONLY for scoring. The optional Earth-prior experiment receives synthetic externally known nadir direction (not provided by the assignment hardware); label its outcome separately.

## Independent held-out results — representative comparisons

For errors, **correct** means an accepted Sun direction within 5° of the synthetic true Sun. **Wrong accepted** means an accepted estimate more than 5° wrong. These numbers are scenario-conditional, **not** estimated rates per orbital day.

| Test | V4 baseline | Brightness + cross-face + provisional fault recovery | Interpretation |
| --- | ---: | ---: | --- |
| Nominal direct Sun: correct accepted | 99.13% | **99.31%** | Essentially same high nominal availability |
| Nominal direct Sun: p95 among accepted | 1.59° | **1.59°** | No measurable normal accuracy gain |
| Typical distributed Earth albedo: correct accepted | 99.13% | **99.13%** | Existing estimator adequate in this simplified case |
| Eclipse-only: falsely valid Sun | **100%** | **0%** | A strong benefit of calibrated brightness gating |
| Eclipse crossing: falsely valid Sun | **100%** | **0%** | Again strong in this model |
| Corrupted single LDR: correct accepted | 83.33% | **86.11%** | Modest increase in usable correct directions |
| Corrupted single LDR: wrong accepted | 16.67% | **7.12%** | Substantially fewer dangerous wrong values, but some rejected |
| Severe directional glint: wrong accepted | 77.78% | **71.70%** | **NOT solved** |
| Fast tumble: correct accepted | 93.58% | **92.88%** | Essentially retained; hard temporal rejection collapsed to 15.10% |
| Angular-response drift: correct accepted | 89.24% | 87.85% | Needs real recalibration; extra gates don't fix it |

The optional **conservative** residual gate reduces wrong accepted glint directions to 34.20%, but still accepts **zero** correct glint directions in the selected stress case and reduces correct accepted fast-tumble readings to 12.15%. It is a configurable warning/very conservative mode, not a universal improvement.

The **external-nadir Earth-albedo prior** reduced estimated typical-albedo p95 from ~2.04° to ~1.20°, but increased no-albedo Sun-only p95 from ~1.59° to ~5.70° and degraded fault cases. It is NOT suitable without additional attitude/ephemeris information and a validated reflectance prior.

The eclipse false-detection rate is zero under these **synthetic sampled conditions**, not a formal reliability bound. The current model excludes atmospheric scattering/penumbra, actual orbital cloud maps, spacecraft-glint geometry, LDR spectral variations, and hardware saturation at real solar irradiance. Those may produce more difficult counterexamples.

## Code and reproduction

Requires Python 3.10+, NumPy, SciPy, pandas, Matplotlib.

```bash
python test_model.py
python test_safety_layer.py
OPENBLAS_NUM_THREADS=1 python leo_gating_study.py --seeds 811 812 813 814 --nseq 6 --frames 24
python make_figures.py
python safety_layer.py
```

`reference/` contains copied V3/V4 mathematical modules. `leo_gating_study.py` generates 11 synthetic lighting/fault cases and all ablations. `safety_layer.py` is an integration-ready Python **reference** state machine, not compiled Arduino firmware; it requires actual calibration, processor-target implementation and physical verification. `summary.csv` and `test_rows.csv` contain the held-out results; `development_summary.csv`/`development_rows.csv` give independent tuning population results; `sweep_summary.csv` is an exploratory threshold sweep, not a certified tuning output.

## Key remaining blockers

1. **Coherent directional reflections/false Sun:** cannot reliably disambiguate arbitrary sources from a small number of broadband intensity channels; strong glint remains the largest *conditional* modeled threat.
2. **True GL5537-1 optical/electrical calibration:** angles, spectral dependence, temperature, ADC range and illumination conditions must be experimentally measured, including true orbital-intensity engineering feasibility.
3. **Drift and stale calibration:** the separate V4 controlled-angle recalibration was promising in simulation, but no self-calibration is observable without an independent reference.
4. **Faults and failover:** provisional isolation can be wrong; common power/host failures remain untested.

## Literature grounding

- NASA, Small Spacecraft Technology State of the Art, GNC chapter: <https://www.nasa.gov/smallsat-institute/sst-soa/guidance-navigation-and-control/> — coarse sensors, FOV versus albedo threshold trade-off.
- EIVE CubeSat on-orbit ADCS qualification, 2024: <https://link.springer.com/article/10.1007/s12567-024-00559-7> — false Sun during eclipse transitions and relative intensity checks.
- UPMSat-2 COTS Sun sensor, 2021: <https://www.mdpi.com/1424-8220/21/14/4905> — on-orbit albedo-related correction, largely at incidence angles beyond 75°.
- AE4901 assignment manual (11 November 2026), assignment 3, page 7.
