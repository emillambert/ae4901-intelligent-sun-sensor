#!/usr/bin/env python3
"""Demonstrate identifiability of the proposed calibration fit on SYNTHETIC data.
Not a substitute for lab characterization. Fits R10, gamma, angular exponent,
and ambient flux from controlled illumination/known Sun directions.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from engineering_study import Model,N,PHYS,sphere,flux_to_r,divider_voltage,voltage_to_r,resp
O=Path(__file__).resolve().parent
m=Model(701)
rng=np.random.default_rng(384)
angles=sphere(750,.398)
ref=np.repeat(angles,4,axis=0)
brightness=np.tile([20.,40.,70.,100.],len(angles))
true=resp(ref,exponent=m.p)
flux=brightness[:,None]*true + m.ambient[None,:]
r=flux_to_r(flux,m.r10,m.gamma)
vv=divider_voltage(r,m.rfixed,m.vcc)
# voltage read at 5V AVcc with ADC noise. The inference assumes known source lux.
counts=np.clip(np.round(1023*vv/m.vcc[None,:]+rng.normal(0,.65,vv.shape)),1,1022)
volts=counts/1023*m.vcc[None,:]
converted=voltage_to_r(volts,m.rfixed,m.vcc)
rows=[]
for j in range(12):
  visible=(ref@PHYS[j])>0
  dot=np.clip(ref@N[j],0,1)
  # Optimize using source angles with useful illumination; include some dark samples
  sel=(visible & (dot>.25)) | (~visible & (rng.random(len(ref))<.08))
  x=dot[sel];B=brightness[sel]; target=np.log(converted[sel,j])
  def predicted(params):
    logR10,g,p,b=params
    illumination=np.maximum(B*x**p+b,.03)
    return logR10-g*np.log(illumination/10)
  fit=least_squares(lambda theta:predicted(theta)-target,
     [np.log(25000),.6,1.1,1.5],bounds=([np.log(10000),.4,.65,.01],[np.log(50000),.85,1.7,7.]),
     loss='soft_l1',f_scale=.02,max_nfev=400)
  logR,g,p,b=fit.x
  rows.append(dict(sensor=j,truth_R10=m.r10[j],fit_R10=np.exp(logR),truth_gamma=m.gamma[j],fit_gamma=g,
                   truth_exponent=m.p[j],fit_exponent=p,truth_bg=m.ambient[j],fit_bg=b,
                   rms_logR=float(np.sqrt(np.mean(fit.fun**2))),observations=int(sel.sum())))
df=pd.DataFrame(rows)
df.to_csv(O/'synthetic_calibration_fit.csv',index=False)
print('Synthetic calibration fit ONLY. Median absolute errors:')
for k in ['R10','gamma','exponent','bg']:
    err=np.abs(df['fit_'+k]-df['truth_'+k])
    print(k, 'median',round(err.median(),4),'p95',round(err.quantile(.95),4))
