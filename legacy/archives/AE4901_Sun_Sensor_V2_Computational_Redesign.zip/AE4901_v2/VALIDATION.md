# AE4901 Sun Sensor V2 — mathematical redesign, simulation and limitations

**Date:** 2026-11-21. **Status:** computational / unverified hardware.

## Frozen hardware baseline

- Six CubeSat faces, two GL5537-1 per face; one per controller.
- Each controller owns one of six sensor-axis sets rotated +10° or −10° about the [1,1,1] body diagonal (~8.16° tilt from each face normal).
- Two Arduino-class boards. One GL5537-1 and one fixed resistor per analog channel; three-dimensional vector + health status.
- Use the smallest resistor *actually supplied*, preferably 30 kΩ. Practical manual specifies **12 resistors 30 kΩ–3 MΩ**, but does not guarantee twelve 30 kΩ parts. Do not treat this as a locked BOM.

## Improvements attempted

1. **LDR calibration:** replace identical-LDR and ideal-cosine approximation with individual nonlinear resistance parameters (R10, gamma), angular exponent, sensor background offset and geometric normals. A `synthetic_calibration.py` demonstration fits all four types of parameters against synthetic known-angle / known-illuminance data. Real calibration is still necessary.
2. **ADC headroom:** keep the fixed divider and choose between AVcc and the nominal 1.1 V internal ADC reference on ATmega328P/ATmega2560. Low ADC voltage can be read at substantially more counts. Reference-change settling and actual AVcc/internal-reference calibration are required. A 30k resistor is the lowest part value mentioned in the manual; values above 30k worsen high-light sensitivity under this divider orientation.
3. **Controller failure:** continue estimation using the surviving six-face sensor set and explicitly report degraded status. The nearest-response estimator does not demand a full-rank above-threshold linear problem; this is a different definition of coverage from the older ~79% result.
4. **Ambient/reflections:** subtract calibrated static ambient offsets, use a calibrated one-source response library, compare residuals and cautiously isolate a suspect single channel. If a coherent second source is present or isolation is ambiguous, flag the output as unreliable. No algorithm in this package guarantees that two illuminated sources can be uniquely identified or that the true Sun can be labeled without additional priors.

## Key results: one hypothetical sensor-population draw

| Simulated test | Baseline nominal + 5V p95 | Calibrated + auto reference p95 | Conservative fault-logic p95 / accepted % |
|---|---:|---:|---:|
| Single 80-lux source | 12.428° | 2.263° | 2.263° / 100% |
| Single 300-lux source | 14.354° | 2.132° | 2.132° / 100% |
| One contaminated LDR (+40% source) | 21.808° | 17.983° | 3.755° / **56.38%** |
| Second directional source (30%) | 21.772° | 18.388° | 15.611° / **27.46%** |
| Arduino A offline | 13.876° | 4.565° | -- |
| Arduino B offline | 14.998° | 3.199° | -- |

All p95 figures are **conditional on accepted samples**. The acceptance criteria and imposed fault severity are illustrative and not calibrated to real false-positive/false-negative rates. A small p95 on only a subset of directions is not a full-coverage accuracy claim. The extra p95 errors in the fault scenario depend on the chosen secondary-light direction and one synthetic population of sensors.

**Six additional independent hypothetical sensor-population draws:** after calibrated ADC auto-ranging, normal 80-lux p95 was 1.91–2.37°, Arduino A outage p95 2.70–4.32°, and a fixed 30% second source p95 **21.04–25.30°**. These are *parameter sensitivity checks*, not statistically meaningful confidence bounds on physical accuracy.

## Current ranking of material remaining errors / blockers

| Rank | Current limitation | Quantitative evidence | Needed action |
|---|---|---|---|
| 1 | Conflicting directional light and reflections | 18.39° p95 for a 30% secondary source in one run; 21–25° across 6 other synthetic draws | Use explicit one-source fit/quality flag; physically control illumination or add independent information if operation under multiple comparable light sources is required |
| 2 | Unknown **actual** LDR optical response, spectral dependence and calibration transfer | Synthetic model assumes a smooth cosine-power angular response with precisely fitted parameters. Real error unknown | Obtain genuine directional/range calibration before claiming accuracy; no way to certify it mathematically |
| 3 | Fault detection versus continued availability | 3.76° p95 conditional on ~56% of readings after a corrupted channel | Stronger redundancy logic, temporal checks and real false-alarm metrics if continuous operation is essential |
| 4 | Controller outage | 3.20–4.57° p95 in one model draw; data still usable in 97–98% of sky directions within 5° | One sensor per face on each board is sound. Ensure genuinely independent power/communications and verify real fault recovery |
| 5 | ADC quantization, input impedance and strong-light saturation | 30k divider at 100 lux: 177 counts on 5V vs 805 on 1.1V. At extrapolated 100,000 lux: 3 vs 15 counts | Auto reference helps but direct-sun range still cannot be guaranteed; switch reference correctly or change hardware if direct sunlight is required |
| 6 | Lab source angular geometry, temperature and CdS time history | Not modeled here; a nearby extended lamp and LDR hysteresis can dominate the assumed <3° normal-case simulation | Must be separately analyzed/characterized if sub-degree goals are important |

## Mathematical model & simplifying assumptions

- Geometric response: `E_i = B * max(0,n_i·s)^p_i * 1{f_i·s>0} + ambient_i + fault_i`, where `n` is the tilted optical normal and `f` is the physical cube face normal.
- Electrical response: `R_i(E)=R10_i*(E/10)^(-gamma_i)`, clipped to finite resistance; this gamma power law is only manufacturer-defined between **10 and 100 lux**. Every result using irradiances outside that range is an **extrapolation**.
- Divider: `V_ADC=VCC*R_LDR/(R_FIXED+R_LDR)`; 10-bit code approximately `1023*V_ADC/V_REF`.
- Calibration truth in simulation: R10 uniformly 20–30 kΩ, gamma ~0.60±0.032, **hypothetical** optical exponent ~1.15±0.11, 1.5 lux average static ambient, 0.8% light jitter, 0.65 ADC count noise.
- Assumed per-sensor calibration uncertainty: 2% in R10, ±0.008 in gamma, ±0.035 in optical exponent, ±0.25 lux in background, and calibrated but imperfect VCC/internal reference.
- Method: 24,000 model sky directions and 2,400 independent held-out directions, nearest normalized response pattern. Failure tests use fixed injected patterns, not modeled physical aging. Conservative one-channel recovery uses all 12 leave-one-out fits and refuses ambiguous cases.
- The model does not include actual lens/resin/package scattering, finite near-field source extent, spectral differences between Sun and lamps, transient CdS hysteresis, correlated board drift, real ADC integral/nonlinear error, power-rail coupling or physical 3D-printed tolerances.

## Reproduction & verification

- `engineering_study.py` produces circuit transfer table, scenario results, geometry CSV, figures and assumptions JSON.
- `synthetic_calibration.py` demonstrates fitting R10, gamma, angular exponent, background from synthetic experiments (an internal mathematical validation, not empirical calibration).
- `multiseed_check.py` repeats key cases on six synthetic parameter populations.
- `unit_checks.py` tests geometry, ADC equations, monotonic resistor behavior, failover handling, response library normalization and available output files.
- `electronics/ldr_30k_voltage_divider.cir` is a SPICE DC netlist; `electronics/README.md` describes the wiring. No ngspice or KiCad executable was present in this runtime, so the netlist was **not** checked in SPICE/KiCad. The arithmetic was verified independently in Python.
- `firmware/AE4901_v2_autorange.ino` is an uncompiled Arduino firmware prototype. `firmware/v2_host_estimator.py` was exercised in synthetic demo mode. Neither was tested on real Arduino hardware.

## Sources

- TU Delft AE4901 Embedded Systems Practical Manual (11 November 2026), section 4.4: default hardware and requirements.
- Senba GL5537-1 product data: https://www.lcsc.com/product-detail/C125628.html
- Microchip ATmega328P ADC voltage reference: https://onlinedocs.microchip.com/oxy/GUID-0EC909F9-8FB7-46B2-BF4B-05290662B5C3-en-US-12.1.1/GUID-3B1B66BF-56DE-4E06-8124-9B952CBCF02C.html
- Microchip ADC conversion/reference settling: https://onlinedocs.microchip.com/oxy/GUID-F670183D-C025-46C7-B7F5-9BAD389BF43F-en-US-3/GUID-C476E897-0FD2-4F5B-9B1E-674BB6F7E8B8.html
- NASA small spacecraft GNC: https://www.nasa.gov/smallsat-institute/sst-soa/guidance-navigation-and-control/
- HERMES coarse Sun-sensor calibration and redundancy: https://pmc.ncbi.nlm.nih.gov/articles/PMC10007507/

## Decision

Continue with the existing **bare six-face 12-LDR ±10° rotated design** and two independently acquired six-sensor arrays. Use the smallest supplied fixed resistor, prototype auto-ADC reference switching on an AVR with 1.1 V reference, and implement per-channel calibration, fit-quality reporting and failover. No basis to promise sub-degree accuracy or complete immunity to reflections. The single biggest unresolved **real-world** uncertainty is the actual packaged GL5537-1 angular/electrical response and its variation with brightness/source spectrum.
