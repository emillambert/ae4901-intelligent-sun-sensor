from pathlib import Path
import numpy as np
import pandas as pd
from engineering_study import Model,Matcher,resp,BOARD,sphere,angular,stats
O=Path(__file__).resolve().parent
sun=sphere(1100,.371)
second=np.array([.49,-.24,.84]);second/=np.linalg.norm(second)
rows=[]
for seed in (40,41,42,43,44,45):
 m=Model(seed)
 look=Matcher(m.est_p,ngrid=17000)
 b=Matcher(m.est_p,ngrid=17000,board=1)
 for case,lux,source,fail in [
  ('normal_80_lux',80,None,None),
  ('brighter_300_lux',300,None,None),
  ('secondary_30pct',80,(second,.3),None),
  ('board_A_offline',80,None,0)]:
  rng=np.random.default_rng(seed*313+3)
  adc,ref=m.read(sun,rng,lux,source,False,'auto',fail)
  flux,flags=m.recover(adc,ref,'calibrated')
  matcher=b if fail==0 else look
  est,d,_=matcher.query(flux)
  active=BOARD!=fail if fail is not None else np.ones(12,bool)
  valid=(d<.6)&(np.linalg.norm(flux[:,active],axis=1)>1)
  s=stats(angular(est,sun),valid)
  rows.append(dict(seed=seed,scenario=case,**s))
df=pd.DataFrame(rows)
df.to_csv(O/'multiseed_sensitivity.csv',index=False)
print(df.groupby('scenario')[['p95_deg','valid_pct','all_within5_pct']].agg(['min','median','max']).round(2).to_string())
