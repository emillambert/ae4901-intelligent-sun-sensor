from pathlib import Path
import numpy as np,pandas as pd
from engineering_study import N,F,BOARD,Model,resp,flux_to_r,divider_voltage,voltage_to_r,to_lux,sphere,Matcher
root=Path(__file__).resolve().parent
assert np.allclose(np.linalg.norm(N,axis=1),1)
assert np.allclose(N.T@N,4*np.eye(3),atol=1e-9)
assert set(BOARD.tolist())=={0,1}
model=Model(7)
E=np.tile(np.linspace(10,100,12)[None,:],(4,1))
R=flux_to_r(E,model.r10,model.gamma)
V=divider_voltage(R,model.rfixed,model.vcc)
R2=voltage_to_r(V,model.rfixed,model.vcc)
assert np.allclose(R,R2,rtol=1e-9)
assert np.allclose(to_lux(R,model.r10,model.gamma),E,rtol=1e-9)
assert np.all(np.diff(flux_to_r(np.array([[10],[100]]),np.array([25000.]),np.array([.6]))[:,0])<0)
sun=sphere(400,.37)
assert np.all(resp(sun)>=0)
assert np.all(resp(sun)<=1+1e-12)
for board in (0,1):
  est,dist,ind=Matcher(model.est_p,board=board,ngrid=4000).query(resp(sun,exponent=model.est_p))
  assert np.isfinite(est).all() and np.isfinite(dist).all()
D=pd.read_csv(root/'divider_and_adc.csv')
q=D[(D.resistor_ohms==30000)&(D.lux==100)].iloc[0]
assert q.adc_autoref_count>4*q.adc_5v_count
results=pd.read_csv(root/'scenario_comparison.csv')
assert results.scenario.nunique()>=9
for name in ['80 lux / Arduino A offline','80 lux / Arduino B offline']:
  q=results[(results.scenario==name)&(results.approach=='B2: cal + auto ADC ref')].iloc[0]
  assert q.valid_pct>90
assert (root/'firmware/v2_host_estimator.py').exists()
print('PASS: geometry, inversion, ADC auto-reference, model dictionary, failover and artifact assertions')
