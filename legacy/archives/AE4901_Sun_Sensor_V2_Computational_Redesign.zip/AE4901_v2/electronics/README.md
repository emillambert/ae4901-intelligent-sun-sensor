# One-channel electrical design

```
 +5V/AVcc -- R_FIXED (30 kΩ initially) --+-- Arduino A0..A5
                                         |
                                    GL5537-1 LDR
                                         |
                                        GND
```

For each of six sensors per board. Repeat for Arduino B; each board has one sensor on each of +X,-X,+Y,-Y,+Z,-Z.

`V_ADC = VCC * R_LDR/(R_FIXED+R_LDR)`, so the 5 V ADC reference is ratiometric and is insensitive to constant VCC variation, assuming divider power and analog reference use the same supply. For internal nominal 1.1 V reference, reconstruct the voltage using an individually characterized reference value *and* AVcc.

Select the smallest **actually supplied** R_FIXED, nominally 30 kΩ. The manual only says 12 resistors spanning 30 kΩ to 3 MΩ; it does not guarantee twelve 30 kΩ resistors. If the included values differ, enter each actual value into firmware and calibration.

With ATmega328P / Mega2560, `analogReference(DEFAULT)` then switch to internal reference only for low-voltage measurements (<0.90 V). Do **not** apply an external voltage to AREF. The first ADC result after a MUX or reference change should be discarded; wait for reference settling. This assumes MCU supports the 1.1 V reference; adapt for other boards.

A divider with 30 kΩ and R_LDR=25 kΩ has Thevenin source impedance `30k||25k=13.6kΩ`, slightly above the customary approx 10 kΩ ADC recommendation. Low-speed acquisition and sufficient settling make this a reasonable prototype, but quantization and sample/hold errors remain **unverified**. Optional capacitors or buffers are extra parts outside the guaranteed kit.

Netlist included in `ldr_30k_voltage_divider.cir`; it has not been simulated by an external SPICE solver here. The voltages were independently calculated by Python and validated with round-trip mathematical assertions.
