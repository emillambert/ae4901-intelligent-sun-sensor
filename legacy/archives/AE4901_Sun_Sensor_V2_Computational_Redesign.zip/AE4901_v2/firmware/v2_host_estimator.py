#!/usr/bin/env python3
"""AE4901 v2 host-side vector estimate & failover for SUN2 packets.
Prototype, not hardware or flight software qualification. Requires real per-sensor
calibration JSON. All quality thresholds are illustrative and must be validated.

Usage: python v2_host_estimator.py --demo
       python v2_host_estimator.py --port-a /dev/cu.usbmodemX --port-b /dev/cu.usbmodemY
"""
import sys,os,json,time,argparse
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from engineering_study import Matcher,BOARD,robust_recover,N,Model,resp,sphere,flux_to_r,divider_voltage

def parse(line):
    bits=line.strip().split(',')
    if len(bits)!=16 or bits[0]!='SUN2':return None
    try:
        ident=int(bits[1]);sequence=int(bits[2]);t=int(bits[3]);adc=np.asarray([int(x) for x in bits[4:10]],float)
        lowmask=int(bits[10]);rail=int(bits[11]);boardvector=np.asarray([float(x) for x in bits[12:15]])
        onboardvalid=int(bits[15])==1
        if ident not in (0,1) or min(adc)<0 or max(adc)>1023:return None
        return dict(id=ident,seq=sequence,time_ms=t,adc=adc,lowmask=lowmask,rail=rail,board_vector=boardvector,
                    onboardvalid=onboardvalid,receive=time.monotonic())
    except ValueError:return None

class Host:
  def __init__(self,config):
    self.conf=config
    self.cal=config['sensors']
    self.p=np.array([x['angular_exponent'] for x in self.cal])
    self.matchers={None:Matcher(self.p,24000),0:Matcher(self.p,24000,board=0),1:Matcher(self.p,24000,board=1)}
    self.last={}
  def ingest(self,p):self.last[p['id']]=p
  def compute(self):
    now=time.monotonic()
    online=[x for x in (0,1) if x in self.last and now-self.last[x]['receive']<self.conf['timeout_seconds']]
    if not online:return {'state':'NO_DATA','vector':None,'message':'Neither board fresh'}
    pattern=np.zeros(12,float)
    bad=np.zeros(12,bool)
    for board in online:
      p=self.last[board]
      for face in range(6):
        i=face*2+board
        s=self.cal[i]
        adc=float(p['adc'][face]); low=bool(p['lowmask']&(1<<face))
        vcc=self.conf['controller'][board]['avcc_volts']
        aref=self.conf['controller'][board]['internal_ref_volts']
        volts=adc/1023*(aref if low else vcc)
        if volts>=vcc or adc<2 or adc>1021:
            bad[i]=True;continue
        rr=s['fixed_resistor_ohms']*volts/(vcc-volts)
        light=10*(rr/s['resistance_at_10lux_ohms'])**(-1/s['electrical_gamma'])
        pattern[i]=max(0,light-s['ambient_offset_lux'])
    # Treat missing boards as missing, not faulty readings.
    online_board=None if len(online)==2 else online[0]
    valid_channels=np.array([i for i in range(12) if BOARD[i] in online and not bad[i] and pattern[i]>0])
    if len(valid_channels)<3 or np.linalg.norm(pattern)<1:
        return {'state':'INVALID','vector':None,'message':'Not enough usable signal'}
    # A failed individual channel must not be confused with a failed controller.
    matcher=self.matchers[online_board]
    vec,d,_=matcher.query(pattern[None,:]);quality=float(d[0]);isolated=False;suspect=False
    if online_board is None:
       out,dist,iso,sus=robust_recover(pattern[None,:],self.p,matcher)
       vec=out;quality=float(dist[0]);isolated=bool(iso[0]);suspect=bool(sus[0])
    # Strict confidence handling for known model mismatch. A lack of warning
    # never proves absolute angular accuracy or single-source illumination.
    if suspect or quality>.15:
       return {'state':'SUSPECT_LIGHT_OR_CALIBRATION','vector':vec[0].tolist(),
              'message':'One-source fit inconsistent; do not use for control',
              'fit_distance':quality,'valid_for_control':False}
    state='DEGRADED_CONTROLLER' if online_board is not None else ('RECOVERED_SENSOR' if isolated else 'NORMAL')
    return {'state':state,'vector':vec[0].tolist(),'fit_distance':quality,
            'valid_for_control':self.conf.get('real_calibration_verified',False),
            'warning':None if self.conf.get('real_calibration_verified',False) else 'Calibration is placeholder, output not qualified'}

def demo(host):
    model=Model(701)
    s=np.array([.62,-.21,.76]);s/=np.linalg.norm(s)
    sample=np.array([s]); rng=np.random.default_rng(17)
    counts,refs=model.read(sample,rng,80,adc_mode='auto')
    for board in (0,1):
        ind=np.arange(12)[BOARD==board]
        cmask=sum((1<<i) for i,j in enumerate(ind) if refs[0,j]==model.aref[j])
        packet=dict(id=board,seq=1,time_ms=1000,adc=counts[0,ind],lowmask=cmask,rail=0,
                    board_vector=np.array([0.,0.,0.]),onboardvalid=True,receive=time.monotonic())
        host.ingest(packet)
    print('Both boards:',json.dumps(host.compute()))
    host.last[0]['receive']-=10
    print('Arduino A offline:',json.dumps(host.compute()))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--demo',action='store_true');ap.add_argument('--config',default=str(HERE/'calibration_TEMPLATE.json'))
    ap.add_argument('--port-a');ap.add_argument('--port-b');args=ap.parse_args()
    host=Host(json.loads(Path(args.config).read_text()))
    if args.demo: demo(host);sys.exit(0)
    if not args.port_a and not args.port_b:ap.error('Provide --demo or at least one serial port')
    try:import serial
    except ImportError:sys.exit('Install pyserial for hardware serial acquisition.')
    ports={i:serial.Serial(x,115200,timeout=.05) for i,x in enumerate([args.port_a,args.port_b]) if x}
    try:
      while True:
        for board,ser in ports.items():
          packet=parse(ser.readline().decode('utf-8',errors='ignore'))
          if packet and packet['id']==board:host.ingest(packet)
        print(json.dumps(host.compute()))
        time.sleep(.15)
    finally:
      for ser in ports.values():ser.close()
