AE4901 sun-sensor geometries: reproducible preliminary simulation

GEOMETRY
Flat: two sensors normal to each of six cube faces.
Icosahedral: 12 unit directions of a regular icosahedron; two assigned to each nearest cube face.
Dual rotated cubes: two independent ±XYZ sensor sets, each rotated 30 deg about the [1,1,1] body diagonal in opposite directions. Each mounted optical axis tilts approximately 24.4 deg from its physical face normal.

MODEL
I_i = max(0, n_i dot s), normalized face-on intensity = 1.
Optional additive i.i.d. Gaussian noise sigma=0.01, clipped at zero. A sensor is INCLUDED in the fit when output > 0.05 (other threshold sweeps included). Estimate sun vector using ordinary least squares over included channels, with unknown common illumination scale and three vector components. No estimate is declared when the 3x3 normal-equation matrix is rank-deficient. Report angular error only for valid estimates; valid fraction separately.
30,000 nearly-uniform Fibonacci directions plus 18 axes/edge directions. Reproducible random seeds.

LIMITATIONS
No actual GL5537-1 angular response, resistance-light relationship, ADC quantization, lamp spectral characteristics, optical occlusion, mounted faces shadowing, per-channel calibration errors, albedo, or real thermal effects. These must be measured. 'Cos^1.3 mismatch' is a hypothetical model-error stress test, not a measured GL5537-1 exponent.
Some icosahedral face-to-MCU assignments are poor under one-board failure; assignments evaluated by enumerating all 64 possible pair splits with a 5% threshold.
Simulated angular error is conditional on valid orientations. Full rank of idealized positive measurements is stricter than a proper censored or Bayesian estimator using darkness information.
The dual rotated cube design is a proposed architecture, not a literature-validated optimal geometry.
