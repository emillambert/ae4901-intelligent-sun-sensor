"""Independent validation of 2026 AE4901 LDR sensor layout simulation.
Uses deterministic equal-area directions; checks complete geometry/visibility assumptions,
not actual sensor measurements. Physical shadow rule is an intentionally conservative
co-planar / flush-face placement. All error magnitudes are hypothetical.
"""
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
O=Path('/mnt/data/ae4901_validation'); O.mkdir(exist_ok=True,parents=True)
RNG=np.random.default_rng(20261121)
F=np.array([[1.,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])

def sphere(k=16384):
    # equidistributed in z, with an independent irrational-angle azimuth.
    i=np.arange(k)
    z=1-2*(i+.5)/k
    a=i*np.pi*(3-np.sqrt(5))
    rho=np.sqrt(1-z*z)
    return np.column_stack((rho*np.cos(a),rho*np.sin(a),z))
S=sphere()
S=np.concatenate([S,F],axis=0)

def rot(axis, degrees):
    k=np.asarray(axis,float); k=k/np.linalg.norm(k)
    p=np.deg2rad(degrees)
    K=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    return np.eye(3)+np.sin(p)*K+(1-np.cos(p))*(K@K)

def normals(rotation):
    R=rot([1,1,1],rotation)
    N=np.empty((12,3))
    for j,f in enumerate(F):
        N[2*j]=R@f
        N[2*j+1]=R.T@f
    return N

def ico():
    phi=(1+np.sqrt(5))/2
    v=[]
    for a in (-1,1):
        for b in (-1,1):
            v.extend([[a*phi,0,b],[a,b*phi,0],[0,a,b*phi]])
    v=np.asarray(v,float); v/=np.linalg.norm(v,axis=1)[:,None]
    N=[]
    for face in F:
        ii=np.flatnonzero(np.isclose(v@face,(v@face).max()))
        assert len(ii)==2
        N.extend(list(v[ii]))
    return np.asarray(N)

def brightness(N, shadow=True, exponent=1.0, gain=None, bg=0):
    raw=S@N.T
    signal=np.maximum(raw,0)
    if shadow:
        # Necessity for a flush, center-face sensor: light must arrive on outward hemisphere of the physical face.
        physical=np.repeat(F,2,axis=0)
        visible=(S@physical.T)>0
        signal*=visible
    signal=np.power(signal,exponent)
    if gain is not None:signal*=gain
    return signal+bg

def fit(N, y, threshold=0.05, keep=None):
    if keep is not None:
        y=y.copy(); y[:,~keep]=0
    use=y>threshold
    # Compute masked normal equations without calling original project's helper
    gram=np.einsum('ni,ij,ik->njk',use.astype(float),N,N)
    eig=np.linalg.eigvalsh(gram)
    valid=eig[:,0]>1e-8
    q=np.zeros((len(S),3)); r=np.sum(y[:,:,None]*use[:,:,None]*N[None,:,:],axis=1)
    if valid.any():q[valid]=np.linalg.solve(gram[valid],r[valid,:,None])[:,:,0]
    mag=np.linalg.norm(q,axis=1); valid&=(mag>1e-10)
    guess=q[valid]/mag[valid,None]
    errs=np.full(len(S),np.nan)
    errs[valid]=np.degrees(np.arccos(np.clip(np.sum(guess*S[valid],axis=1),-1,1)))
    return valid,errs,use,eig

def stats(valid,err):
    return dict(valid_pct=round(valid.mean()*100,2), median_deg=round(float(np.nanmedian(err)),3) if valid.any() else np.nan, p95_deg=round(float(np.nanquantile(err,.95)),3) if valid.any() else np.nan,
      p99_deg=round(float(np.nanquantile(err,.99)),3) if valid.any() else np.nan)

def independent_checks():
    # 12 normals are unit norm, and rigid rotations preserve dot products.
    for a in [0,15,30,45]:
        N=normals(a)
        assert np.allclose(np.linalg.norm(N,axis=1),1,atol=1e-12)
        assert np.allclose(N.T@N,4*np.eye(3),atol=1e-12)
        assert np.allclose(N[::2]@N[::2].T, F@F.T,atol=1e-12)
        assert np.allclose(N[1::2]@N[1::2].T,F@F.T,atol=1e-12)
        # at 0 deg duplicated sensors must match
        if a==0: assert np.allclose(N[::2],N[1::2])
    assert np.allclose(np.linalg.eigvalsh(ico().T@ico()),[4,4,4])
independent_checks()
rows=[]
for name,N in [('Flat',normals(0)),('Icosahedral',ico()),('Dual rotated 30deg',normals(30))]:
    physical=np.repeat(F,2,axis=0)
    raw=S@N.T
    backfacing=((raw>0.05)&(S@physical.T<=0))
    # Different scenarios; same 1% additive noise in every row for fair comparison.
    for shadow in (False,True):
        sig=brightness(N,shadow=shadow)
        for test, power, sigma, gains, subset in [
            ('No noise',1.,0.,None,None),
            ('1% noise',1.,.01,None,None),
            ('3% noise',1.,.03,None,None),
            ('1% noise + 5% gain mismatch',1.,.01,np.random.default_rng(13).normal(1,.05,12),None),
            ('1% noise + response exponent 1.3',1.3,.01,None,None),
            ('Board A offline',1.,.01,None,np.arange(12)%2==1),
            ('Board B offline',1.,.01,None,np.arange(12)%2==0),
        ]:
            signal=brightness(N,shadow=shadow,exponent=power,gain=gains)
            noise=np.random.default_rng(101).normal(0,sigma,size=signal.shape) if sigma else 0
            y=np.maximum(signal+noise,0)
            v,e,use,_=fit(N,y,.05,keep=subset)
            z={'geometry':name,'self_shadowing':shadow,'scenario':test,'face_backside_signal_pct':round(100*backfacing.mean(),2)}
            z.update(stats(v,e)); rows.append(z)
summary=pd.DataFrame(rows)
summary.to_csv(O/'scenario_audit.csv',index=False)

# Independent directional observability / conditioning profile by tilt.
scan=[]
for angle in np.arange(0,50,2.5):
    N=normals(angle)
    theta=float(np.rad2deg(np.arccos(np.clip(N[0]@F[0],-1,1))))
    for shadow in (False,True):
        y=brightness(N,shadow=shadow)
        v,e,u,ev=fit(N,y,.05)
        _,errN,_,_=fit(N,np.maximum(y+np.random.default_rng(22).normal(0,.01,y.shape),0),.05)
        for board,kept in [('all',np.ones(12,bool)),('A only',np.arange(12)%2==0),('B only',np.arange(12)%2==1)]:
            valid,err,_,_=fit(N,y,.05,keep=kept)
            scan.append(dict(rotation_deg=angle,tilt_deg=theta,self_shadowing=shadow,board=board,valid_pct=100*valid.mean(),
                 p95_err_deg=float(np.nanquantile(errN,.95)) if board=='all' else np.nan))
scan=pd.DataFrame(scan)
scan.to_csv(O/'tilt_audit.csv',index=False)

# Visualize shortcomings and geometry choice; contrasting shaded/unshaded.
fig, ax=plt.subplots(figsize=(8,4.8))
for shadow,color in [(False,'#34699A'),(True,'#C75050')]:
    t=scan[(scan.self_shadowing==shadow)&(scan.board=='all')]
    ax.plot(t.tilt_deg,t.valid_pct,marker='o',ms=3,color=color,label='With physical face visibility' if shadow else 'No cube occlusion')
ax.set(xlabel='Sensor tilt from local cube face normal (degrees)',ylabel='Share of directions with full-rank solution (%)',title='Geometric observability under ideal cosine model')
ax.set_ylim(0,103);ax.legend();ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(O/'self_shadowing_effect.png',dpi=170);plt.close(fig)

# Text summary
print('INVARIANTS validated: unit normals, N.T@N=4I, orthonormal per board, icosahedral symmetry.')
print('WARNING: independent icosahedral split in audit uses a canonical rather than original optimized board assignment.')
print('\nSCENARIOS SELECTED')
s=summary[summary.scenario.isin(['No noise','1% noise','1% noise + response exponent 1.3','Board A offline'])]
print(s[['geometry','self_shadowing','scenario','valid_pct','p95_deg','face_backside_signal_pct']].to_string(index=False))
print('\nTILT COVERAGE')
print(scan[(scan.board=='all') & (scan.rotation_deg.isin([0.,10.,20.,30.,40.]))][['rotation_deg','tilt_deg','self_shadowing','valid_pct']].to_string(index=False))
print('\nfiles',*[str(p) for p in O.iterdir()])
