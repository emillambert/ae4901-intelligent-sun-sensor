"""Geometry study final checks: optimized icosahedral split; corrected inverse response."""
from pathlib import Path
src=Path('/mnt/data/ae4901_validation_audit.py').read_text().split('rows=[]')[0]
exec(compile(src,'audit.py','exec'))
from numpy.random import default_rng
O=Path('/mnt/data/ae4901_validation')

# Make the same optimized face-to-board assignment as the prior simulation.
V=ico().copy()
for j,bit in enumerate([0,1,0,1,0,1]):
    if bit:V[2*j:2*j+2]=V[2*j:2*j+2][::-1].copy()

rows=[]
for name,N in [('Flat',normals(0)),('Icosahedral, optimized split',V),('Dual rotated 10deg (tilt 8.16deg)',normals(10)),('Dual rotated 15deg (tilt 12.24deg)',normals(15)),('Dual rotated 30deg (tilt 24.40deg)',normals(30))]:
 for pow in [1.,0.8,1.3]:
  y=brightness(N,True,exponent=pow)
  y=np.maximum(0,y+default_rng(234).normal(0,.01,size=y.shape))
  for calibration in ['uncalibrated linear','correct power inverse']:
   obs=y if calibration=='uncalibrated linear' else y**(1/pow)
   for subset in ['Both boards','Board A only','Board B only']:
    keep=None if subset=='Both boards' else (np.arange(12)%2==0 if subset=='Board A only' else np.arange(12)%2==1)
    v,errors,mask,_=fit(N,obs,0.05,keep)
    rows.append(dict(geometry=name,raw_exponent=pow,processing=calibration,controller_mode=subset,
      **stats(v,errors)))
result=pd.DataFrame(rows)
result.to_csv(O/'calibration_and_failover.csv',index=False)
print('STRESS MODEL: INVERSE-POWER CALIBRATION TEST')
print(result[(result.raw_exponent==1.3)&(result.controller_mode=='Both boards')][['geometry','processing','valid_pct','p95_deg','p99_deg']].to_string(index=False))
print('\nBOARD FAILOVER, IDEAL COSINE+1% NOISE')
print(result[(result.raw_exponent==1)&(result.processing=='uncalibrated linear')][['geometry','controller_mode','valid_pct','p95_deg','p99_deg']].to_string(index=False))
