"""Supplementary sensitivity analysis, imports only the definitions from independent audit script."""
from pathlib import Path
s=Path('/mnt/data/ae4901_validation_audit.py').read_text().split('rows=[]')[0]
exec(compile(s,'/mnt/data/ae4901_validation_audit.py','exec'))
from numpy.random import default_rng

records=[]
for rotation in [0,2.5,5,7.5,10,12.5,15,20,25,30]:
  N=normals(rotation)
  tilt=float(np.degrees(np.arccos(np.clip(N[0]@F[0],-1,1))))
  truth=brightness(N,shadow=True)
  for scenario in ['1% noise','1% noise + 5% gains','1% noise + angular misalign 1 degree','1% noise + cos power 1.3','1% noise + cos power 0.8']:
    for k in range(2):
      rng=default_rng(200+k)
      if scenario=='1% noise + 5% gains':
        y=brightness(N,True,gain=rng.normal(1,.05,12))
      elif scenario=='1% noise + angular misalign 1 degree':
        perturbed=np.zeros_like(N)
        for i,n in enumerate(N):
          axis=rng.normal(size=3); axis/=np.linalg.norm(axis)
          perturbed[i]=rot(axis,rng.normal(0,1))@n
        # actual sensor axes differ from nominal design but still on same physical face
        y=brightness(perturbed,True)
      elif scenario=='1% noise + cos power 1.3':
        y=brightness(N,True,exponent=1.3)
      elif scenario=='1% noise + cos power 0.8':
        y=brightness(N,True,exponent=.8)
      else:
        y=truth.copy()
      y=np.maximum(y+rng.normal(0,.01,y.shape),0)
      v,errors,_,eig=fit(N,y,.05)
      vv,ee,_,_=fit(N,y,.05,keep=np.arange(12)%2==0)
      records.append(dict(rotation_deg=rotation,tilt_deg=round(tilt,2),scenario=scenario,trial=k,
          valid_pct=v.mean()*100,p95_deg=np.nanquantile(errors,.95),p99_deg=np.nanquantile(errors,.99),
          fraction_accurate_under_3_deg=np.nanmean(v&(np.nan_to_num(errors,nan=999)<3))*100,
          one_board_valid_pct=vv.mean()*100,one_board_p95_deg=np.nanquantile(ee,.95)))
df=pd.DataFrame(records)
df.to_csv('/mnt/data/ae4901_validation/additional_stress_tests.csv',index=False)
agg=df.groupby(['rotation_deg','tilt_deg','scenario'])[['valid_pct','p95_deg','p99_deg','fraction_accurate_under_3_deg','one_board_valid_pct','one_board_p95_deg']].mean().reset_index()
print('SELECTED SUMMARY: ') 
for scenario in agg.scenario.unique():
 print('\n',scenario)
 print(agg[(agg.scenario==scenario)&(agg.rotation_deg.isin([0.,5.,10.,15.,20.,30.]))][['rotation_deg','tilt_deg','valid_pct','p95_deg','p99_deg','fraction_accurate_under_3_deg','one_board_valid_pct']].round(2).to_string(index=False))
agg.to_csv('/mnt/data/ae4901_validation/stress_summary.csv',index=False)
