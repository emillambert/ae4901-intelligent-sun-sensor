"""Optimize icosahedral split under realistic cube-face visibility.
Separate from original optimizer which ignored physical face blocking.
"""
from pathlib import Path
exec(compile(Path('/mnt/data/ae4901_validation_audit.py').read_text().split('rows=[]')[0],'audit.py','exec'))
from itertools import product,combinations

def rank_fraction_6(N6,signals6,threshold=.05):
  masks=signals6>threshold
  valid=np.zeros(len(S),bool)
  for triple in combinations(range(6),3):
    if abs(np.linalg.det(N6[list(triple)]))>1e-7:
      valid|=masks[:,list(triple)].all(axis=1)
  return valid.mean()

base=ico()
results=[]
for bits in product([0,1],repeat=6):
  N=base.copy()
  for i,b in enumerate(bits):
    if b: N[2*i:2*i+2]=N[2*i:2*i+2][::-1].copy()
  y=brightness(N,shadow=True)
  a=rank_fraction_6(N[::2],y[:,::2])
  b=rank_fraction_6(N[1::2],y[:,1::2])
  results.append(dict(bits=''.join(map(str,bits)),board_a_pct=100*a,board_b_pct=100*b,worst_board_pct=100*min(a,b)))
df=pd.DataFrame(results).sort_values(['worst_board_pct','board_a_pct'],ascending=False)
df.to_csv('/mnt/data/ae4901_validation/icosa_board_split_optimized_under_shading.csv',index=False)
print(df.head(10).round(3).to_string(index=False))
print('original original split 010101',df[df.bits=='010101'].round(3).to_string(index=False))
