"""Conservative long-glint gyro experiment; a prediction is never revalidated by a
contaminated LDR after propagation confidence expires. Reacquisition requires a
new independent reference once timed out. These are intentionally synthetic.
"""
from pathlib import Path
import numpy as np,pandas as pd
from scipy.spatial.transform import Rotation
from gyro_fusion_test import Model,Estimator,acquire,sunlight_sequence,angular,ang,vec_gyro_sequence
R=Path(__file__).resolve().parent

def conservative_monitor(y,base,omega,max_hold=40,gate=7):
    output=np.full_like(y,np.nan)
    mode=np.full(len(y),'invalid',dtype='<U20')
    anchor=None;forecast=None;age=0;expired=False
    for t in range(len(y)):
        if t==0:
            if base[t]:forecast=y[t].copy();output[t]=forecast;mode[t]='measured'
            continue
        if forecast is not None:
            forecast=Rotation.from_rotvec(omega[t-1]).apply(forecast)
            forecast/=np.linalg.norm(forecast)
        if forecast is None:
            if base[t] and not expired:
                forecast=y[t].copy();output[t]=forecast;mode[t]='measured';age=0
            continue
        good=base[t] and ang(y[t],forecast)<gate and not expired
        if good:
            forecast=0.7*forecast+0.3*y[t]
            forecast/=np.linalg.norm(forecast)
            output[t]=forecast;mode[t]='measured';age=0
        else:
            age+=1
            if age<=max_hold and not expired:
                output[t]=forecast;mode[t]='propagated'
            else:
                expired=True
                # Keep forecast internal but NEVER trust it or re-anchor from LDR
                # without a separate independent reference.
    return output,mode

def run():
    rows=[]
    for T in [40,120,300]:
        for bias in [0.04,0.25,0.8]:
            for seed in range(221,225):
                m=Model(seed);est=Estimator(m,n_grid=7500)
                for trial in range(22):
                    scenario='sustained_glint';truth,glint,amp=sunlight_sequence(seed*10000+trial,scenario,T=T)
                    (_, _),(c,ref)=acquire(m,truth,np.random.default_rng(seed*10000+trial+930),lux=80,second=(glint,amp))
                    y,score,valid,brightness,_,_=est.estimate(c,ref,'V3')
                    base=valid&(brightness>24)
                    omega=vec_gyro_sequence(truth,np.random.default_rng(seed*30000+trial+989),bias,0.18)
                    out,mode=conservative_monitor(y,base,omega,max_hold=40)
                    err=angular(np.nan_to_num(out,nan=0),truth)
                    active=mode!='invalid'
                    rows.append(dict(duration_s=T, bias_deg_s=bias, total_accepted=np.mean(active)*100,
                                     direct=np.mean(mode=='measured')*100,prop=np.mean(mode=='propagated')*100,
                                     accepted_good5=np.mean(active&(err<=5))*100,
                                     accepted_wrong10=np.mean(active&(err>10))*100,
                                     invalid=np.mean(~active)*100))
    df=pd.DataFrame(rows); df.to_csv(R/'long_runs.csv',index=False)
    s=df.groupby(['duration_s','bias_deg_s'],as_index=False).mean();s.to_csv(R/'long_summary.csv',index=False)
    print(s.round(2).to_string(index=False))
if __name__=='__main__': run()
