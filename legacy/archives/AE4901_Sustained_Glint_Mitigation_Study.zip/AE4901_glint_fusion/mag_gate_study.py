"""Synthetic magnetometer angle-invariant gate (not complete ADCS). 
Tests the physically available scalar constraint b_body dot s_body = b_inertial dot s_inertial.
Requires an external magnetic-field model and ephemeris, not provided in course kit.
"""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from gyro_fusion_test import Model,Estimator,acquire,sunlight_sequence,angular,metric

def unit(v):return np.asarray(v)/np.linalg.norm(v)
def angle(a,b):return np.rad2deg(np.arccos(np.clip(np.sum(a*b,axis=-1),-1,1)))
def rotated_b_field(truth,rng):
    # Choose one independent magnetic vector for each sequence; physically co-rotates
    # with the spacecraft, at near-constant inertial Sun–B angle over 40 s.
    b0=unit(rng.normal(size=3)); b=np.zeros_like(truth);b[0]=b0
    for i in range(1,len(truth)):
        a,c=truth[i-1],truth[i]
        cross=np.cross(a,c);norm=np.linalg.norm(cross)
        step=np.arctan2(norm,np.dot(a,c))
        axis=cross/norm if norm>1e-12 else np.array([1.,0.,0.])
        b[i]=Rotation.from_rotvec(axis*step).apply(b[i-1])
    # Synthetic 2° magnetic vector error and 3° reference scalar-angle error.
    bmeas=np.zeros_like(b)
    for i in range(len(b)):
        bmeas[i]=unit(Rotation.from_rotvec(rng.normal(0,np.deg2rad(2)/np.sqrt(3),3)).apply(b[i]))
    expected=angle(truth,b)+rng.normal(0,3,len(truth))
    return bmeas,expected

def run():
    rows=[]
    for seed in range(221,225):
        m=Model(seed);est=Estimator(m,n_grid=7500)
        for scenario in ['clean_slow','transient_glint','sustained_glint','clean_fast','attitude_step']:
            for trial in range(22):
                truth,glint,amp=sunlight_sequence(seed*10000+trial,scenario)
                (_, _),(codes,refs)=acquire(m,truth,np.random.default_rng(seed*10000+trial+930),lux=80,second=(glint,amp))
                direct,score,valid,brightness,_,_=est.estimate(codes,refs,'V3')
                base=valid&(brightness>24)
                bm,ex=rotated_b_field(truth,np.random.default_rng(seed*999+trial+91))
                diff=abs(angle(direct,bm)-ex)
                for threshold in [5,8,12,20]:
                    accepted=base&(diff<threshold)
                    mode=np.where(accepted,'direct_measured','invalid')
                    rows.append(dict(seed=seed,trial=trial,scenario=scenario,method=f'magnetic_gate_{threshold}deg',**metric(truth,direct,mode)))
    df=pd.DataFrame(rows)
    df.to_csv(R/'mag_runs.csv',index=False)
    s=df.groupby(['scenario','method'],as_index=False)[['available_pct','good5_pct','wrong10_pct','p95_valid_deg']].mean()
    s.to_csv(R/'mag_summary.csv',index=False)
    print(s.round(2).to_string(index=False))
if __name__=='__main__':run()
