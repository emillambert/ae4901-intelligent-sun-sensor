# AE4901 — sustained-glint mitigation feasibility study (22 November 2026)

**Scope:** Independent computational comparison of V8's calibrated 12-LDR synthetic model with (i) an IMU gyroscope prediction gate, and (ii) a separately simulated magnetometer + known geomagnetic/Sun relative angle gate. No LDR, gyro or magnetometer was tested physically. No claim of flight performance.

## Why V8 fails

V8's sustained glint starts after 13 of 40 frames and continues for ~27 samples. In the ideal cosine limit, two illumination sources illuminating the same set of detectors can be exactly indistinguishable from a single intensity-weighted direction. A temporal gate using only past LDR vectors eventually accepts a persistent false source. More sophisticated fitting of the same instantaneous data cannot guarantee recovery.

## Candidate 1: gyro-aided prediction

Independent synthetic gyro readings are computed from true simulated spacecraft motion, then **independent additive bias and white noise** are injected before the estimation algorithm uses them. The algorithm propagates the last accepted Sun direction; if a new LDR direction differs from the gyro-predicted one by >7°, it suspends updating the direct Sun measurement and labels the output `propagated`. This is *not* a fresh Sun measurement. It needs a gyroscope, initial correct acquisition, and well-calibrated gyro bias. No gyro is supplied in the course kit.

The holdout comparison uses four synthetic LDR populations, 22 separate sequences per population per scenario; each sequence is 40 one-second frames. It reuses V8's original calibrated synthetic LDR model. Results from `summary.csv`:

- Sustained glint: wrong-accepted >10° 61.68% with V8 temporal gating; 0.00% with low-drift gyro (assumed bias 0.04°/s, per-axis noise 0.12° per sample); 0.14% with moderate-drift gyro (bias 0.25°/s, noise 0.18°/sample).
- Sustained glint: about 67.5% of reported values are **gyro predictions, not verified LDR Sun measurements**.
- Sustained glint: fraction reported and within 5° is 100% (low-drift) or 82.76% (moderate-drift) in this synthetic 40-second test.
- Uncontaminated fast-tumble/attitude-step scenarios remain available in this test, but angular steps and roll are idealized. Gyro noise, scale error, thermal drift, misalignment, timing, and true 3D attitude have not been fully modeled.

**Do not extrapolate short-term performance to several minutes.** `long_duration_test.py` adopts a conservative 40-second maximum gyro-only propagation horizon after which it declares the Sun vector invalid unless an independent reference becomes available. For a 300-second sequence containing a 200-second glint, low-drift results are ~47.1% total time accepted, ~52.9% invalid, and 0.22% wrong-accepted >10°. A high uncalibrated gyro bias of 0.8°/s produces 12.21% wrong-accepted even with 40-second cut-off. Do not automatically reacquire from the same contaminated LDRs after the gyro prediction expires.

## Candidate 2: magnetometer + external orbit/field reference

The physically valid test is an invariant: `s_body · b_body = s_inertial · b_inertial`. A magnetometer alone is insufficient: it must be paired with known spacecraft position/time, a magnetic-field model, and Sun ephemeris. This gate can **reject** geometrically inconsistent false Sun vectors; it does not itself recover the true direction.

The synthetic magnetic model adds an illustrative ~2° random magnetic direction error and ~3° error to the predicted Sun–magnetic-field angle. An 8° consistency threshold gave:

- Sustained-glint wrong-accepted >10°: 20.06% of frames, versus V8's 61.68%, while retaining 98.10% of correct-within-5° observations under normal sunlight.
- A 5° threshold reduced glint wrong-accepted to 12.90% but reduced normal correct acceptance to 87.47%.
- A 12° threshold accepted 29.46% wrong glint results but retained 99.72% clean valid results.

**This is a sensitivity experiment, not an optimized spacecraft ADCS.** In a real implementation B/ephemeris geometry can make the angle invariant weak, geomagnetic-model quality varies by orbit/field, and magnetometer measurements are vulnerable to spacecraft magnetic interference.

## Engineering recommendations

1. **No new hardware (course baseline):** keep V8 LDR consistency, calibrated illumination and eclipse detection; use temporal warnings conservatively; explicitly return `GLINT_SUSPECT/INVALID` rather than a false vector. There is no assured software-only solution for sustained coherent glints.
2. **One inexpensive new sensor (if permitted):** add a calibrated 3-axis gyroscope and output `MEASURED/PROPAGATED/INVALID` with age and uncertainty. A gyro is effective only over a bounded time since the last trusted optical acquisition. Mount/time-sync and calibration matter.
3. **Real LEO albedo rejection:** add a three-axis magnetometer and a simulated/real orbit + geomagnetic + solar ephemeris to verify candidates, or adopt an attitude filter that uses these independent vectors. Costs more integration than LDR-only.
4. **If long-lasting strong specular glints must be accurately resolved:** use an independent angular optical sensor (quadrant/pinhole digital Sun sensor or camera) and test it against albedo. Narrow FOVs and housing may limit continuous full-sphere acquisition.
5. **Before adding hardware:** rerun scenarios with distributed Earth-disk albedo (not only one fixed-direction 80%-intensity body-frame source), natural illumination and calibrated LDR spectral/angle responses. The 61.7% is *not* a real-world fraction of orbital observations.

## Reproduce

```bash
pip install numpy scipy pandas matplotlib
python gyro_fusion_test.py
python mag_gate_study.py
python long_duration_test.py
python make_summary_figure.py
```

The included `v8_reference/` folder contains the required V8 synthetic-data generator and V7 model/estimator sources so that the study runs independently of the original V8 folder.

### Relevant published references
- NASA small spacecraft GNC: https://www.nasa.gov/smallsat-institute/sst-soa/guidance-navigation-and-control/
- Sun direction determination improvement by albedo input estimation combining photodiodes and magnetometer: https://www.sciencedirect.com/science/article/pii/S0094576521005142
- HERMES attitude architecture: https://pmc.ncbi.nlm.nih.gov/articles/PMC10007507/
- EIVE attitude control sensor albedo issue: https://link.springer.com/article/10.1007/s12567-024-00559-7
