"""Independent V8-like synthetic test: check if a separate gyro measurement can
reduce false accepted sustained-glint Sun vectors. NOT a physical demonstration.

The gyro signal is separately generated from simulated true body motion, then
noisy/bias perturbed before entering the filter. Truth only used by the synthetic
sensor generators and final scoring.
"""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation
R=Path(__file__).resolve().parent
V8=R/'v8_reference';sys.path.insert(0,str(V8))
from v8_temporal_study import Model,Estimator,acquire, sunlight_sequence,adaptive_monitor,angular, ang

def vec_gyro_sequence(truth, rng, bias_deg_per_sec, noise_deg_per_sec):
    # One-second readings; minimal rotation from truth[t-1] to truth[t]
    # (matches these synthetic trajectories' attitude changes up to roll).
    gyro=[]
    axis=rng.normal(size=3);axis/=np.linalg.norm(axis)
    bias=axis*np.deg2rad(bias_deg_per_sec)
    for prev,nxt in zip(truth[:-1],truth[1:]):
        cross=np.cross(prev,nxt)
        sin=np.linalg.norm(cross)
        step=np.arctan2(sin,np.clip(np.dot(prev,nxt),-1,1))
        rotvec=cross/sin*step if sin>1e-12 else np.zeros(3)
        rotvec+=bias+rng.normal(0,np.deg2rad(noise_deg_per_sec),3)
        gyro.append(rotvec)
    return np.array(gyro)

def gyro_guard(pred,base,omega,gate_deg=7.0,max_predict_seconds=40,gyro_uncertainty_budget_deg=8.0,bias_uncertainty_deg_s=0.10,gyro_white_noise_deg_s=0.18):
    """Propagate previously accepted estimate using only gyro sensor increments.

    Output modes are direct_measured / propagated / invalid. 'propagated' is NOT a
    new Sun measurement. Rejected observations do not secretly become valid.
    """
    n=len(pred)
    result=np.full_like(pred,np.nan)
    mode=np.full(n,'invalid',dtype='<U20')
    propagated_age=0
    for t in range(n):
        if t==0:
            if base[t]:result[t]=pred[t];mode[t]='direct_measured'
            continue
        if np.all(np.isfinite(result[t-1])):
            forecast=Rotation.from_rotvec(omega[t-1]).apply(result[t-1])
            forecast/=np.linalg.norm(forecast)
        else:forecast=None
        if forecast is None:
            if base[t]:result[t]=pred[t];mode[t]='direct_measured';propagated_age=0
            continue
        diff=ang(forecast,pred[t]) if base[t] else np.inf
        if base[t] and diff<=gate_deg:
            # Re-anchor to observed Sun direction when consistent with gyro.
            # partial blending reduces undue anchoring to tiny coherent contamination.
            new=0.7*forecast+0.3*pred[t]
            result[t]=new/np.linalg.norm(new)
            mode[t]='direct_measured';propagated_age=0
        else:
            propagated_age+=1
            # An actual implementation should increase uncertainty according to measured
            # gyro noise/bias calibration; these values are illustrative.
            sigma=np.sqrt((gyro_white_noise_deg_s**2)*propagated_age+ (bias_uncertainty_deg_s*propagated_age)**2)
            if propagated_age<=max_predict_seconds and sigma<gyro_uncertainty_budget_deg:
                result[t]=forecast;mode[t]='propagated'
    return result,mode

def metric(truth,pred,mode):
    err=angular(np.nan_to_num(pred,nan=0),truth)
    direct=mode=='direct_measured';prop=mode=='propagated';allgood=direct|prop
    return dict(direct_pct=round(100*np.mean(direct),2),gyro_propagated_pct=round(100*np.mean(prop),2),
                available_pct=round(100*np.mean(allgood),2),
                good5_pct=round(100*np.mean(allgood&(err<=5)),2),
                wrong10_pct=round(100*np.mean(allgood&(err>10)),2),
                p95_valid_deg=round(float(np.percentile(err[allgood],95)),2) if np.any(allgood) else np.nan)

def run():
    rows=[]
    for seed in range(221,225):
        m=Model(seed);est=Estimator(m,n_grid=7500)
        for scenario in ['clean_slow','transient_glint','sustained_glint','clean_fast','attitude_step']:
            for trial in range(22):
                truth,glint,amp=sunlight_sequence(seed*10000+trial,scenario)
                (_, _),(codes,refs)=acquire(m,truth,np.random.default_rng(seed*10000+trial+930),lux=80,second=(glint,amp))
                direct,score,valid,brightness,_,_=est.estimate(codes,refs,'V3')
                base=valid&(brightness>24)
                V8_gate,_=adaptive_monitor(direct,base)
                for name,dirs,mode in [
                    ('V8_no_gyro',direct,np.where(base,'direct_measured','invalid')),
                    ('V8_temporal_gate',direct,np.where(base&V8_gate,'direct_measured','invalid'))]:
                    rows.append(dict(seed=seed,trial=trial,scenario=scenario,method=name,**metric(truth,dirs,mode)))
                for gyro_profile,bias,noise in [('low_drift',.04,.12),('moderate_drift',.25,.18)]:
                    omega=vec_gyro_sequence(truth,np.random.default_rng(seed*30000+trial+989),bias,noise)
                    dirs,mode=gyro_guard(direct,base,omega,bias_uncertainty_deg_s=max(bias,.10),gyro_white_noise_deg_s=max(noise,.18))
                    rows.append(dict(seed=seed,trial=trial,scenario=scenario,method='gyro_'+gyro_profile,**metric(truth,dirs,mode)))
    df=pd.DataFrame(rows)
    df.to_csv(R/'runs.csv',index=False)
    summary=df.groupby(['scenario','method'],as_index=False)[['direct_pct','gyro_propagated_pct','available_pct','good5_pct','wrong10_pct','p95_valid_deg']].mean()
    summary.to_csv(R/'summary.csv',index=False)
    print(summary.round(2).to_string(index=False))
    return summary

if __name__=='__main__':run()
