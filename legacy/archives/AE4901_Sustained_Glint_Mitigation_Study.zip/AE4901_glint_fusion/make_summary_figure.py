from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
s=pd.read_csv(R/'summary.csv');m=pd.read_csv(R/'mag_summary.csv')
rows=s[s.scenario=='sustained_glint'].set_index('method')
mrows=m[m.scenario=='sustained_glint'].set_index('method')
labels=['V8 temporal','Gyro low drift','Gyro moderate drift','Magnetometer 8° gate']
wrong=[rows.loc['V8_temporal_gate','wrong10_pct'],rows.loc['gyro_low_drift','wrong10_pct'],rows.loc['gyro_moderate_drift','wrong10_pct'],mrows.loc['magnetic_gate_8deg','wrong10_pct']]
good=[rows.loc['V8_temporal_gate','good5_pct'],rows.loc['gyro_low_drift','good5_pct'],rows.loc['gyro_moderate_drift','good5_pct'],mrows.loc['magnetic_gate_8deg','good5_pct']]
fig,ax=plt.subplots(figsize=(9,4.7)); x=range(len(labels)); ax.bar(x,wrong,label='Wrong (>10°), accepted');ax.bar(x,good,bottom=wrong,label='Accurate (≤5°), accepted',alpha=0.45)
ax.set_ylim(0,105);ax.set_ylabel('Share of all simulated frames (%)');ax.set_xticks(list(x),labels,rotation=13,ha='right');ax.legend();ax.grid(axis='y',alpha=.2)
fig.suptitle('Sustained-glint rejection with independent information (synthetic 40 s tests)');fig.tight_layout();fig.savefig(R/'sustained_glint_tradeoff.png',dpi=160)
