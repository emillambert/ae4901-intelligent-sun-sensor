from pathlib import Path
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent
f=pd.read_csv(O/'temporal_heldout_summary.csv')
order=['clean_slow','transient_glint','sustained_glint','clean_fast','attitude_step']
labels=['Clean / slow','Brief glint','Sustained glint','Fast tumble','Real attitude step']
fig,ax=plt.subplots(figsize=(9,4.3))
x=np.arange(len(order));w=.37
for j,(method,label) in enumerate([('calibrated_no_temporal_gate','Calibrated estimator'),('V8_adaptive_temporal_gate','+ Adaptive temporal gate')]):
 vals=[float(f[(f.scenario==s)&(f.method==method)].wrong10_pct.iloc[0]) for s in order]
 ax.bar(x+(j-.5)*w,vals,w,label=label)
ax.set_xticks(x,labels,rotation=10);ax.set_ylabel('Accepted but wrong (>10°), % of all frames');ax.set_title('Independent holdout: strong reflected-light tests');ax.legend(loc='upper left');ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(O/'v8_wrong_accepted.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(9,4.3))
for j,(method,label) in enumerate([('calibrated_no_temporal_gate','Calibrated estimator'),('V8_adaptive_temporal_gate','+ Adaptive temporal gate')]):
 vals=[float(f[(f.scenario==s)&(f.method==method)].good5_pct.iloc[0]) for s in order]
 ax.bar(x+(j-.5)*w,vals,w,label=label)
ax.set_xticks(x,labels,rotation=10);ax.set_ylabel('Accepted and within 5°, % of all frames');ax.set_ylim(0,105);ax.set_title('Independent holdout: usable estimates');ax.legend(loc='lower left');ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(O/'v8_usable_estimates.png',dpi=180);plt.close(fig)
