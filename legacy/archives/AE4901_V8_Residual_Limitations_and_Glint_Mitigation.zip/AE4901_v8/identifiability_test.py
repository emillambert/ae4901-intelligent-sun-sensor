"""Analytical counterexample for ambiguous scalar cosine sensors. The two
illuminants are both within one active face set, so the summed 12-sensor
pattern equals that of one virtual source exactly, if unknown brightness is
allowed. This illustrates nonidentifiability, NOT typical glint prevalence.
"""
from pathlib import Path
import sys,numpy as np,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'/'AE4901_v7'/'reference'))
from engineering_study import N,PHYS
unit=lambda v:np.asarray(v,float)/np.linalg.norm(v)
sun=unit([.62,.56,.55]); glint=unit([.37,.81,.45]);strength=.8
face_s=(PHYS@sun)>0; face_g=(PHYS@glint)>0
sensor_s=(N@sun)>0; sensor_g=(N@glint)>0
assert (face_s==face_g).all() and (sensor_s==sensor_g).all(), 'Chosen counterexample does not share active set'
def resp(s):return np.maximum(0,N@s)*((PHYS@s)>0)
y=resp(sun)+strength*resp(glint)
virtual=sun+strength*glint
yeq=np.linalg.norm(virtual)*resp(unit(virtual))
err=float(np.degrees(np.arccos(np.clip(np.dot(unit(virtual),sun),-1,1))))
result=dict(sun=sun.tolist(),glint=glint.tolist(),glint_sun_angle_deg=float(np.degrees(np.arccos(np.dot(sun,glint)))),glint_strength_ratio=strength,apparent_direction=unit(virtual).tolist(),apparent_sun_error_deg=err,max_normalized_measurement_difference=float(np.max(np.abs(y-yeq))))
(HERE/'identifiability_counterexample.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
