import sys,unittest,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from v8_temporal_study import adaptive_monitor,unit
from identifiability_test import resp,sun,glint,strength
class V8Tests(unittest.TestCase):
    def test_alias_same_12_readings(self):
        v=sun+strength*glint
        self.assertLess(np.max(np.abs(resp(sun)+strength*resp(glint)-np.linalg.norm(v)*resp(unit(v)))),1e-12)
    def test_no_rejection_stable(self):
        dirs=np.tile(unit(np.array([.4,.5,.7])),(40,1))
        ok,state=adaptive_monitor(dirs,np.ones(40,bool))
        self.assertTrue(ok.all())
    def test_single_jump_rejected(self):
        a=unit(np.array([.4,.5,.7]));b=unit(np.array([-.6,.5,.7]))
        seq=np.tile(a,(40,1));seq[21]=b
        ok,_=adaptive_monitor(seq,np.ones(40,bool))
        self.assertFalse(ok[21]);self.assertTrue(ok[22])
    def test_true_new_direction_reacquires(self):
        a=unit(np.array([.4,.5,.7]));b=unit(np.array([-.6,.5,.7]))
        seq=np.tile(a,(40,1));seq[20:]=b
        ok,_=adaptive_monitor(seq,np.ones(40,bool))
        self.assertFalse(ok[20]);self.assertFalse(ok[21]);self.assertTrue(ok[22])
    def test_invalid_not_recycled_as_valid(self):
        dirs=np.tile(unit(np.array([.4,.5,.7])),(40,1))
        valid=np.ones(40,bool);valid[20:23]=False
        ok,_=adaptive_monitor(dirs,valid)
        self.assertFalse(ok[20:23].any())
if __name__=='__main__':unittest.main()
