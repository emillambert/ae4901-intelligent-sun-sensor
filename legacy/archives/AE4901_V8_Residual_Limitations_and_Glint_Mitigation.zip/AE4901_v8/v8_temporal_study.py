"""AE4901 V8: Causal, conservative transient-glint monitor.

This is a synthetic comparison, not flight qualification. Uses the V7 archive's
UNCHANGED reference LDR/ADC forward model and V3 calibrated estimator.
Explicitly keeps invalid frames invalid: no stale vector is counted as accepted.
"""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent/'source'/'AE4901_v7'/'reference'
sys.path.insert(0,str(R))
from engineering_study import Model, resp, angular
from validate_v3 import Estimator,acquire

HERE=Path(__file__).resolve().parent

def unit(x): return x / np.linalg.norm(x,axis=-1,keepdims=True)
def rotate(v,axis,deg):
    t=np.deg2rad(deg); return unit(v*np.cos(t)+np.cross(axis,v)*np.sin(t)+axis*np.dot(axis,v)*(1-np.cos(t)))
def ang(a,b): return np.rad2deg(np.arccos(np.clip(np.dot(a,b),-1,1)))

def sunlight_sequence(seed,scenario,T=40):
    rng=np.random.default_rng(seed)
    s0=unit(rng.normal(size=3));axis=unit(rng.normal(size=3))
    if abs(np.dot(s0,axis))>.85:axis=unit(np.cross(s0,[1,0,0]) if abs(s0[0])<.8 else np.cross(s0,[0,1,0]))
    rate={'clean_slow':.8,'transient_glint':.8,'sustained_glint':.8,'clean_fast':13.,'attitude_step':.8}[scenario]
    truth=np.array([rotate(s0,axis,rate*t+(38. if scenario=='attitude_step' and t>=T//2 else 0)) for t in range(T)])
    amp=np.zeros(T)
    if scenario=='transient_glint':amp[T//3:T//3+4]=.8
    if scenario=='sustained_glint':amp[T//3:]=.8
    # Interfering source fixed in spacecraft body coordinates; if it becomes weak in all faces it will not confuse estimate.
    # Direction chosen with separation from nominal Sun at the start of the event.
    at=truth[T//3]; perp=unit(rng.normal(size=3));perp=unit(perp-at*np.dot(perp,at))
    glint=unit(.55*at+.835*perp)
    return truth,glint,amp

def adaptive_monitor(vectors,base_accept,innovation_floor=6.0,rate_multiplier=2.5,stable_frames=3):
    """Uses only previously accepted vectors; no ground-truth data.

    A suspicious step gets rejected, unless multiple consistent frames agree
    on a new direction; then reacquire. Allows genuine fast motion if preexisting
    movement was similar. No protection against a persistent false illumination.
    """
    accepted=np.zeros(len(vectors),bool)
    reasons=[]
    history=[]
    proposal=[]
    for t,x in enumerate(vectors):
        if not base_accept[t] or not np.all(np.isfinite(x)):
            proposal=[];reasons.append('base_invalid');continue
        if len(history)<3:
            accepted[t]=True;history.append(x.copy());reasons.append('initial_acquire');continue
        rate=np.median([ang(history[-k-1],history[-k]) for k in (1,2)])
        allowed=max(innovation_floor,rate_multiplier*rate+2)
        delta=ang(x,history[-1])
        if delta<=allowed:
            accepted[t]=True;history.append(x.copy());proposal=[];reasons.append('tracked');continue
        # Candidate is only accepted after multiple consecutive mutually consistent samples.
        if proposal and ang(x,proposal[-1])<max(6,allowed):
            proposal.append(x.copy())
        else:
            proposal=[x.copy()]
        if len(proposal)>=stable_frames:
            accepted[t]=True;history.append(x.copy());proposal=[];reasons.append('reacquired')
        else:
            reasons.append('suspect_jump')
    return accepted,np.array(reasons)

def metric(truth,pred,accept):
    err=angular(pred,truth)
    n=len(err);accepted=accept&np.isfinite(err)
    return dict(n=n,accepted_pct=100*np.mean(accepted),good5_pct=100*np.mean(accepted&(err<=5)),
                wrong10_pct=100*np.mean(accepted&(err>10)),
                p95_accepted_deg=float(np.quantile(err[accepted],.95)) if accepted.any() else np.nan)

def run(seeds=range(121,125),trials=22,suffix="development"):
    rows=[]
    for sd in seeds:
        m=Model(sd);est=Estimator(m,n_grid=7500)
        for scen in ['clean_slow','transient_glint','sustained_glint','clean_fast','attitude_step']:
            for q in range(trials):
                s,g,a=sunlight_sequence(sd*10000+q,scen)
                (c0,r0),(codes,refs)=acquire(m,s,np.random.default_rng(sd*10000+q+930),lux=80,second=(g,a))
                pred,score,valid,brightness,_,_=est.estimate(codes,refs,'V3')
                # Brightness threshold ~0.3*80 lux effective, not a flight-calibrated solar threshold.
                base=valid&(brightness>24)
                new,reasons=adaptive_monitor(pred,base)
                for name,mask in [('calibrated_no_temporal_gate',base),('V8_adaptive_temporal_gate',base&new)]:
                    rows.append(dict(seed=sd,trial=q,scenario=scen,method=name,**metric(s,pred,mask)))
        print('completed population',sd,flush=True)
    df=pd.DataFrame(rows);df.to_csv(HERE/f'temporal_{suffix}_runs.csv',index=False)
    # Micro averages of outcomes by equal-size sequences; p95 is average of each 40-frame batch, not pooled globally.
    smry=df.groupby(['scenario','method'],as_index=False).agg(accepted_pct=('accepted_pct','mean'),good5_pct=('good5_pct','mean'),wrong10_pct=('wrong10_pct','mean'),p95_accepted_deg=('p95_accepted_deg','mean'))
    smry.to_csv(HERE/f'temporal_{suffix}_summary.csv',index=False)
    print(smry.round(2).to_string(index=False))
    return smry
if __name__=='__main__':
    run(suffix='development')
    run(seeds=range(221,225),suffix='heldout')
