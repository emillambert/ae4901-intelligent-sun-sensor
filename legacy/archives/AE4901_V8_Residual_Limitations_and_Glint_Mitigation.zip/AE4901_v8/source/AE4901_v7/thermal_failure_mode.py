#!/usr/bin/env python3
"""Negative control: assumed temperature coefficients can be actively harmful.
Uses same V7 synthetic thermal forward model and independently inaccurate calibration.
"""
import sys
from pathlib import Path
import numpy as np, pandas as pd
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from v7_study import Model,Estimator,sphere,make_thermal_adc,estimate_new,angular
rows=[]
for seed in (1601,1602,1603,1604):
    m=Model(seed);rng=np.random.default_rng(seed*9);dirs=sphere(400,.311)
    k=rng.normal(.004,.0018,12)*rng.choice([-1,1],12)
    dp=rng.normal(.0015,.0006,12)*rng.choice([-1,1],12)
    temp=55
    code,ref=make_thermal_adc(m,dirs,np.random.default_rng(seed+temp*11),np.full(len(dirs),temp),k,dp)
    m0_r,m0_p=m.est_r10.copy(),m.est_p.copy()
    for lab,sign in [('stale_ground_calibration',0),('correct_sign_thermal_calibration',1),('WRONG_SIGN_thermal_calibration',-1)]:
        m.est_r10=m0_r*np.exp((temp-20)*sign*k)
        m.est_p=np.clip(m0_p+(temp-20)*sign*dp,.6,2)
        e=Estimator(m,n_grid=4100)
        z=estimate_new(m,e,code,ref,mode='common',robust=True)
        err=angular(z['s'],dirs)
        rows.append(dict(seed=seed,method=lab,p95=float(np.percentile(err,95)),within5=float(100*np.mean(err<=5))))
f=pd.DataFrame(rows);f.to_csv(HERE/'thermal_failure_mode.csv',index=False)
print(f.groupby('method')[['p95','within5']].mean().round(2))
