import unittest, tempfile
from pathlib import Path
import numpy as np, pandas as pd
from health_and_drift import packet,decode,DriftGuard,crc16_ccitt
from calibrate_ldr import create_synthetic_example,validate_and_fit
from v7_study import independent_attitude_prior,unit
class TestV7(unittest.TestCase):
    def test_crc_standard_check(self):
        self.assertEqual(crc16_ccitt(b'123456789'),0x29B1)
    def test_packet_round_trip(self):
        self.assertEqual(decode(packet(1,65535,[1,10,50,100,999,1023],7))['adc'][4],999)
    def test_packet_corruption(self):
        payload=bytearray(packet(0,1,[0]*6));payload[4]^=32
        with self.assertRaises(ValueError):decode(bytes(payload))
    def test_packet_sanity(self):
        with self.assertRaises(ValueError):packet(2,1,[1]*6)
    def test_drift_monitor_is_conservative(self):
        d=DriftGuard()
        s=None
        for k in range(70):
            v=np.zeros(12);v[4]=5
            s=d.update(v,np.ones(12,bool))
        self.assertEqual(s.state,'CHANNEL_DRIFT_SUSPECT')
        self.assertIn(4,s.suspect_channels)
    def test_coherent_glint_freezes(self):
        d=DriftGuard()
        s=d.update(np.array([5]*6+[0]*6),np.ones(12,bool))
        self.assertEqual(s.state,'LIGHTING_OR_MODEL_SUSPECT')
        self.assertEqual(d.n.sum(),0)
    def test_monitor_pauses_without_two_controllers(self):
        d=DriftGuard();s=d.update(np.zeros(12),np.ones(12,bool),controllers=1)
        self.assertEqual(s.state,'MONITOR_PAUSED')
    def test_synthetic_calibration_train_test(self):
        with tempfile.TemporaryDirectory() as p:
            f=Path(p)/'synth.csv';create_synthetic_example(f)
            fit,score=validate_and_fit(f,Path(p)/'out')
            self.assertEqual(len(fit),12)
            self.assertTrue((score[score.split=='test'].model_p95_relative_error_pct<8).all())
    def test_external_prior_separate_noise(self):
        s=np.tile(np.array([1.,0,0]),(3000,1))
        p=independent_attitude_prior(s,np.random.default_rng(9),std_deg=3)
        self.assertGreater(np.mean(np.arccos(np.clip(np.einsum('ni,ni->n',p,s),-1,1))),0)
        self.assertTrue(np.allclose(np.linalg.norm(p,axis=1),1))
if __name__=='__main__':unittest.main()
