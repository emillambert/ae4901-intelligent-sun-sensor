#!/usr/bin/env python3
"""AE4901 V4 algorithm investigation. Synthetic only; NO measured GL5537 LDRs.

Compare against V3 on identical ADC measurements; signal and optical disturbances
are injected by legacy V3 independent forward model. No calibration uses held-out
true Sun directions. Improvements do not constitute laboratory validation.
"""
from pathlib import Path
import sys, json, math, time
sys.path.insert(0,str(Path(__file__).resolve().parent/'reference_v3'))
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from engineering_study import Model, sphere, resp, angular, N, PHYS, BOARD
from validate_v3 import Estimator, acquire, recover, optical_and_jac, tangent_basis

OUT=Path(__file__).resolve().parent
C=np.column_stack((np.ones(12),PHYS))


def fit_model(y, clipped, s_init, p, mode='common', robust=True, steps=6):
    """Joint sunlight direction, source scale and additive ambient nuisance.

    mode: 'common' models 1 extra diffuse ambient scalar; 'spatial' models
    a diffuse ambient intercept and 3 gradients across physical cube normals.
    IRLS Huber helps resist a single corrupted sensor. Ridge priors on
    ambient reflect that it is not identifiable arbitrarily from one frame.
    """
    n=len(y)
    signal=np.nan_to_num(y,nan=0.,posinf=0.,neginf=0.)
    keep=(~clipped)&np.isfinite(y)
    mat=C[:,:1] if mode=='common' else C
    k=mat.shape[1]
    s=s_init.copy(); s/=np.linalg.norm(s,axis=1)[:,None]
    a=np.maximum(np.nanmax(signal,axis=1),1.)
    b=np.zeros((n,k))
    noise=1.4 + .027*np.maximum(signal,0.)
    prior_sd=np.array([6.]+[3.]*3)[:k]
    prior_precision=1/np.maximum(prior_sd,1e-6)**2
    for _ in range(steps):
        pat,J3=optical_and_jac(s,p)
        prediction=a[:,None]*pat+b@mat.T
        residual=signal-prediction
        inv_noise=1/noise
        if robust:
            z=np.abs(residual)*inv_noise
            hub=np.minimum(1.,2.7/np.maximum(z,1e-12))
        else:hub=np.ones_like(residual)
        w2=keep*hub*inv_noise**2
        u,v=tangent_basis(s)
        uder=a[:,None]*np.einsum('nki,ni->nk',J3,u)
        vder=a[:,None]*np.einsum('nki,ni->nk',J3,v)
        J=np.concatenate((pat[:,:,None],np.broadcast_to(mat,(n,12,k)), uder[:,:,None],vder[:,:,None]),axis=2)
        H=np.einsum('nij,nik,ni->njk',J,J,w2)
        g=np.einsum('nij,ni,ni->nj',J,residual,w2)
        # Ridge penalization on nuisance ambient relative to pre-calibrated per-channel ambient.
        for idx in range(k):
            H[:,1+idx,1+idx]+=prior_precision[idx]
            g[:,1+idx]-=b[:,idx]*prior_precision[idx]
        H+=np.diag([.0001]+[.0001]*k+[.06,.06])[None,:,:]
        d=np.linalg.solve(H,g[:,:,None])[:,:,0]
        a=np.clip(a+np.clip(d[:,0],-35,35),0,1e5)
        b=np.clip(b+np.clip(d[:,1:1+k],-4,4),-15,15)
        s+=np.clip(d[:,-2],-.12,.12)[:,None]*u+np.clip(d[:,-1],-.12,.12)[:,None]*v
        s/=np.linalg.norm(s,axis=1)[:,None]
    pat,_=optical_and_jac(s,p)
    prediction=a[:,None]*pat+b@mat.T
    residual=signal-prediction
    std_res=residual/noise
    errnorm=np.sqrt((keep*std_res**2).sum(axis=1)/np.maximum(keep.sum(axis=1),1))
    # Diagnostic channel: largest remaining standardized mismatch, raw residual and model goodness.
    absres=np.abs(std_res);absres[~keep]=0
    bad=absres.argmax(axis=1)
    return s,errnorm,a,b,bad,absres,pat,prediction


def estimate_new(m,old,codes,refs,boardlost=None,mode='common',robust=True):
    y,clip=recover(m,codes,refs,cal=True,keep_negative=True)
    live=np.ones(12,bool) if boardlost is None else BOARD!=boardlost
    clip[:,~live]=True
    s0,_,_,_,_,_=old.estimate(codes,refs,'V3',boardlost=boardlost)
    s,r,a,b,bad,ares,pat,pred=fit_model(y,clip,s0,m.est_p,mode=mode,robust=robust)
    valid=(~clip).sum(axis=1)>=3
    return dict(s=s,score=r,valid=valid,amp=a,b=b,bad=bad,ares=ares,raw=y,clip=clip,pat=pat,pred=pred)


def fault_recover(m,old,codes,refs):
    """Robust direction + capped per-channel downweighting, no unjustified recovery claims.
    Identify a single suspect if residual is well separated, refit excluding it,
    but separately track a strict reliability gate. Can only *suspect* a failure,
    never guarantee fault ID from one static snapshot.
    """
    start=estimate_new(m,old,codes,refs,mode='common',robust=True)
    j=start['bad'];ares=start['ares']
    sorted_res=np.sort(ares,axis=1)
    # Thresholds are predeclared engineering hypotheses, not trained classifiers.
    candidate=(sorted_res[:,-1]>6.)&(sorted_res[:,-1]>2.4*np.maximum(sorted_res[:,-2],.5))
    if candidate.any():
        rows=np.where(candidate)[0]
        mask=start['clip'][rows].copy();mask[np.arange(len(rows)),j[rows]]=True
        s,r,a,b,which,res,p,pred=fit_model(start['raw'][rows],mask,start['s'][rows],m.est_p,mode='common',robust=True,steps=8)
        improve=(r<1.7)&(r<.63*start['score'][rows])
        suc=rows[improve]
        start['s'][suc]=s[improve]
        start['score'][suc]=r[improve]
        start['bad'][suc]=j[suc]
    else: suc=np.empty(0,int)
    state=np.full(len(codes),'GOOD',object)
    state[start['score']>2.7]='UNTRUSTED'
    state[candidate]='SUSPECT'
    state[suc]='ISOLATED_PROVISIONAL'
    # A suspected fault can be trusted for display but not for autonomous pointing.
    # Original data make it impossible to guarantee the suspect is the faulty sensor.
    trusted=np.isin(state,['GOOD','ISOLATED_PROVISIONAL'])
    return start, state, trusted, suc


def second_light_candidate(m,old,codes,refs,single,limit=2600):
    """Two-source detection experimental method.
    Given first direction, greedily fit second direction to calibrated *intensity*
    residual using independently seeded dictionary. Nonnegative coefficients.
    Detects some two-source cases but cannot label the Sun unambiguously.
    """
    y,clip=recover(m,codes,refs,cal=True,keep_negative=True)
    x=np.maximum(0,np.nan_to_num(y,nan=0))
    grid=sphere(limit,.326)
    patt=resp(grid,exponent=m.est_p)
    # Primary candidate from joint robust single-source estimation; estimate nuisance offset.
    p1=resp(single['s'],exponent=m.est_p)
    b=single['b'][:,0]
    yy=np.maximum(0,x-b[:,None])
    # k-residual is used to propose one second direction.
    a1=np.maximum(0,np.einsum('ni,ni->n',yy,p1)/(np.einsum('ni,ni->n',p1,p1)+1e-9))
    residual=yy-a1[:,None]*p1
    norms=np.maximum(np.linalg.norm(patt,axis=1),1e-7)
    scores=residual@(patt/norms[:,None]).T
    top=scores.argmax(axis=1)
    p2=patt[top]
    # NNLS for the two positive amplitudes, exact for unconstrained positive solution.
    aa=np.sum(p1*p1,axis=1);bb=np.sum(p2*p2,axis=1);cc=np.sum(p1*p2,axis=1)
    dy=np.sum(p1*yy,axis=1);ey=np.sum(p2*yy,axis=1)
    det=aa*bb-cc*cc
    A=np.maximum(0,np.where(det>1e-6,(dy*bb-ey*cc)/(det+1e-12),0))
    B=np.maximum(0,np.where(det>1e-6,(ey*aa-dy*cc)/(det+1e-12),0))
    bndry=(B<=0)|(A<=0)
    A=np.where(bndry,np.maximum(0,dy/(aa+1e-8)),A)
    B=np.where(bndry,0,B)
    fit1=np.sum((yy-a1[:,None]*p1)**2,axis=1)
    fit2=np.sum((yy-A[:,None]*p1-B[:,None]*p2)**2,axis=1)
    sep=angular(single['s'],grid[top])
    ratio=B/np.maximum(A,B+1e-9)
    improvement=(fit1-fit2)/np.maximum(fit1,1e-9)
    # gate requires positive, distinct second component and material reduction in residual
    suspect=(B>6)&(ratio>.12)&(sep>18)&(improvement>.47)
    return dict(suspect=suspect,sep_deg=sep,ratio=ratio,improvement=improvement,p1=single['s'],p2=grid[top],A=A,B=B)


def calc_metrics(est,sky,valid=None):
    if valid is None:valid=np.ones(len(sky),bool)
    er=angular(est,sky)
    return dict(p95_accepted=float(np.quantile(er[valid],.95)) if valid.any() else np.nan,
                median_accepted=float(np.median(er[valid])) if valid.any() else np.nan,
                p95_all=float(np.quantile(er,.95)),
                accepted_pct=100*valid.mean(),
                accepted_within5_pct=100*np.mean(valid&(er<=5)),
                wrong_accepted_gt5_pct=100*np.mean(valid&(er>5)))


def experiment(seeds=(701,702,703,704), n_dirs=650):
    sky=sphere(n_dirs,.43)
    sec=np.array([.49,-.24,.84]);sec/=np.linalg.norm(sec)
    scenarios={
      'normal_80lux':dict(lux=80),
      'dim_20lux':dict(lux=20),
      'bright_300lux':dict(lux=300),
      'high_10000lux_EXTRAPOLATED':dict(lux=10000),
      'common_background_4lux':dict(lux=80,ambient_shift=4),
      'nonuniform_background_1to7lux':dict(lux=80,transient_bg=np.linspace(1,7,12)),
      'angular_drift':dict(lux=80,ang_drift=True),
      'one_sensor_fault_40pct':dict(lux=80,fault=('cycle',.40)),
      'second_source_10pct':dict(lux=80,second=(sec,.1)),
      'second_source_30pct':dict(lux=80,second=(sec,.3)),
      'arduino_A_offline':dict(lux=80,lost=0),
      'arduino_B_offline':dict(lux=80,lost=1),
    }
    rows=[];diagnostics=[]
    for si,seed in enumerate(seeds):
        m=Model(seed);old=Estimator(m,n_grid=7000)
        for scen,args0 in scenarios.items():
            args=args0.copy()
            if args.pop('ang_drift',False):args['mismatch']=np.clip(m.p+.18*np.sin(np.arange(12)+.31),.6,1.9)
            rng=np.random.default_rng(177000+seed)
            (c5,r5),(ca,ra)=acquire(m,sky,rng,**args)
            lost=args.get('lost',None)
            s0,_,v0,_,_,_=old.estimate(ca,ra,'V3',boardlost=lost)
            oldraw=calc_metrics(s0,sky,v0)
            methods={'V3_previous':oldraw}
            trial=estimate_new(m,old,ca,ra,boardlost=lost,mode='common',robust=True)
            methods['V4_joint_bg_huber']=calc_metrics(trial['s'],sky,trial['valid'])
            spatial=estimate_new(m,old,ca,ra,boardlost=lost,mode='spatial',robust=True)
            methods['V4_spatial_bg_huber']=calc_metrics(spatial['s'],sky,spatial['valid'])
            if lost is None:
                fault,state,trusted,rec=fault_recover(m,old,ca,ra)
                methods['V4_fault_state_all']=calc_metrics(fault['s'],sky,fault['valid'])
                methods['V4_fault_state_trusted']=calc_metrics(fault['s'],sky,trusted)
                two=second_light_candidate(m,old,ca,ra,trial)
                methods['V4_multisource_reject']=calc_metrics(trial['s'],sky,trial['valid']&~two['suspect'])
                diagnostics.append(dict(seed=seed,scenario=scen,multisource_flag_pct=100*two['suspect'].mean(),
                                        fault_suspect_pct=100*np.mean(state=='SUSPECT'),
                                        fault_rescued_pct=100*np.mean(state=='ISOLATED_PROVISIONAL'),
                                        fault_reject_pct=100*np.mean(~trusted),
                                        fault_correct_id_pct=float(100*np.mean(fault['bad'][rec]==np.arange(len(sky))[rec]%12)) if len(rec) and scen=='one_sensor_fault_40pct' else np.nan))
            for name,vals in methods.items():rows.append(dict(seed=seed,scenario=scen,method=name,**vals))
        print(f'seed {seed} complete',flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(OUT/'full_results.csv',index=False)
    diag=pd.DataFrame(diagnostics);diag.to_csv(OUT/'diagnostics.csv',index=False)
    summary=frame.groupby(['scenario','method'],sort=False).median(numeric_only=True).reset_index().drop(columns='seed')
    summary.to_csv(OUT/'summary_median.csv',index=False)
    return frame,summary,diag

if __name__=='__main__':
    a,b,d=experiment()
    print(b.to_string(index=False))
