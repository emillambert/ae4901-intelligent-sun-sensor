#!/usr/bin/env python3
"""AE4901 V2 circuit/sensor/ambient/failover numerical design investigation.

NOT a hardware validation. All physical LDR angular, resistance and noise
properties beyond cited datasheet values are hypothetical sensitivity models.
The source includes self-shadowing, 6 physical faces, 12 axes +/-10 deg about
[1,1,1]. The synthetic calibration estimated per-channel electrical and
angular parameters; actual fitted calibration would replace them.
"""
import os, math, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

O=Path(__file__).resolve().parent
F=np.array([[1.,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]])
PHYS=np.repeat(F,2,axis=0)
BOARD=np.arange(12)%2

def rodrigues(k, theta):
    k=np.asarray(k,float);k/=np.linalg.norm(k)
    K=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
    t=np.deg2rad(theta)
    return np.eye(3)+np.sin(t)*K+(1-np.cos(t))*(K@K)
ROT=rodrigues([1.,1.,1.],10)
N=np.array([r@f for f in F for r in (ROT,ROT.T)])
assert np.allclose(N.T@N,4*np.eye(3),atol=1e-10)

def sphere(n, off=0):
    i=np.arange(n,dtype=float)+off
    z=1-2*(i+.5)/n
    t=i*np.pi*(3-np.sqrt(5))
    return np.stack((np.sqrt(np.maximum(0,1-z*z))*np.cos(t),
                     np.sqrt(np.maximum(0,1-z*z))*np.sin(t),z),axis=1)

def resp(s,normals=N,exponent=None):
    if exponent is None: exponent=np.ones(12)
    dots=np.maximum(s@normals.T,0)
    face=(s@PHYS.T)>0
    return dots**np.asarray(exponent)[None,:]*face

# voltage divider orientation: Vcc -> Rfixed -> ADC pin -> GL5537 LDR -> GND
# R(E) only characterized by gamma between ~10 and 100 lux.
R10_NOM=25000.
GAMMA_NOM=.6
FIX_NOM=30000.

def flux_to_r(flux,r10,gamma):
    return np.clip(r10[None,:]*(np.maximum(flux,0.01)/10)**(-gamma[None,:]), 10., 2e6)

def divider_voltage(rldr,rfixed,vcc):
    return vcc[None,:]*rldr/(rldr+rfixed[None,:])

def voltage_to_r(v,rfixed,vcc):
    return rfixed[None,:]*v/np.maximum(vcc[None,:]-v,1e-8)

def to_lux(r,r10,gamma):
    return 10*(r/r10[None,:])**(-1/np.asarray(gamma)[None,:])

class Model:
    def __init__(self,seed=7):
        rng=np.random.default_rng(seed)
        self.r10=rng.uniform(20000,30000,12)
        self.gamma=rng.normal(.60,.032,12).clip(.53,.67)
        self.p=rng.normal(1.15,.11,12).clip(.90,1.44) # hypothetical angular exponent
        self.ambient=np.maximum(0,rng.normal(1.5,.55,12))
        self.vcc=np.where(BOARD==0,4.94,5.06)
        self.aref=np.where(BOARD==0,1.07,1.14) # hypothetical AVRs in allowed range
        self.rfixed=np.full(12,FIX_NOM)
        # estimated calibration (not exact oracle), held fixed over validation
        self.est_r10=self.r10*(1+rng.normal(0,.02,12))
        self.est_gamma=self.gamma+rng.normal(0,.008,12)
        self.est_p=self.p+rng.normal(0,.035,12)
        self.est_bg=np.maximum(0,self.ambient+rng.normal(0,.25,12))
        self.est_vcc=self.vcc*(1+rng.normal(0,.003,12))
        self.est_aref=self.aref*(1+rng.normal(0,.006,12))
        self.est_ref_rfixed=self.rfixed

    def read(self,dirs,rng, source_lux=80., secondary=None, hot_channel=False,
             adc_mode='5V', fault_board=None, dark_drift=False):
        raw=source_lux*resp(dirs,exponent=self.p)
        if secondary is not None:
            vector,frac=secondary
            # second coherent directional source adds a physically indistinguishable component
            raw+=source_lux*frac*resp(np.repeat(np.asarray(vector)[None,:],len(dirs),axis=0),exponent=self.p)
        raw+=self.ambient[None,:]
        if dark_drift:
            raw+=rng.normal(0,.9,(len(dirs),12))
        if hot_channel:
            # Inject one local contaminated channel per sky direction, magnitude 40% primary flux
            ix=rng.integers(0,12,len(dirs));raw[np.arange(len(dirs)),ix]+=source_lux*.4
        raw=np.maximum(raw,0.02)
        # multiplicative incident light / circuit noise: *hypothetical*
        raw=np.maximum(raw*(1+rng.normal(0,.008,raw.shape)),.01)
        r=flux_to_r(raw,self.r10,self.gamma)
        v=divider_voltage(r,self.rfixed,self.vcc)
        references=np.broadcast_to(self.vcc,(len(dirs),12)).copy()
        if adc_mode=='auto':
            # First 5V sample used to decide; only reduce ref when voltage safely < ~1.0V.
            references=np.where(v<.98,self.aref[None,:],self.vcc[None,:])
        elif adc_mode!='5V': raise ValueError(adc_mode)
        # ADC code 10bit, 0.65 count gaussian noise (simulation), 1 quantization interval
        counts=np.clip(np.rint(1023*v/references+rng.normal(0,.65,v.shape)),0,1023)
        if fault_board is not None: counts[:,BOARD==fault_board]=np.nan
        return counts,references

    def recover(self, counts, references, method='nominal'):
        if method=='nominal':
            vv=np.where(np.isclose(references,self.vcc[None,:]),self.vcc[None,:], self.aref[None,:])
            vr=np.full(12,R10_NOM); gr=np.full(12,GAMMA_NOM)
            bg=np.zeros(12)
            fixed=np.full(12,FIX_NOM)
            vcc=np.full(12,5.)
            # count fraction under AVcc is ratiometric; code includes actual VCC
            # we use calibrated 5V ratio for nominal to avoid unfair supply artifact
            vcc=np.where(vv==self.vcc[None,:],self.vcc[None,:],5.)
        elif method=='calibrated':
            vv=np.where(np.isclose(references,self.vcc[None,:]),self.est_vcc[None,:],self.est_aref[None,:])
            vr=self.est_r10;gr=self.est_gamma;bg=self.est_bg;fixed=self.est_ref_rfixed
            vcc=self.est_vcc[None,:]
        else:raise ValueError(method)
        volts=(np.nan_to_num(counts,nan=0)/1023)*vv
        volts=np.maximum(volts,0.00001)
        rr=voltage_to_r(volts,fixed,np.broadcast_to(vcc,(len(volts),12))[0])
        flux=to_lux(rr,vr,gr)-bg[None,:]
        # clipped channels cannot supply reliable intensity
        flags=(np.nan_to_num(counts,nan=0)<2)|(np.nan_to_num(counts,nan=1023)>1021)|np.isnan(counts)
        flux=np.clip(flux,0,1e6)
        flux[flags]=0
        return flux,flags

class Matcher:
    def __init__(self, exponent, ngrid=24000, board=None):
        sky=sphere(ngrid,.171)
        pattern=resp(sky,exponent=exponent)
        if board is not None:pattern=pattern[:,BOARD==board]
        norms=np.linalg.norm(pattern,axis=1)
        pattern=pattern/(norms[:,None]+1e-12)
        self.sky=sky
        self.tree=cKDTree(pattern)
        self.pattern=pattern
        self.board=board
        # columns from full geometry, masked for individual board
        self.p=np.asarray(exponent)
    def query(self,signal,k=1):
        if self.board is not None:signal=signal[:,BOARD==self.board]
        norm=np.linalg.norm(signal,axis=1)
        x=signal/(norm[:,None]+1e-12)
        d,idx=self.tree.query(x,k=k)
        return self.sky[idx],d,idx

def angular(est,truth):
    return np.degrees(np.arccos(np.clip(np.einsum('ni,ni->n',est,truth),-1,1)))

def make_matchers(model):
    return {typ:Matcher(np.ones(12) if typ=='nominal' else model.est_p) for typ in ('nominal','calibrated')},\
        {b:Matcher(model.est_p,board=b) for b in (0,1)}

def robust_recover(flux,known,matcher):
    """Conservative single-channel leave-one-out fit; ambiguous cases flagged.

    Single-channel rejection only happens when 11 consistent channels have a
    clearly superior fit. This does NOT identify arbitrary or common-mode faults.
    The thresholds are engineering assumptions, not a calibrated FDI detector.
    """
    est,dist,_=matcher.query(flux)
    candidates=dist>.12
    isolated=np.zeros(len(flux),bool)
    suspect=np.zeros(len(flux),bool)
    if not candidates.any():return est,dist,isolated,suspect
    if not hasattr(matcher,'loo_trees'):
        base=resp(matcher.sky,exponent=known)
        matcher.loo_trees=[]
        for j in range(12):
            y=base[:,np.arange(12)!=j]
            y=y/(np.linalg.norm(y,axis=1)[:,None]+1e-12)
            matcher.loo_trees.append(cKDTree(y))
    rows=np.where(candidates)[0]
    y=flux[rows]
    all_d=[];all_idx=[]
    for j,tree in enumerate(matcher.loo_trees):
        yy=y[:,np.arange(12)!=j]
        yy=yy/(np.linalg.norm(yy,axis=1)[:,None]+1e-12)
        d,ix=tree.query(yy)
        all_d.append(d);all_idx.append(ix)
    scores=np.stack(all_d,axis=1)
    indices=np.stack(all_idx,axis=1)
    sortd=np.sort(scores,axis=1)
    bestj=np.argmin(scores,axis=1)
    best=sortd[:,0]
    # Strong evidence of exactly one abnormal channel. Otherwise do not claim recovery.
    support=(best<.11)&(best<.35*sortd[:,1])&(best<.55*dist[rows])
    rescued=rows[support]
    isolated[rescued]=True
    suspect[rows[~support]]=True
    est[rescued]=matcher.sky[indices[np.arange(len(rows))[support],bestj[support]]]
    dist[rescued]=best[support]
    return est,dist,isolated,suspect

def stats(err,valid,dist=None):
    e=err[valid]
    return dict(valid_pct=round(100*valid.mean(),2),
                med_deg=round(float(np.median(e)),3) if len(e) else np.nan,
                p95_deg=round(float(np.quantile(e,.95)),3) if len(e) else np.nan,
                p99_deg=round(float(np.quantile(e,.99)),3) if len(e) else np.nan,
                all_within5_pct=round(float(100*np.mean(valid&(err<=5))),2),
                failure_gt5_pct=round(float(100*np.mean(~valid |(err>5))),2))

def evaluate(model,dirs,rng,scenario,lookups,boards):
    name=scenario['name']
    sec=scenario.get('secondary')
    hot=scenario.get('hot_channel',False)
    bright=scenario.get('source_lux',80.)
    boardlost=scenario.get('board_offline')
    cache={}
    for admode in ('5V','auto'):
        counts,refs=model.read(dirs,rng,bright,sec,hot,admode,boardlost,scenario.get('dark_drift',False))
        for cal in ('nominal','calibrated'):
            if admode=='5V' and cal=='nominal': label='B0: nominal model + 5V ADC'
            elif admode=='5V' and cal=='calibrated':label='B1: per-sensor cal + 5V ADC'
            elif admode=='auto' and cal=='calibrated':label='B2: cal + auto ADC ref'
            else:continue
            flux,flags=model.recover(counts,refs,cal)
            matcher=lookups[cal] if boardlost is None else boards[1-boardlost]
            est,dist,_=matcher.query(flux)
            active=(BOARD!=boardlost) if boardlost is not None else np.ones(12,bool)
            valid=(np.linalg.norm(flux[:,active],axis=1)>1)&(np.sum(flags[:,active],axis=1)<len(active[active]))
            # quality threshold is diagnostic; default loose enough not to cherry-pick easy cases
            valid &= dist<.60
            err=angular(est,dirs)
            z=stats(err,valid)
            z.update(dict(scenario=name,approach=label,avg_adc_counts=round(float(np.nanmean(counts)),1),
                          avg_flags=round(float(np.mean(flags.sum(axis=1))),3),
                          fit_p95=round(float(np.quantile(dist,.95)),3)))
            cache[label]=(flux,est,dist,valid,err)
            yield z
    # Robust recovery only with both boards live and per-channel calibrated optical response
    if boardlost is None:
        flux,_,_,valid,err=cache['B2: cal + auto ADC ref']
        es,di,isolated,suspect=robust_recover(flux,model.est_p,lookups['calibrated'])
        # Never silently accept unisolated large inconsistency as a trusted Sun vector.
        va=valid&(di<.15)&(~suspect)
        z=stats(angular(es,dirs),va)
        z.update(dict(scenario=name,approach='B3: B2 + single-channel outlier recovery',
                      isolated_pct=round(float(100*np.mean(isolated)),2),
                      suspect_pct=round(float(100*np.mean(suspect)),2)))
        yield z

def divider_table():
    rows=[]
    for fixed in [30000.,100000.,1000000.,3000000.]:
        for lux in [1,10,100,1000,10000,100000]:
            resistance=25000*(lux/10)**(-.6)
            v=5*resistance/(resistance+fixed)
            q5=1023*v/5
            q1=1023*v/1.1
            qauto=q1 if v<.98 else q5
            # local 1 LSB (quantizer) converted into relative illuminance error
            ref=1.1 if v<.98 else 5.0
            step=ref/1023
            def f_v(vv):
                rr=fixed*vv/max(5-vv,1e-10)
                return 10*(rr/25000)**(-1/.6)
            eplus=f_v(min(v+step/2,4.999999))
            eminus=f_v(max(v-step/2,1e-8))
            halfspan=abs(eplus-eminus)/(2*lux)*100
            rows.append(dict(resistor_ohms=int(fixed),lux=lux,ldr_resistance_ohms=round(resistance,1),v_adc=round(v,4),
                             adc_5v_count=round(q5,1),adc_1p1_count=round(q1,1) if q1<1024 else None,
                             selected_vref=ref,adc_autoref_count=round(qauto,1),
                             half_lsb_light_pct=round(halfspan,3),
                             extrapolated=lux<10 or lux>100))
    return pd.DataFrame(rows)

def main():
    rng=np.random.default_rng(20261121)
    model=Model(701)
    lookup,board=make_matchers(model)
    # independent held-out orientations; not part of lookup tree
    dirs=sphere(2400,.487)
    secundir=np.array([.49,-.24,.84]);secundir/=np.linalg.norm(secundir)
    scenarios=[
       dict(name='80 lux single source / normal',source_lux=80.),
       dict(name='20 lux single source / dim',source_lux=20.),
       dict(name='300 lux single source / brighter',source_lux=300.),
       dict(name='1500 lux single source / strong (extrap.)',source_lux=1500.),
       dict(name='80 lux + calibration/background drift',source_lux=80.,dark_drift=True),
       dict(name='80 lux + 1 contaminated channel',source_lux=80.,hot_channel=True),
       dict(name='80 lux + 30% second directional source',source_lux=80.,secondary=(secundir,.30)),
       dict(name='80 lux / Arduino A offline',source_lux=80.,board_offline=0),
       dict(name='80 lux / Arduino B offline',source_lux=80.,board_offline=1),
    ]
    rows=[]
    for scen in scenarios:
        for result in evaluate(model,dirs,np.random.default_rng(20261121+len(rows)),scen,lookup,board):
            rows.append(result)
    df=pd.DataFrame(rows)
    df.to_csv(O/'scenario_comparison.csv',index=False)
    div=divider_table()
    div.to_csv(O/'divider_and_adc.csv',index=False)
    pd.DataFrame(dict(face=np.repeat(['+X','-X','+Y','-Y','+Z','-Z'],2),controller=np.tile(['A','B'],6),
                      nx=N[:,0],ny=N[:,1],nz=N[:,2],resistor_ohms=np.full(12,FIX_NOM))).to_csv(O/'sensor_and_wiring.csv',index=False)
    # control math spot checks
    for lux in [10,100]:
        res=25000*(lux/10)**(-.6)
        v=5*res/(res+30000)
        inv=30000*v/(5-v)
        assert abs(inv-res)<1e-9
    # compare selected scenarios for plot
    choose=['80 lux single source / normal','20 lux single source / dim',
            '80 lux + 1 contaminated channel','80 lux + 30% second directional source']
    fig,axes=plt.subplots(1,2,figsize=(13,5),layout='constrained')
    legend=['B0: nominal model + 5V ADC','B1: per-sensor cal + 5V ADC','B2: cal + auto ADC ref','B3: B2 + single-channel outlier recovery']
    xs=np.arange(len(choose));width=.19
    for i,s in enumerate(legend):
        yy=[];zz=[]
        for sc in choose:
            sub=df[(df.scenario==sc)&(df.approach==s)]
            yy.append(float(sub.p95_deg.iloc[0]));zz.append(float(sub.all_within5_pct.iloc[0]))
        axes[0].bar(xs+(i-1.5)*width,yy,width,label=s.replace(': ',': ').replace('single-channel outlier recovery','robust'))
        axes[1].bar(xs+(i-1.5)*width,zz,width)
    axes[0].set_ylabel('p95 angular error (degrees; accepted only)');axes[0].set_ylim(bottom=0)
    axes[1].set_ylabel('All directions estimated within 5 degrees (%)');axes[1].set_ylim(0,101)
    for ax in axes:
        ax.set_xticks(xs);ax.set_xticklabels(['Normal (80 lux)','Dim (20 lux)','1 bad LDR','Second lamp +30%'],rotation=20,ha='right')
        ax.grid(axis='y',alpha=.2)
    axes[0].legend(loc='upper left',fontsize=8)
    fig.suptitle('Model-based changes under hypothetical GL5537-1 response; NOT hardware validation')
    fig.savefig(O/'improvement_comparison.png',dpi=170)
    plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5),layout='constrained')
    for fixed in [30000.,100000.,1e6,3e6]:
        x=div[div.resistor_ohms==fixed]
        ax.plot(x.lux,x.adc_5v_count,'o-',label=f'{fixed/1000:g} kΩ fixed, AVcc')
    x=div[div.resistor_ohms==30000]
    ax.plot(x.lux,x.adc_autoref_count,'ks--',label='30 kΩ, auto AVcc/1.1V')
    ax.axvspan(10,100,alpha=.09,color='grey',label='Gamma characterized 10–100 lux')
    ax.set(xscale='log',ylim=(-10,1040),xlabel='Lux (hypothetical extrapolation beyond 10–100 lux)',ylabel='ADC count',title='ADC headroom with supplied-range resistor values')
    ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.savefig(O/'divider_design.png',dpi=170)
    plt.close(fig)
    # Save exact model assumptions (do not imply real performance)
    meta={
      'model_version':'2026-11-21 v2 computational only',
      'face_visibility':'cos(face_normal,sun)>0; ignores finite size and bounce',
      'sensor_axes':'12 sensors = R([1,1,1], ±10°)*six cube normals',
      'adc':'ATmega328P modeled as ideal 10bit plus Gaussian 0.65-count noise',
      'brightness_calibration_limit':'LDR power law anchored at 10 lux, gamma source quoted between 10 and 100 lux; any outside extrapolates',
      'model_truth':{'R10_ohm':'uniform 20..30k','electrical_gamma':'N(0.60,0.032) clipped 0.53..0.67','optical_exponent':'N(1.15,0.11) clipped 0.9..1.44; HYPOTHETICAL',
        'ambient_lux':'N(1.5,.55) clipped at 0', 'illumination_relative_jitter':'0.8% iid','adc_noise_counts':'0.65 gaussian',
        'avcc':'4.94V A,5.06V B','internal_vref':'1.07V A,1.14V B'},
      'calibrated_knowledge':{'R10':'2% normal error','electrical_gamma':'0.008 absolute sigma','angular_exponent':'0.035 absolute sigma','ambient':'0.25 lux sigma','avcc':'0.3% sigma','internal_1p1_ref':'0.6% sigma'},
      'estimation':'normalized irradiance pattern dictionary nearest-neighbor 24000 directions; 2400 independent held-out sun directions',
      'robust':'single channel isolation on dominant residual; quality gate normalized pattern distance<0.60',
      'limitation':'No measured angular response, spectral bias, LDR temporal hysteresis, supply noise, exact supplied resistor values, ADC nonlinearity; lookup finite resolution.'}
    (O/'model_assumptions.json').write_text(json.dumps(meta,indent=2))
    print(df[['scenario','approach','p95_deg','valid_pct','all_within5_pct','isolated_pct']].fillna('').to_string(index=False))
    print('Wrote',O)

if __name__=='__main__': main()
