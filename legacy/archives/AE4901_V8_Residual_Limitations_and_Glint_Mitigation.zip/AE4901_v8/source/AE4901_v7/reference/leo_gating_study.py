#!/usr/bin/env python3
"""AE4901 V5 — synthetic LEO albedo and rule ablation.
This is NOT physical GL5537 data or a flight-qualified albedo model.
The Earth is a Lambertian, sunlit extended disk; eclipse is a geometric occultation.
The absolute brightness is deliberately 80 lux EQUIVALENT (calibrated indoor model),
not LEO solar irradiance; nonlinear bright-sun extrapolation is not warranted.

Reproduce: python leo_gating_study.py --seeds 801 802 803 804 --nseq 18 --frames 30
"""
import argparse, sys, math
from pathlib import Path
import numpy as np, pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'reference'))
from engineering_study import Model, resp, angular, N, PHYS, BOARD, flux_to_r, divider_voltage, sphere, rodrigues
from validate_v3 import Estimator, recover, tangent_basis, local_refine
from compare_v4 import estimate_new, fault_recover

RE=6371.0
ALT=400.
EARTH_RADIUS_DEG=np.degrees(np.arcsin(RE/(RE+ALT)))
LUX=80.0


def unit(x): return x/np.linalg.norm(x,axis=-1,keepdims=True)


def rotations_about_axis(v,axis,theta):
    # Rodrigues: axes and vectors can both be batched
    return unit(v*np.cos(theta)[:,None]+np.cross(axis,v)*np.sin(theta)[:,None]+axis*np.sum(axis*v,axis=1)[:,None]*(1-np.cos(theta))[:,None])


def scenarios(seed,nseq=12,frames=30):
    """Sequence of quasi-smooth spacecraft attitudes and orbit solar-nadir geometry.
    Includes angularly adjacent Earth-limb transitions and independently randomized
    cloud patterns; scenario labels disclose the simplified environment.
    """
    rng=np.random.default_rng(seed)
    labels=['sun_only','diffuse_low','earth_typical','bright_clouds','earth_near_limb','eclipse_transition','eclipse_only','specular_glint','corrupt_channel','fast_tumble','angular_drift']
    cases=[]
    for label in labels:
        for q in range(nseq):
            s0=unit(rng.normal(size=3)); ax=unit(rng.normal(size=3))
            sep0={'sun_only':135,'diffuse_low':125,'earth_typical':100,'bright_clouds':83,'earth_near_limb':72.5,
                  'eclipse_transition':105,'eclipse_only':25,'specular_glint':90,'corrupt_channel':110,'fast_tumble':115,'angular_drift':112}[label]
            if label=='eclipse_transition':
                # a simplified in/out sequence; actual orbit timing is not modelled
                half=frames//2
                sep=np.r_[np.linspace(105,30,half),np.linspace(30,105,frames-half)]
            else:
                sep=np.full(frames,sep0+rng.uniform(-7,7))
            spin=np.deg2rad(rng.uniform(.15,1.8))
            if label=='specular_glint': spin=np.deg2rad(rng.uniform(.1,2.4))
            if label=='fast_tumble':spin=np.deg2rad(rng.uniform(8,22))
            t=np.arange(frames)
            sun=rotations_about_axis(np.broadcast_to(s0,(frames,3)).copy(),np.broadcast_to(ax,(frames,3)),spin*t)
            u,_=tangent_basis(sun)
            nadir=unit(np.cos(np.deg2rad(sep))[:,None]*sun+np.sin(np.deg2rad(sep))[:,None]*u)
            # In shadow if the Sun lies inside Earth's angular disk, neglecting atmosphere/penumbra.
            direct=np.sum(nadir*sun,axis=1)<np.cos(np.deg2rad(EARTH_RADIUS_DEG))
            cases.append(dict(label=label,case=q,sun=sun,nadir=nadir,direct=direct,
                              cloud_seed=int(rng.integers(1,1e9)),spin=spin))
    return cases


def earth_disk_albedo(sun,nadir,cloud_seed,setting,npatch=80):
    """Visible Earth Lambertian radiance integral over angular disk.
    At each apparent disk direction, ray intersect sphere to obtain local surface normal;
    irradiance factor (albedo/pi)*max(normal dot Sun,0) * solid_angle.
    Omits atmosphere, specular ocean, geospatial albedo and real material spectrum.
    """
    n=len(sun)
    # solid angle quadrature on disk, fixed for all frames in sequence
    j=np.arange(npatch)
    cosrad=1-(1-np.cos(np.deg2rad(EARTH_RADIUS_DEG)))*(j+.5)/npatch
    phis=j*np.pi*(3-np.sqrt(5))
    u,v=tangent_basis(nadir)
    dirs=cosrad[None,:,None]*nadir[:,None,:]+np.sqrt(1-cosrad**2)[None,:,None]*(
        np.cos(phis)[None,:,None]*u[:,None,:]+np.sin(phis)[None,:,None]*v[:,None,:])
    dirs=unit(dirs)
    center=-nadir*(RE+ALT)
    sd=np.einsum('ni,nki->nk',center,dirs)
    discr=np.maximum(0,sd*sd-((RE+ALT)**2-RE**2))
    raydist=-sd-np.sqrt(discr)
    surface=center[:,None,:]+raydist[:,:,None]*dirs
    normal=unit(surface)
    cos_sun=np.maximum(0,np.einsum('nki,ni->nk',normal,sun))
    rng=np.random.default_rng(cloud_seed)
    if setting=='prior':rho=np.full(npatch,.27)
    elif setting=='sun_only':rho=np.zeros(npatch)
    elif setting=='diffuse_low':rho=np.full(npatch,.10)
    elif setting=='bright_clouds':rho=np.where(rng.random(npatch)<.55,.75,.16)
    elif setting=='earth_near_limb':rho=np.where(rng.random(npatch)<.30,.70,.21)
    elif setting=='eclipse_only':rho=np.full(npatch,.36)
    else:rho=np.where(rng.random(npatch)<.22,.65,.14)
    weight=rho[None,:]/np.pi*cos_sun*(2*np.pi*(1-np.cos(np.deg2rad(EARTH_RADIUS_DEG)))/npatch)
    # per-sensor angular response; self-shading for sensors on back of physical faces
    sensor_dot=np.maximum(0,np.einsum('nkj,ij->nki',dirs,N))
    face_visible=(np.einsum('nkj,ij->nki',dirs,PHYS)>0)
    return np.einsum('nki,nk->ni',sensor_dot**1.15*face_visible,weight),float(np.mean(rho))


def acquire_environment(m,case,seed,npanels=80):
    rng=np.random.default_rng(seed)
    sun,nadir,direct=case['sun'],case['nadir'],case['direct']
    setting=case['label'];n=len(sun)
    # Truth uses per-channel angular exponents, but Earth integral assumes p=1.15.
    # Deliberate forward-model mismatch: not using the exact inverse model.
    alb,albedo_mean=earth_disk_albedo(sun,nadir,case['cloud_seed'],setting,npanels)
    if setting!='sun_only':
        # moderately differ spectral/angular albedo response channel to channel
        alb=alb*np.clip(1+.09*np.sin(np.arange(12)*1.8+.3),.65,1.35)[None,:]
    true_p=m.p.copy()
    if setting=='angular_drift':true_p=np.clip(true_p+.20*np.sin(np.arange(12)+.31),.6,1.85)
    E=LUX*direct[:,None]*resp(sun,exponent=true_p)+LUX*alb+m.ambient[None,:]
    if setting=='specular_glint':
        direction=unit(.3*sun+.95*nadir)
        E+=LUX*.25*resp(direction,exponent=m.p)
    if setting=='corrupt_channel':
        k=int(case['case']%12)
        E[:,k]+=LUX*.4
    E=np.maximum(.01,E)*(1+rng.normal(0,.008,E.shape))
    R=flux_to_r(E,m.r10,m.gamma)
    V=divider_voltage(R,m.rfixed,m.vcc)
    refs5=np.broadcast_to(m.vcc[None,:],V.shape)
    refs=np.where(V<.98,m.aref[None,:],refs5)
    adcnoise=rng.normal(0,.65,V.shape)
    code=np.clip(np.rint(1023*V/refs+adcnoise),0,1023)
    return code,refs,albedo_mean


def compute_diagnostics(m,est,codes,refs):
    ref=estimate_new(m,est,codes,refs,mode='common',robust=True)
    raw,clips=recover(m,codes,refs,cal=True,keep_negative=True)
    maxflux=np.nanmax(raw,axis=1)
    # Independent face-level estimators; high disagreement signals a suspect measurement
    est_a=est.estimate(codes,refs,'V3',boardlost=1)[0]
    est_b=est.estimate(codes,refs,'V3',boardlost=0)[0]
    delta=angular(est_a,est_b)
    fault,states,trust,_=fault_recover(m,est,codes,refs)
    return {'recovered_sun':fault['s'],'recovered_states':states,
            'sun':ref['s'],'score':ref['score'],'max_flux':maxflux,'delta':delta,
            'clip':clips,'valid':ref['valid'],'amp':ref['amp'],'raw':raw}




def earth_prior_direction(m,est,codes,refs,nadir):
    """OPTIONAL counterfactual: known Earth/nadir direction from external ADCS and
    approximate Lambertian .27 Earth reflectivity. Not usable with supplied hardware alone.
    No validation truth direction is used as an estimator input.
    """
    flux,clips=recover(m,codes,refs,cal=True,keep_negative=True)
    s=est.estimate(codes,refs,'V3')[0]
    for k in range(2):
        predicted_albedo,_=earth_disk_albedo(s,nadir,21301,'prior',npatch=80)
        clean=np.nan_to_num(flux)-LUX*predicted_albedo
        s0=est.cal.query(np.maximum(0,clean))[0]
        s,score,a=local_refine(clean,s0,m.est_p,clips,iters=5)
    return s

def decide(diag,mode,thresholds):
    n=len(diag['sun'])
    finite=diag['valid']&np.isfinite(diag['max_flux'])
    eligible=finite.copy()
    if 'brightness' in mode:
        eligible &= diag['max_flux']>=thresholds['brightness']*LUX
    if 'consistency' in mode:
        eligible &= (diag['score']<thresholds['resid'])&(diag['delta']<thresholds['boards_deg'])
    if 'recover_fault' in mode:
        # The V4 isolation candidate is provisional; never claim arbitrary faults identified.
        rescue=(diag['recovered_states']=='ISOLATED_PROVISIONAL')
        eligible |= rescue & finite & (diag['max_flux']>=thresholds['brightness']*LUX)
        if 'brightness' in mode:eligible &= diag['max_flux']>=thresholds['brightness']*LUX
    if 'time' in mode:
        # temporal gate requires previously accepted direction and an angular speed bound
        # it must NOT allow holding the stale direction as current data.
        prior=None
        for k in range(n):
            if not eligible[k]:continue
            if prior is not None:
                if angular(diag['sun'][k:k+1],diag['sun'][prior:prior+1])[0] > thresholds['step_deg']*(k-prior)+thresholds['margin_deg']:
                    eligible[k]=False
                else: prior=k
            else: prior=k
    if 'hysteresis' in mode:
        # Require two consecutive convincing frames to reacquire after a dropout;
        # if one already accepted, permit continuity until weak criteria fails.
        consecutive=0;on=False
        for k in range(n):
            ok=bool(eligible[k]); high=(diag['max_flux'][k]>=thresholds['reacq']*LUX)
            if not ok:on=False;consecutive=0;continue
            if on:continue
            consecutive=consecutive+1 if high else 0
            if consecutive>=2:
                on=True
            else: eligible[k]=False
    return eligible


def evaluate(diag,truth,direct,accepted,method=''):
    direction=diag['sun'].copy()
    if 'recover' in method:
        correction=(diag['recovered_states']=='ISOLATED_PROVISIONAL')
        direction[correction]=diag['recovered_sun'][correction]
    if 'earth_prior' in method and 'earth_prior_sun' in diag: direction=diag['earth_prior_sun']
    err=angular(direction,truth)
    active=direct
    good=active&accepted&(err<=5)
    wrong=active&accepted&(err>5)
    vals=err[active&accepted]
    return dict(day_samples=int(active.sum()),eclipse_samples=int((~active).sum()),
                day_accept_pct=float(100*accepted[active].mean()) if active.any() else np.nan,
                day_good5_pct=float(100*good.sum()/active.sum()) if active.any() else np.nan,
                day_wrong5_pct=float(100*wrong.sum()/active.sum()) if active.any() else np.nan,
                day_p95_accepted_deg=float(np.quantile(vals,.95)) if len(vals) else np.nan,
                day_p95_unfiltered_deg=float(np.quantile(err[active],.95)) if active.any() else np.nan,
                eclipse_false_valid_pct=float(100*accepted[~active].mean()) if (~active).any() else np.nan,
                total_wrong_accepted_pct=float(100*(wrong.sum()+(accepted&~active).sum())/len(active)))


MODES={
 'baseline':(),
 'threshold':('brightness',),
 'cross_face':('consistency',),
 'temporal':('time',),
 'threshold_cross':('brightness','consistency'),
 'threshold_eclipse':('brightness','hysteresis'),
 'all_four':('brightness','consistency','time','hysteresis'),
 'all_without_time':('brightness','consistency','hysteresis'),
 'cross_temporal':('consistency','time'),
 'recover_fault_only':('brightness','recover_fault'),
 'cross_recover':('brightness','consistency','recover_fault'),
 'cross_recover_eclipse':('brightness','consistency','recover_fault','hysteresis'),
 'conservative_recover':('brightness','consistency','recover_fault'),
 'conservative_no_recover':('brightness','consistency'),
 'earth_prior_optional':('brightness',),
}


def main(seeds,nseq,frames,mode_test):
    from collections import defaultdict
    defaults={'brightness':.30,'resid':2.9,'boards_deg':14.,'step_deg':4.,'margin_deg':3.,'reacq':.35}
    options={'brightness':[.2,.3,.4,.5], 'resid':[.8,1.1,1.4,2.0,2.9,4.0], 'boards_deg':[2,4,6,9,14,20], 'step_deg':[3,4,7]}
    rows=[];diag_rows=[]
    for seed in seeds:
        m=Model(seed);est=Estimator(m,n_grid=6500)
        cases=scenarios(10000+seed,nseq,frames)
        for idx,case in enumerate(cases):
            codes,refs,rho=acquire_environment(m,case,seed*10000+idx)
            diag=compute_diagnostics(m,est,codes,refs)
            if not mode_test:diag['earth_prior_sun']=earth_prior_direction(m,est,codes,refs,case['nadir'])
            if mode_test:
                ablation=[(f'{k}={val}',tuple([ 'brightness' if k=='brightness' else 'consistency' if k in ('resid','boards_deg') else 'time']),{**defaults,k:val}) for k,values in options.items() for val in values]
            else: ablation=[(key,mode,defaults) for key,mode in MODES.items()]
            for name,mode,params in ablation:
                if name.startswith('conservative_'):params={**params,'resid':.9,'boards_deg':7.}
                valid=decide(diag,mode,params)
                stats=evaluate(diag,case['sun'],case['direct'],valid,method=name)
                rows.append(dict(seed=seed,scenario=case['label'],case=case['case'],method=name,**stats))
            err=angular(diag['sun'],case['sun'])
            diag_rows.append(dict(seed=seed,scenario=case['label'],case=case['case'],true_day_frac=case['direct'].mean(),
                             raw_median_err_day=float(np.median(err[case['direct']])) if case['direct'].any() else None,
                             raw_median_amp=float(np.median(diag['amp'])),
                             max_flux_day=float(np.median(diag['max_flux'][case['direct']])) if case['direct'].any() else None,
                             max_flux_eclipse=float(np.median(diag['max_flux'][~case['direct']])) if (~case['direct']).any() else None,
                             typical_albedo=float(rho)))
        print(f'seed {seed}: {len(cases)} cases done',flush=True)
    pd.DataFrame(rows).to_csv(ROOT/('sweep_rows.csv' if mode_test else 'test_rows.csv'),index=False)
    pd.DataFrame(diag_rows).to_csv(ROOT/'scenario_diagnostics.csv',index=False)
    data=pd.DataFrame(rows)
    # Avoid p95-of-p95 for decision: compute average per-sequence with transparent aggregation;
    # exact pooled p95 requires samples; this report labels per-case p95 averages explicitly.
    summary=data.groupby(['scenario','method'],as_index=False).agg(
        n_cases=('case','size'),day_accept_pct=('day_accept_pct','mean'),day_good5_pct=('day_good5_pct','mean'),
        day_wrong5_pct=('day_wrong5_pct','mean'),p95_mean_case_deg=('day_p95_accepted_deg','mean'),
        eclipse_false_valid_pct=('eclipse_false_valid_pct','mean'),total_wrong_accepted_pct=('total_wrong_accepted_pct','mean'))
    summary.to_csv(ROOT/('sweep_summary.csv' if mode_test else 'summary.csv'),index=False)
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',nargs='+',type=int,default=[801,802,803,804]);ap.add_argument('--nseq',type=int,default=10);ap.add_argument('--frames',type=int,default=30);ap.add_argument('--sweep',action='store_true')
    cfg=ap.parse_args()
    print('Earth angular radius deg',EARTH_RADIUS_DEG,flush=True)
    out=main(cfg.seeds,cfg.nseq,cfg.frames,cfg.sweep)
    print(out[out.scenario.isin(['earth_typical','bright_clouds','eclipse_transition'])].to_string(index=False))
