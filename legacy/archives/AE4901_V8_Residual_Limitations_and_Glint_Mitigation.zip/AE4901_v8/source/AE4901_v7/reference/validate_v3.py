#!/usr/bin/env python3
"""AE4901 v3 computational validation. Uses v2 synthetic instrument as unchanged forward truth.

NOT PHYSICAL VALIDATION. Parameters for optical scattering, background and ADC errors are
hypotheses. Results compare algorithms on IDENTICAL simulated ADC samples and independent
held-out Sun vectors. Calibration is an assumed approximate per-channel model, NOT oracle truth.
"""
from pathlib import Path
import sys, time, json
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
from engineering_study import Model, Matcher, sphere, resp, N, PHYS, BOARD, FIX_NOM, angular, flux_to_r, divider_voltage

P=Path(__file__).resolve().parent

# LDR forward model, reference switching and ADC codes are identical to v2.
# A simulated optional diffuse ambient shift is injected BEFORE electronics.
def acquire(m, s, rng, lux=80, second=None, fault=None, lost=None, ambient_shift=0., source_scale=None,
            mismatch=None, transient_bg=None):
    n=len(s)
    exp=m.p if mismatch is None else mismatch
    if source_scale is None:source_scale=np.full(n,float(lux))
    E=source_scale[:,None]*resp(s,exponent=exp)
    if second is not None:
        v,k=second
        vv=np.broadcast_to(np.asarray(v,dtype=float),(n,3)) if np.asarray(v).ndim==1 else np.asarray(v)
        k=np.full(n,float(k)) if np.isscalar(k) else np.asarray(k)
        E+=source_scale[:,None]*k[:,None]*resp(vv,exponent=exp)
    E+=m.ambient[None,:]+ambient_shift
    if transient_bg is not None:E+=transient_bg
    if fault is not None:
        j,strength=fault
        if j=='random':
            ix=rng.integers(0,12,n)
        elif j=='cycle':
            ix=np.arange(n)%12
        else: ix=np.full(n,int(j))
        E[np.arange(n),ix]+=source_scale*strength
    E=np.maximum(E,0.01)*(1+rng.normal(0,0.008,E.shape))
    R=flux_to_r(E,m.r10,m.gamma)
    V=divider_voltage(R,m.rfixed,m.vcc)
    noise=rng.normal(0,.65,V.shape)
    refs5=np.broadcast_to(m.vcc[None,:],V.shape)
    refsauto=np.where(V<.98,m.aref[None,:],m.vcc[None,:])
    codes5=np.clip(np.rint(V/refs5*1023+noise),0,1023).astype(float)
    codesa=np.clip(np.rint(V/refsauto*1023+noise),0,1023).astype(float)
    if lost is not None:
        codes5[:,BOARD==lost]=np.nan
        codesa[:,BOARD==lost]=np.nan
    return (codes5,refs5),(codesa,refsauto)

def recover(m,codes,refs,cal=True,keep_negative=False):
    """Independent arithmetic path for ADC inversion, with calibrated references.
    Keeps negative background-subtracted flux for v3 common-mode estimation."""
    n=len(codes)
    clipped=np.isnan(codes)|(codes<=1)|(codes>=1022)
    if cal:
        r10=m.est_r10;gamma=m.est_gamma;bg=m.est_bg
        vref=np.where(refs<2,m.est_aref[None,:],m.est_vcc[None,:]);vcc=m.est_vcc
    else:
        r10=np.full(12,25000.);gamma=np.full(12,.60);bg=np.zeros(12)
        vref=np.where(refs<2,1.1,m.vcc[None,:]);vcc=m.vcc
    V=np.nan_to_num(codes,nan=0)/1023*vref
    R=m.rfixed[None,:]*np.maximum(V,1e-6)/np.maximum(vcc[None,:]-V,1e-6)
    E=10*np.power(np.clip(R/r10[None,:],1e-9,1e9),-1/gamma[None,:])-bg[None,:]
    E[clipped]=np.nan
    if not keep_negative:E=np.clip(E,0,None)
    return E,clipped

def tangent_basis(s):
    pole=np.broadcast_to(np.array([0.,0.,1.]),s.shape).copy()
    pole[np.abs(s[:,2])>.91]=np.array([0.,1.,0.])
    u=np.cross(s,pole);u/=np.linalg.norm(u,axis=1)[:,None]
    v=np.cross(s,u)
    return u,v

def optical_and_jac(s,p):
    d=s@N.T;f=s@PHYS.T
    vis=(d>0)&(f>0)
    ds=np.where(vis,d,0.)
    pattern=ds**p[None,:]
    D=np.where(vis,p[None,:]*np.maximum(ds,1e-8)**(p[None,:]-1),0.)
    # N.T is derivative of cosine dot w.r.t 3-vector, ignoring face-visibility discontinuity
    J=D[:,:,None]*N[None,:,:]
    return pattern,J

def local_refine(y,s0,p,clipped=None,iters=4, weights=None):
    """Vectorized 2-DOF spherical Gauss-Newton, nuisance brightness fitted jointly.
    Does not claim convergence globally: nearest-pattern lookup supplies initial direction."""
    s=np.asarray(s0,float).copy();y=np.nan_to_num(np.asarray(y,float),nan=0.,posinf=0.)
    mask=np.isfinite(weights) if weights is not None else np.ones(y.shape,bool)
    if clipped is not None:mask &= ~clipped
    mask &= np.isfinite(y)
    # Optical noise is roughly proportional to flux PLUS fixed inversion and background error.
    # Fixed 0.75-lux floor avoids over-weighting channels near zero response.
    if weights is None:w=1/np.sqrt(.75**2+(0.016*np.maximum(y,0))**2)
    else:w=weights.copy()
    w=np.where(mask,w,0.)
    for _ in range(iters):
        pat,dpat=optical_and_jac(s,p)
        den=np.sum(w*w*pat*pat,axis=1)+1e-12
        amp=np.maximum(0,np.sum(w*w*y*pat,axis=1)/den)
        u,v=tangent_basis(s)
        J0=pat
        J1=amp[:,None]*np.sum(dpat*u[:,None,:],axis=2)
        J2=amp[:,None]*np.sum(dpat*v[:,None,:],axis=2)
        J=np.stack((J0,J1,J2),axis=2)*w[:,:,None]
        res=(y-amp[:,None]*pat)*w
        JTJ=np.einsum('nki,nkj->nij',J,J)
        JTr=np.einsum('nki,nk->ni',J,res)
        JTJ+=np.diag([1e-6,1e-3,1e-3])[None,:,:]
        step=np.linalg.solve(JTJ,JTr[:,:,None])[:,:,0]
        ax=np.clip(step[:,1],-.13,.13);by=np.clip(step[:,2],-.13,.13)
        s+=ax[:,None]*u+by[:,None]*v
        s/=np.linalg.norm(s,axis=1)[:,None]
    pat,_=optical_and_jac(s,p)
    amp=np.maximum(0,np.sum(w*w*y*pat,axis=1)/(np.sum(w*w*pat*pat,axis=1)+1e-12))
    resid=np.sqrt(np.sum((w*(y-amp[:,None]*pat))**2,axis=1)/(np.maximum(np.sum(w*w*y*y,axis=1),1e-12)))
    return s,resid,amp

class Estimator:
    def __init__(self,m,n_grid=26000):
        self.m=m
        self.nom=Matcher(np.ones(12),n_grid)
        self.cal=Matcher(m.est_p,n_grid)
        self.single={i:Matcher(m.est_p,n_grid,board=i) for i in (0,1)}
    def estimate(self,codes,refs,version,boardlost=None,common_bg=True):
        cal=version!='B0'
        raw,clipped=recover(self.m,codes,refs,cal=cal,keep_negative=True)
        active=np.ones(12,bool) if boardlost is None else BOARD!=boardlost
        clipped[:,~active]=True
        nominal=version=='B0'
        p=np.ones(12) if nominal else self.m.est_p
        mat=self.nom if nominal else self.cal
        # Existing v2 nearest-pattern matcher, always conditioned on selected live board
        if boardlost is not None: mat=self.single[1-boardlost]
        s,d,_=mat.query(np.clip(np.nan_to_num(raw,nan=0.),0,None))
        if version in ('B0','B1','B2'):
            return s,d,np.ones(len(s),bool),np.zeros(len(s)),raw,clipped
        # V3: per-frame common ambient estimator from the physically backlit/shaded faces
        # Only applies when all board sensors present; median over reliably dark faces.
        clean=raw.copy()
        if common_bg and boardlost is None:
            for _ in range(2):
                shade=(s@PHYS.T)<-.15
                dark=np.where(shade & (~clipped),clean,np.nan)
                num=np.sum(np.isfinite(dark),axis=1)
                darkmed=np.nanmedian(dark,axis=1)
                delta=np.where(num>=3,np.clip(np.nan_to_num(darkmed,nan=0.),-6,6),0.)
                clean=clean-delta[:,None]
                s,_,_=self.cal.query(np.clip(np.nan_to_num(clean,nan=0.),0,None))
        s0=s
        s,r,a=local_refine(clean,s0,p,clipped)
        valid=(np.sum(~clipped[:,active],axis=1)>=3)&(np.linalg.norm(np.nan_to_num(clean[:,active],nan=0.),axis=1)>1)
        return s,r,valid,a,clean,clipped



    def diagnose_and_recover(self,codes,refs):
        """Single-channel leave-one-out isolation with independent board check.

        Does NOT correct coherent second-source illumination. Suspicious
        multi-source/unknown response outputs are deliberately NOT accepted.
        """
        s,r,valid,amp,y,clipped=self.estimate(codes,refs,'V3')
        n=len(y)
        state=np.full(n,'NORMAL',dtype='<U24')
        removed=np.full(n,-1,int)
        high=(r>.095)&valid
        state[~valid]='INSUFFICIENT'
        if not high.any():return s,r,state,removed
        rows=np.where(high)[0]
        # Both controllers observe a complete six-face geometry; an isolated
        # sensor fault should make only one controller disagree with the model.
        br=[]
        for b in (0,1):
            tmp=codes[rows].copy();tmp[:,BOARD!=b]=np.nan
            si,ri,_,_,_,_=self.estimate(tmp,refs[rows],'V3',boardlost=1-b)
            br.append(ri)
        br=np.stack(br,axis=1)
        health=np.min(br,axis=1)<.035
        # Build leave-one-out lookup trees from **calibrated forward model**.
        # The 12 reconstructions are independent hypotheses, not 12 extra LDRs.
        if not hasattr(self,'loo_trees'):
            pat=resp(self.cal.sky,exponent=self.m.est_p)
            self.loo_trees=[]
            for j in range(12):
                rest=np.delete(pat,j,axis=1)
                rest/=np.linalg.norm(rest,axis=1)[:,None]+1e-12
                self.loo_trees.append(cKDTree(rest))
        yy=np.maximum(0.,np.nan_to_num(y[rows],nan=0.))
        all_d=[];all_ix=[]
        for j,tr in enumerate(self.loo_trees):
            yyj=np.delete(yy,j,axis=1)
            yyj/=np.linalg.norm(yyj,axis=1)[:,None]+1e-12
            dd,ix=tr.query(yyj)
            all_d.append(dd);all_ix.append(ix)
        scores=np.stack(all_d,axis=1)
        indices=np.stack(all_ix,axis=1)
        ordered=np.sort(scores,axis=1)
        j=np.argmin(scores,axis=1)
        best=ordered[:,0];second=ordered[:,1]
        # Thresholds are algorithm hypotheses, chosen to avoid frequent
        # healthy-data false isolation; require independent sensitivity tests.
        single=health & (best<.08) & (best<.60*second) & (best<.60*r[rows])
        if single.any():
            positions=np.where(single)[0]
            rr=rows[positions];jj=j[positions]
            s0=self.cal.sky[indices[positions,jj]]
            mask=clipped[rr].copy()
            mask[np.arange(len(rr)),jj]=True
            refined,fit,_=local_refine(y[rr],s0,self.m.est_p,mask,iters=6)
            # Must refit the retained 11 channels with the calibrated optics.
            accept=fit<.105
            rr=rr[accept];jj=jj[accept]
            s[rr]=refined[accept];r[rr]=fit[accept]
            # Confidence tier: distinguish a mathematically possible LOO
            # correction from an independently supported controller fault.
            parent_board=BOARD[jj]
            local=br[positions[accept]]
            ratio=local[np.arange(len(rr)),parent_board]/np.maximum(
                 local[np.arange(len(rr)),1-parent_board],1e-6)
            confirmed=ratio>1.5
            state[rr[confirmed]]='RECOVERED_ONE_SENSOR'
            state[rr[~confirmed]]='TENTATIVE_SENSOR'
            removed[rr]=jj
        state[high & (state=='NORMAL')]='SUSPECT'
        return s,r,state,removed


def stats(angles,valid):
    return {'accepted_pct':round(float(100*valid.mean()),2),
            'median_deg':round(float(np.median(angles[valid])),3) if valid.any() else np.nan,
            'p95_deg':round(float(np.quantile(angles[valid],.95)),3) if valid.any() else np.nan,
            'p99_deg':round(float(np.quantile(angles[valid],.99)),3) if valid.any() else np.nan,
            'success_le5_pct':round(float(100*np.mean(valid & (angles<=5))),2),
            'wrong_accepted_gt5_pct':round(float(100*np.mean(valid&(angles>5))),2),
            'p95_all_unfiltered_deg':round(float(np.quantile(angles,.95)),3)}


def run_scenarios():
    rows=[];records=[]
    sky=sphere(1100,.543)
    secondary=np.array([.49,-.24,.84]);secondary/=np.linalg.norm(secondary)
    scenarios={
        'Normal 80 lux':dict(lux=80),
        'Dim 20 lux':dict(lux=20),
        'Bright 300 lux':dict(lux=300),
        'Strong 1500 lux (extrapolated)':dict(lux=1500),
        'Bright 10000 lux (extrapolated)':dict(lux=10000),
        'Diffuse ambient +4 lux':dict(lux=80,ambient_shift=4),
        'Uneven ambient 1-7 lux':dict(lux=80,transient_bg=np.linspace(1,7,12)),
        'Angular-response change (assumed)':dict(lux=80,ang_drift=True),
        'One LDR +40% corruption':dict(lux=80,fault=('cycle',.40)),
        'Coherent second light +10%':dict(lux=80,second=(secondary,.10)),
        'Coherent second light +30%':dict(lux=80,second=(secondary,.30)),
        'Coherent second light +60%':dict(lux=80,second=(secondary,.60)),
        'Arduino A offline':dict(lux=80,lost=0),
        'Arduino B offline':dict(lux=80,lost=1),
    }
    for k in [701,702,703,704]:
        m=Model(k); est=Estimator(m)
        for scenario,args in scenarios.items():
            rng=np.random.default_rng(299000+k) # same random draw across scenario intensity variants
            args=args.copy()
            if args.pop('ang_drift',False):
                args['mismatch']=np.clip(m.p+.18*np.sin(np.arange(12)+.31),.6,1.9)
            dd=acquire(m,sky,rng,**args)
            for version,cs,rf in [('B0',dd[0][0],dd[0][1]),('B1',dd[0][0],dd[0][1]),('B2',dd[1][0],dd[1][1]),('V3',dd[1][0],dd[1][1])]:
                s,fit,valid,amp,flux,clip=est.estimate(cs,rf,version,boardlost=args.get('lost'))
                err=angular(s,sky)
                dat=dict(model_seed=k,scenario=scenario,method=version,**stats(err,valid))
                if version=='V3':dat.update(residual_median=float(np.median(fit)),residual_p95=float(np.quantile(fit,.95)))
                rows.append(dat)
                if k==701:
                    records.append((scenario,version,sky,s,err,valid,fit,flux,clip))
            if args.get('lost') is None:
                (ca,rf)=dd[1]
                v4,quality,state,removed=est.diagnose_and_recover(ca,rf)
                trusted=np.isin(state,['NORMAL','RECOVERED_ONE_SENSOR'])
                dat=dict(model_seed=k,scenario=scenario,method='V4 trusted only',**stats(angular(v4,sky),trusted))
                dat.update(recovered_pct=round(100*np.mean(state=='RECOVERED_ONE_SENSOR'),2),
                           tentative_pct=round(100*np.mean(state=='TENTATIVE_SENSOR'),2),
                           suspect_pct=round(100*np.mean(state=='SUSPECT'),2),
                           tentative_within5_pct=round(100*np.mean((state=='TENTATIVE_SENSOR')&(angular(v4,sky)<5)),2))
                if scenario=='One LDR +40% corruption':
                    isr=state=='RECOVERED_ONE_SENSOR'
                    dat['correct_isolation_pct']=round(float(100*np.mean(removed[isr]==np.arange(len(sky))[isr]%12)),2) if isr.any() else np.nan
                rows.append(dat)
        print('completed model seed',k,flush=True)
    pd.DataFrame(rows).to_csv(P/'per_seed_results.csv',index=False)
    by=pd.DataFrame(rows).groupby(['scenario','method'],sort=False).agg({'p95_deg':'median','success_le5_pct':'median', 'accepted_pct':'median','wrong_accepted_gt5_pct':'median','p95_all_unfiltered_deg':'median', 'residual_p95':'median', 'recovered_pct':'median', 'tentative_pct':'median', 'suspect_pct':'median', 'correct_isolation_pct':'median'}).reset_index()
    by.to_csv(P/'comparison_summary.csv',index=False)
    return rows,records

if __name__=='__main__':
    a,b=run_scenarios()
    print(pd.read_csv(P/'comparison_summary.csv').to_string(index=False))
