from pathlib import Path
import pandas as pd, numpy as np, matplotlib.pyplot as plt
H=Path(__file__).resolve().parent
m=pd.read_csv(H/'thermal_summary.csv')
fig,ax=plt.subplots(figsize=(8.8,4.4))
for label,group in m.groupby('method'):
    ax.plot(group.temp_c,group.p95_deg,marker='o',linewidth=2,label='Temperature compensated' if label.startswith('temperature') else 'Fixed ground calibration')
ax.axhline(5,linestyle='--',linewidth=1,color='grey',label='Proposed 5° target')
ax.set(title='Hypothetical thermal sensitivity of 12-LDR sensor',xlabel='Sensor temperature (°C)',ylabel='95th-percentile Sun-vector error (degrees)')
ax.set_ylim(bottom=0);ax.legend();ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(H/'thermal_sensitivity.png',dpi=160);plt.close(fig)

r=pd.read_csv(H/'glint_prior_summary.csv')
g=r[r.scenario=='specular_glint'].set_index('method')
labels=['V5 LDR-only','With 3° ADCS','With 8° ADCS']
methods=['V5_LDR_ONLY','WITH_ADCS_3deg','WITH_ADCS_8deg']
x=np.arange(3)
fig,ax=plt.subplots(figsize=(9,4.4))
a=ax.bar(x-.18,g.loc[methods,'wrong10_pct'].values,.36,label='Wrong >10° accepted')
b=ax.bar(x+.18,g.loc[methods,'accepted_pct'].values,.36,label='All observations accepted')
ax.set_xticks(x,labels);ax.set_ylim(0,75);ax.set_ylabel('Share of daylight observations (%)');ax.set_title('Optional external direction check in a severe synthetic glint case')
ax.legend();ax.grid(axis='y',alpha=.2)
for container in [a,b]:
    for rect in container: ax.text(rect.get_x()+rect.get_width()/2,rect.get_height()+1,f'{rect.get_height():.1f}%',ha='center',fontsize=9)
fig.tight_layout();fig.savefig(H/'glint_external_reference.png',dpi=160);plt.close(fig)
