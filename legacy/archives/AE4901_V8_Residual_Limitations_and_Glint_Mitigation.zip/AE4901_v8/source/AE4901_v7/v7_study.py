#!/usr/bin/env python3
"""AE4901 V7 independent-information and environmental sensitivity study.

Synthetic only. NO sensor measurements, no flight validation. Tests realistic
limitations of 12 scalar intensities, not a qualified Sun-sensor design.
Different attitude and temperature references are optional external inputs,
NOT supplied by the AE4901 kit.
"""
from pathlib import Path
import sys, numpy as np, pandas as pd
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'reference'))
from engineering_study import Model,N,PHYS,resp,flux_to_r,divider_voltage,sphere,angular,BOARD
from validate_v3 import Estimator
from compare_v4 import estimate_new
from leo_gating_study import scenarios,acquire_environment,compute_diagnostics,decide

SEEDS=(1601,1602,1603,1604)
THR={'brightness':.30,'resid':2.9,'boards_deg':14.,'step_deg':4.,'margin_deg':3.,'reacq':.35}

def unit(a): return a/(np.linalg.norm(a,axis=-1,keepdims=True)+1e-14)

def independent_attitude_prior(sun,rng,std_deg=3.,bias_deg=0.):
    """External ADCS direction measurement; simulated independently from LDR ADC.
    The true Sun vector is used ONLY to simulate a new sensor source; this is
    explicitly not a capability of the supplied two Arduinos and 12 LDRs.
    """
    eps=rng.normal(size=sun.shape)
    eps=eps-(eps*sun).sum(axis=1)[:,None]*sun
    eps=unit(eps)
    mag=np.deg2rad(rng.normal(bias_deg,std_deg,len(sun)))
    return unit(np.cos(mag)[:,None]*sun + np.sin(mag)[:,None]*eps)

def summarize(est,truth,accepted,direct):
    err=angular(est,truth); day=direct
    return dict(n=int(day.sum()),p95_accepted_deg=round(float(np.percentile(err[day&accepted],95)),3) if (day&accepted).any() else None,
                accepted_pct=round(float(100*np.mean(accepted[day])),2) if day.any() else None,
                correct5_pct=round(float(100*np.mean((accepted&(err<=5))[day])),2) if day.any() else None,
                wrong10_pct=round(float(100*np.mean((accepted&(err>10))[day])),2) if day.any() else None,
                eclipse_false_pct=round(float(100*np.mean(accepted[~day])),2) if (~day).any() else None)

def run_glint_prior():
    rows=[]
    for seed in SEEDS:
        m=Model(seed);est=Estimator(m,n_grid=4800)
        selected=[c for c in scenarios(seed+15000,nseq=5,frames=28) if c['label'] in ('sun_only','earth_typical','specular_glint','eclipse_only','fast_tumble')]
        for idx,c in enumerate(selected):
            codes,refs,_=acquire_environment(m,c,seed*500+idx)
            diag=compute_diagnostics(m,est,codes,refs)
            base=decide(diag,('brightness','consistency','recover_fault','hysteresis'),THR)
            s=diag['sun'].copy()
            rescue=(diag['recovered_states']=='ISOLATED_PROVISIONAL')&base
            s[rescue]=diag['recovered_sun'][rescue]
            for meth,mask in [('V5_LDR_ONLY',base),('WITH_ADCS_3deg',base & (angular(s,independent_attitude_prior(c['sun'],np.random.default_rng(seed*1000+idx),3.))<12.)),
                ('WITH_ADCS_8deg',base & (angular(s,independent_attitude_prior(c['sun'],np.random.default_rng(seed*2000+idx),8.))<18.)),
                ('WITH_BAD_ADCS_20deg',base & (angular(s,independent_attitude_prior(c['sun'],np.random.default_rng(seed*3000+idx),3.,20.))<12.))]:
                rows.append(dict(seed=seed,scenario=c['label'],case=idx,method=meth,**summarize(s,c['sun'],mask,c['direct'])))
        print('glint prior seed',seed,'complete',flush=True)
    f=pd.DataFrame(rows);f.to_csv(HERE/'glint_prior_cases.csv',index=False)
    return f.groupby(['scenario','method'],as_index=False).agg(n=('n','sum'),accepted_pct=('accepted_pct','mean'),correct5_pct=('correct5_pct','mean'),wrong10_pct=('wrong10_pct','mean'),p95_accepted_deg=('p95_accepted_deg','mean'),eclipse_false_pct=('eclipse_false_pct','mean'))

def make_thermal_adc(m,dirs,rng,temp_c, k_res,dp_c):
    """Hypothesized GL5537 electrical resistance temp factor and angular change.
    k_res and dp_c are NOT datasheet characteristics, deliberately illustrative.
    """
    t=np.asarray(temp_c,float)
    p_true=np.clip(m.p[None,:]+(t[:,None]-20)*dp_c[None,:],.6,2.)
    dot=np.maximum(dirs@N.T,0);vis=(dirs@PHYS.T)>0
    optical=dot**p_true*vis
    lux=80*optical+m.ambient[None,:]
    r=flux_to_r(lux,m.r10,m.gamma)*np.exp((t[:,None]-20)*k_res[None,:])
    volts=divider_voltage(r,m.rfixed,m.vcc)
    refs=np.where(volts<.98,m.aref[None,:],m.vcc[None,:])
    adc=np.clip(np.rint(1023*volts/refs+rng.normal(0,.65,volts.shape)),0,1023)
    return adc,refs

def run_thermal():
    rows=[];dirs=sphere(440,.311)
    for seed in SEEDS:
        m=Model(seed);e=Estimator(m,n_grid=4800);rng=np.random.default_rng(seed*9)
        kres=rng.normal(0.004,.0018,12)*rng.choice([-1,1],12) # assumed 0.4% per Celsius, random sign
        dp=rng.normal(0.0015,.0006,12)*rng.choice([-1,1],12)  # assumed angular exponent change
        m0_r10=m.est_r10.copy();m0_p=m.est_p.copy()
        for t in [-10.,20.,55.]:
            code,refs=make_thermal_adc(m,dirs,np.random.default_rng(seed+int(t)*11),np.full(len(dirs),t),kres,dp)
            for label in ['fixed_ground_cal','temperature_compensation']:
                if label=='temperature_compensation':
                    tmeas=t+rng.normal(0,2)   # optional external sensor, 2C uncertainty
                    measured_k=kres*(1+rng.normal(0,.15,12))
                    measured_dp=dp+rng.normal(0,.0003,12)
                    m.est_r10=m0_r10*np.exp((tmeas-20)*measured_k)
                    m.est_p=np.clip(m0_p+(tmeas-20)*measured_dp,.6,2)
                    ei=Estimator(m,n_grid=4800)
                else:
                    m.est_r10=m0_r10;m.est_p=m0_p;ei=e
                z=estimate_new(m,ei,code,refs,mode='common',robust=True)
                err=angular(z['s'],dirs)
                rows.append(dict(seed=seed,temp_c=t,method=label,p95_deg=np.percentile(err,95),median_deg=np.median(err),within5_pct=100*np.mean(err<=5)))
            m.est_r10=m0_r10;m.est_p=m0_p
        print('thermal seed',seed,'complete',flush=True)
    f=pd.DataFrame(rows);f.to_csv(HERE/'thermal_cases.csv',index=False)
    return f.groupby(['temp_c','method'],as_index=False).agg(p95_deg=('p95_deg','mean'),median_deg=('median_deg','mean'),within5_pct=('within5_pct','mean'))

if __name__=='__main__':
    a=run_glint_prior();a.to_csv(HERE/'glint_prior_summary.csv',index=False)
    b=run_thermal();b.to_csv(HERE/'thermal_summary.csv',index=False)
    print('\nGLINT PROR SUMMARY\n',a.round(2).to_string(index=False));print('\nTHERMAL SUMMARY\n',b.round(2).to_string(index=False))
