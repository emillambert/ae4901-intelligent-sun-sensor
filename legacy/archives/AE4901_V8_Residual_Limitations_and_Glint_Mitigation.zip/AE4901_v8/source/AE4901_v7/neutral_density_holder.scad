// AE4901 conceptual 3D-printed film retaining cap, not dimension-verified.
// Outer shape must be adapted after inspecting the actual LDR package and holder.
// Use an optically suitable, characterized ND filter; printed plastic is NOT
// an adequate substitute for calibrated spectrally neutral attenuation.
$fn=96;
ldr_d=5.0;                // nominal visible CdS diameter, measure actual package
clearance=0.35;
outer_d=13;
cap_height=3.4;
film_gap=0.6;             // adapt to actual film thickness and mounting approach
hole_d=ldr_d+2*clearance;
difference() {
    cylinder(h=cap_height,d=outer_d);
    translate([0,0,-0.05])cylinder(h=cap_height+0.1,d=hole_d);
    // Retaining side recess for a circular filter disk; add separate adhesive
    // or clamp without obscuring aperture. Verify light leaks in actual assembly.
    translate([0,0,cap_height-film_gap]) cylinder(h=film_gap+.1,d=9.4);
}
