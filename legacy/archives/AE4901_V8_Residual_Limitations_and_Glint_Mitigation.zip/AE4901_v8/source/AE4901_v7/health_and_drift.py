#!/usr/bin/env python3
"""Conservative spacecraft-style telemetry and relative-drift monitor.
Lab reference implementation; not compiled to Arduino or flight-qualified.
This *detects* some channel-specific anomalies. No autonomous gain updates,
because brightness/calibration/glint are confounded without external reference.
"""
from dataclasses import dataclass
import struct
import numpy as np

def crc16_ccitt(data:bytes,initial=0xFFFF)->int:
    crc=initial
    for octet in data:
        crc^=(octet<<8)
        for _ in range(8):
            crc=((crc<<1)^0x1021 if crc&0x8000 else crc<<1)&0xFFFF
    return crc

def packet(board_id:int,sequence:int,adc6,health:int=0)->bytes:
    values=list(adc6)
    if board_id not in (0,1) or not (0<=sequence<65536) or len(values)!=6 or any(not 0<=int(x)<=1023 for x in values):
        raise ValueError('Invalid board, sequence, or six ADC readings')
    # Version 1; magic 0xA7; seq rollover supported; CRC covers header+payload.
    head=struct.pack('<BBBH6HB',0xA7,1,board_id,sequence,*[int(v) for v in values],health&255)
    return head+struct.pack('<H',crc16_ccitt(head))

def decode(data:bytes):
    if len(data)!=20:raise ValueError('Invalid packet length')
    if crc16_ccitt(data[:-2])!=struct.unpack('<H',data[-2:])[0]:raise ValueError('Corrupt packet')
    header=struct.unpack('<BBBH6HB',data[:-2])
    if header[0]!=0xA7 or header[1]!=1 or header[2] not in (0,1):raise ValueError('Unknown protocol')
    return dict(version=header[1],board=header[2],sequence=header[3],adc=list(header[4:10]),health=header[10])

@dataclass
class Status:
    state:str
    suspect_channels:tuple[int,...]
    samples_seen:int
    comment:str

class DriftGuard:
    """EWMA normalized channel residuals from a fitted single-Sun model.
    Only update under stable, high illumination with BOTH controllers present.
    Fails closed on multi-channel changes; never learns from suspect data.
    """
    def __init__(self,channels=12,alpha=.12,limit=3.0,minimum=12):
        self.channels=channels;self.alpha=alpha;self.limit=limit;self.minimum=minimum
        self.smooth=np.zeros(channels);self.n=np.zeros(channels,dtype=int)
    def update(self,residual_sigma,illuminated,stable_sun=True,controllers=2):
        r=np.asarray(residual_sigma,float);ok=np.asarray(illuminated,bool)&np.isfinite(r)
        if r.shape!=(self.channels,) or ok.shape!=(self.channels,):raise ValueError('Expected 12 channels')
        if not stable_sun or controllers!=2:
            return Status('MONITOR_PAUSED',(),int(self.n.max()),'Cannot identify drift reliably in this operating mode')
        # Disturbances involving many channels are not identifiable as independent gain drift.
        coherent=np.sum(ok&(abs(r)>=3.0))
        if coherent>=3:
            return Status('LIGHTING_OR_MODEL_SUSPECT',(),int(self.n.max()),'Freeze learning; possible glint / model mismatch')
        self.smooth[ok]=((1-self.alpha)*self.smooth[ok]+self.alpha*np.clip(r[ok],-12,12))
        self.n[ok]+=1
        suspects=tuple(int(i) for i in np.where((self.n>=self.minimum)&(abs(self.smooth)>=self.limit))[0])
        return Status('CHANNEL_DRIFT_SUSPECT' if suspects else 'MONITORING',suspects,int(self.n.max()),
                      'Diagnostic only; never silently update optical calibration')
