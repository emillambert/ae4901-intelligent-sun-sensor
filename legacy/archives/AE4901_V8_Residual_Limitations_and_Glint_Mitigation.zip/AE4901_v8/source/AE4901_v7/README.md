# AE4901 Intelligent Sun Sensor — V7 residual-risk mitigation study

**Status: a simulated, reproducible engineering study; not a physically validated Sun sensor.** 21 November 2026. Course setup: six faces, 12 GL5537-1 LDRs, dual Arduino-class controllers, printed mounts, ~8.16° tilt and V5 estimator. It does not claim flight readiness.

## Decisions and experimental results

| Limitation | Change and evaluation | V7 recommendation |
|---|---|---|
| Strong spacecraft glints | Add an **optional independent Sun-direction prior** (another ADCS subsystem), and reject >12° disagreements. Under assumed 3° prior error, wrong >10° accepted falls 51.8% -> 18.8%, but accepted glint samples fall 61.3% -> 27.9%. No improvement in the correct direction when glints remain. An 8°-error prior is less effective, and a 20°-biased prior rejects 99% of normal readings. | Provide an external-reference interface; leave OFF by default with 12-LDR kit; do **not** claim a universal glint fix. Retain V5 eclipse, fault checks, and warnings. Avoid spacecraft reflections by integration-level baffle and mounting placement if those surfaces are known. |
| Unknown actual LDR response | Implement CSV-driven **individual calibration fitting**, with optical angle, lux (10–100), voltage-divider references, and optionally temperature; hold out unseen angles. Synthetic correctly specified example: mean per-sensor test p95 *relative resistance error* 21.59% (nominal) -> 1.96% (calibrated). This is NOT Sun-angle error and is not a hardware validation. | Use fitting and cross-validation; reject unsupported extrapolation; collect physical data later. |
| Temperature/drift | Add optional **temperature compensation** with an independently measured temperature and per-channel calibration. At assumed -10°C: p95 9.01° -> 2.37°; at +55°C 12.35° -> 2.77°. A deliberately *wrong-sign* correction at +55°C worsens p95 to 24.80° versus 12.42° unchanged. | Temperature-correct only when a calibrated temperature sensor exists; otherwise use quality warnings and the channel-drift monitor. Ground calibration alone does not solve in-orbit drift. |
| Bright Sun + filter | Retain V6 OD~3 removable-filter **experiment** for real solar levels. V6 predicted large improvement but required extrapolating LDR response; a calibrated film can itself age. | Optional; use only after verifying transmission, angular/spectral effects, response range, and material safety. No filter needed for 20–300 lux lab prototype. |
| Space environmental exposure | Add CRC-protected dual-board measurement packet, sequence/health fields, anomalous-channel monitoring and recommended environmental qualification matrix. Tests demonstrate CRC detection, not radiation tolerance. | University prototype only; flight-ready use needs component/assembly thermal-vacuum, optical aging, radiation and vibration qualifications. |

### Performance definitions

- `correct5_pct`: fraction of **all** direct-Sun samples that were accepted and had Sun-vector error <=5°.
- `wrong10_pct`: fraction of **all** direct-Sun samples accepted **despite** error >10°. Rejecting a sample does not make it accurate.
- `accepted_pct`: fraction of direct-Sun samples with an accepted vector.
- `p95_accepted_deg`: angular error only among accepted observations. Never judge a system from this statistic alone.
- Each group mean is over four synthetic sensor populations and five 28-frame sequences per scenario. Thermal results use 440 directions per population at each temperature. These are **conditional synthetic test proportions**, not on-orbit risk estimates.

## Important scope boundaries

1. A Sun-vector prior is a genuine **new information source**. In the simulator, it is produced by perturbing the true Sun vector with independent Gaussian-angle noise, with 3°, 8° or a deliberately biased 20° case. It is **not available from two Arduinos and LDRs alone**. In a safe-mode satellite, the external reference could also be offline.
2. Synthetic LDR electrical and angular parameters come from the prior V5/V6 models, not empirical GL5537-1 characterization. The thermal coefficients (about 0.4% resistance change per °C with random sign and small angular-exponent shifts) are **hypotheses**, not data-sheet specifications.
3. The calibration demo is easy by design: synthetic observations are generated from the same functional family that the fitter uses, plus noise. Real optics can deviate significantly. Its 1.96% p95 resistance residual is **not** validation that real angular error is 2% or ~2°.
4. In-flight relative channel drift can sometimes be detected from residual trends, but uniform optical aging, illumination changes and repeated glints may be indistinguishable. The monitor warns and freezes rather than silently changing sensor gain.
5. CRC detects certain corrupted communication frames; it does **not** make the CPU, analogue circuitry, LDRs or memory radiation tolerant. The `health_and_drift.py` module is a PC reference, **not compiled embedded firmware**.
6. Because GL5537 response is specified only over a narrow illuminance calibration interval, full solar-brightness performance remains an unknown. An optical-density film cannot be validated for space by a synthetic model or FDM print.

## What is actually included

- `v7_study.py`: paired synthetic glint/optional-reference and thermal-compensation tests.
- `calibrate_ldr.py`: reusable CLI on real lab CSV, conservative input validation, robust per-channel model fit, train/test metrics. `calibration_demo/SYNTHETIC_example_calibration.csv` is generated demonstration data **only**.
- `health_and_drift.py`: CRC16 framed measurement packets, conservative per-channel residual-drift warning, fail-closed lighting changes.
- `thermal_failure_mode.py`: deliberate miscalibration negative-control test.
- `test_v7.py`: unit/regression checks.
- `reference/`: V5 synthetic physical model, estimator and gating source, unchanged for audit/reproduction.
- `*.csv`, `*.png`: source-level results and figures.
- `neutral_density_holder.scad`: earlier conceptual removable ND-film holder; requires physical dimension and film checks.

## Example deployment plan (not already implemented on hardware)

**Core kit only:** use calibrated V5 vector estimator; monitor residuals/health; detect no-Sun and failed boards; transmit vector + validity flag. No autonomous self-calibration and no independent reference.

**With extra calibrated hardware:** add a temperature sensor mounted near the optical components and correct each sensor's measured response using validated per-sensor temperature coefficients. For a real LEO mission, add independently estimated attitude/ephemeris and nadir information. Run prior agreement as a diagnostic; do not make it an unqualified hard veto in safe mode.

**Environmental engineering plan:**

| Hazard | Impact | Engineering control | Required verification before flight claims |
|---|---|---|---|
| Temperature and thermal gradients | Resistance and angular calibration drift | Temperature telemetry near LDRs, per-channel calibration, validity outside characterized limits | Thermal chamber + vacuum + optical calibration at hot/cold boundaries; gradient test |
| Direct Sun and UV | Resistive response outside characterized range; film ageing | Calibrated removable neutral-density film if needed, optical window management | Solar simulator, spectrum/angle transmission, UV ageing and repeated calibration |
| Vacuum and material outgassing | Optical contamination, mount deformation | Avoid claiming hobby PLA/adhesive flight compatibility; select qualified structural/window materials | Vacuum outgassing compliance, vibration, thermal-vacuum cycles |
| Radiation/SEUs/latchup | Bit flips, hung MCU, permanent component changes | CRC/sequence/watchdog, two independently powered controllers, fault state, power-current limit | TID and SEE/radiation analysis or testing per mission orbit/duration; latchup current protection verification |
| Albedo/glints | Wrong but plausible Sun vector | Eclipse gate, cross-face and residual checks, optional ADCS consistency, spacecraft integration geometry | Earth-disk optical test / mission simulation incl cloud and geometry; measure wrong-accepted risk |
| Controller/bus failure | Missing telemetry | Both six-face boards independent, watchdog, failover | Physical unplug, power interruption and corrupted-bus tests |

The GL5537-1 commercial product page lists -30 to +70°C operating range, not vacuum, UV or radiation qualification. NASA GSFC GEVS describes environmental verification and NASA's small-spacecraft GNC overview explains why albedo rejection is limited for coarse photometric sensors.

## Reproduction

Requirements: Python 3.10+, `numpy`, `pandas`, `scipy`, `matplotlib`. In this package directory:

```sh
python -m unittest -v test_v7.py
python v7_study.py
python thermal_failure_mode.py
python calibrate_ldr.py --synthetic-example --output calibration_demo
python plot_results.py
# For actual measurements when available:
python calibrate_ldr.py --input measured_LDR_sweeps.csv --output measured_fits
```

Required real calibration CSV fields: `sensor_id,lux,angle_deg,temp_c,adc,vref_v,vcc_v,rfixed_ohm,split`. `split` is `train` or `test`, with independent direction/illumination cases in the test partition. The demonstration data are **not** substitute for those measurements.

## Sources

- NASA *Small Spacecraft Technology State of the Art — GNC*: https://www.nasa.gov/smallsat-institute/sst-soa/guidance-navigation-and-control/
- EIVE CubeSat albedo trouble and subsequent changes (2024): https://link.springer.com/article/10.1007/s12567-024-00559-7
- UPMSat-2 Sun sensor Earth-albedo modelling: https://www.mdpi.com/1424-8220/21/14/4905
- Senba GL5537-1 product spec: https://www.senbasensor.com/visible-light-sensor/5mm.html
- NASA GSFC General Environmental Verification Standard: https://standards.nasa.gov/standard/GSFC/GSFC-STD-7000
