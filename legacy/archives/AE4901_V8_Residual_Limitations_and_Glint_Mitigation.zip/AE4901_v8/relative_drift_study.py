"""V8 preliminary self-calibration from *redundant clean motion* with 12 LDRs.

Only estimates relative per-channel light response using an assumed single-source
optical model. Rejects updates when a coarse multi-sensor fit is poor. Synthetic
truth and test directions are NOT given to the estimation/calibration routine.
Do NOT auto-apply these updates in a spacecraft without independent checks.
"""
from pathlib import Path
import sys,numpy as np,pandas as pd
R=Path(__file__).resolve().parent/'source'/'AE4901_v7'/'reference';sys.path.insert(0,str(R))
from engineering_study import Model,resp,sphere,Matcher,angular, flux_to_r, divider_voltage
from validate_v3 import Estimator,recover,local_refine
HERE=Path(__file__).resolve().parent

def acquired_drift(m,s,seed,drift,glint_fraction=0.):
    rng=np.random.default_rng(seed)
    direct=80*resp(s,exponent=m.p)*drift[None,:]
    if glint_fraction:
        other=np.tile(np.array([.4,-.65,.65]),(len(s),1));other=other/np.linalg.norm(other,axis=1)[:,None]
        direct+=80*glint_fraction*resp(other,exponent=m.p)
    E=np.maximum(.01,direct+m.ambient)*(1+rng.normal(0,.008,direct.shape))
    r=flux_to_r(E,m.r10,m.gamma)
    v=divider_voltage(r,m.rfixed,m.vcc)
    ref=np.where(v<.98,m.aref[None,:],m.vcc[None,:])
    c=np.clip(np.rint(1023*v/ref+rng.normal(0,.65,v.shape)),0,1023)
    return recover(m,c,ref,cal=True,keep_negative=False)

def estimate_raw(y,clip,p,match,gain):
    x=np.maximum(0,np.nan_to_num(y)/gain[None,:]); x[clip]=0
    initial,_,_=match.query(x)
    s,res,amp=local_refine(x,initial,p,clip,iters=5)
    return s,res,amp

def update_gains(y,clip,p,matcher,iters=4):
    gains=np.ones(12)
    accepted=np.zeros(len(y),bool)
    for _ in range(iters):
        s,fit,amp=estimate_raw(y,clip,p,matcher,gains)
        pattern=resp(s,exponent=p)
        # Require a good fit and >=4 well-illuminated channels for directional diversity.
        bright=(pattern>.20)
        clean=(fit<.085)&((bright&(~clip)).sum(axis=1)>=4)
        accepted=clean
        new=gains.copy()
        for j in range(12):
            good=clean&bright[:,j]&(~clip[:,j])&(amp>12)
            if good.sum()<20:continue
            predicted=amp[good]*pattern[good,j]
            ratios=y[good,j]/np.maximum(predicted,1e-6)
            # Only correct channel-specific changes; common global illumination can't be identified.
            delta=np.median(np.log(np.clip(ratios,.5,2)))
            new[j]*=np.exp(np.clip(delta,-.06,.06))
        # Relative gains only: no absolute brightness correction.
        gains=new/np.median(new)
        gains=np.clip(gains,.7,1.3)
    return gains,100*accepted.mean()

def evaluate(s,est):
    e=angular(est,s)
    return float(np.quantile(e,.95)),float(np.mean(e<=5)*100)

def run():
    rows=[]
    for seed in [101,102,103,104,105,106]:
        m=Model(seed);matcher=Matcher(m.est_p,ngrid=11000)
        rng=np.random.default_rng(seed*11)
        drift=np.exp(rng.normal(0,.12,12));drift/=np.median(drift)
        train=sphere(1200,.21+seed*.01);test=sphere(650,.327+seed*.007)
        for contaminant in [0.,.2]:
            yc,cc=acquired_drift(m,train,seed*11+12,drift,contaminant)
            yt,ct=acquired_drift(m,test,seed*17+16,drift,0.)
            gains,clean_pct=update_gains(yc,cc,m.est_p,matcher)
            before,_,_=estimate_raw(yt,ct,m.est_p,matcher,np.ones(12))
            after,_,_=estimate_raw(yt,ct,m.est_p,matcher,gains)
            p95b,gb=evaluate(test,before);p95a,ga=evaluate(test,after)
            rows.append(dict(seed=seed,training_glint_ratio=contaminant,train_gate_pct=clean_pct,calibration_gain_mae_pct=100*np.mean(np.abs(gains-drift)),p95_before=p95b,p95_after=p95a,good5_before=gb,good5_after=ga))
        print('drift simulation population',seed,flush=True)
    f=pd.DataFrame(rows);f.to_csv(HERE/'drift_runs.csv',index=False)
    summary=f.groupby('training_glint_ratio',as_index=False).mean(numeric_only=True).drop(columns=['seed'])
    summary.to_csv(HERE/'drift_summary.csv',index=False)
    print(summary.round(2).to_string(index=False))
    return summary
if __name__=='__main__':run()
