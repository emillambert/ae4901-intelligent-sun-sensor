"""Nominal GL5537-1 voltage divider calculation. NOT a verified bright-Sun model.
Data-sheet gamma was specified from 10 to 100 lux; 100,000 lux is extrapolated
solely to illustrate why a direct-sunlight filter merits a physical test.
"""
from pathlib import Path
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent
r10=25000.;gamma=.6;rfixed=30000.;vcc=5.;vref=1.1
rows=[]
for incident_lux in (100,1000,10000,80000,100000,130000):
    for nd in (0.,2.5,3.,3.2,3.5):
        E=incident_lux*10**(-nd)
        R=r10*(E/10)**(-gamma)
        V=vcc*R/(rfixed+R)
        ref=vref if V<1.0 else vcc
        adc=round(np.clip(1023*V/ref,0,1023))
        rows.append(dict(incident_lux=incident_lux,optical_density=nd,sensor_equivalent_lux=E,
                         within_10_100_lux_spec=10<=E<=100,nominal_resistance_ohm=R,
                         adc_reference_v=ref,estimated_adc_counts=adc,ideal_adc_voltage_v=V))
pd.DataFrame(rows).to_csv(HERE/'brightness_tradeoffs.csv',index=False)
print(pd.DataFrame(rows).query('incident_lux==100000')[['optical_density','sensor_equivalent_lux','within_10_100_lux_spec','adc_reference_v','estimated_adc_counts']].to_string(index=False))
