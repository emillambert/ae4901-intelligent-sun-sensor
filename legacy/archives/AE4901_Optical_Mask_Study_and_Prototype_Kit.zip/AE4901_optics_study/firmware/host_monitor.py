#!/usr/bin/env python3
"""AE4901 dual-controller host display, logging, and provisional Sun-vector estimator.
Usage: python host_monitor.py --demo --seconds 10 --headless
       python host_monitor.py --port-a /dev/cu.usbmodemA --port-b /dev/cu.usbmodemB
Requires: numpy scipy matplotlib pyserial (serial mode only).
CAUTION: output is PROVISIONAL until the real GL5537-1 optical/electrical calibration
is measured and incorporated into the inverse model in optics_study.py.
"""
import argparse,csv,time,sys
from pathlib import Path
from collections import deque
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from optics_study import NOM_N,rodrigues,flux_to_adc,adc_to_flux,lookup_tree,predict

def parse_packet(line):
    p=line.strip().split(',')
    if len(p)!=15 or p[0]!='SUN':return None
    try:
        bid,seq,millis=[int(x) for x in p[1:4]]
        adc=np.array([int(x) for x in p[4:10]])
        vec=np.array([float(x) for x in p[10:13]])
        flags,valid=int(p[13]),bool(int(p[14]))
        if bid not in (0,1) or np.any(adc<0) or np.any(adc>1023):return None
        return dict(id=bid,seq=seq,millis=millis,adc=adc,vec=vec,flags=flags,valid=valid,received=time.monotonic())
    except (ValueError,IndexError):return None

def demo_packets(t):
    sun=np.array([np.cos(t*.22)*np.cos(.5),np.sin(t*.22)*np.cos(.5),np.sin(.5)])
    E=10+80*np.maximum(0,NOM_N@sun)
    adc=flux_to_adc(E[None,:],np.full(12,25000.),np.full(12,.6))[0]
    out=[]
    for j in (0,1):
        dd=np.clip(np.rint(adc[j::2]),1,1022).astype(int)
        sub=NOM_N[j::2]@sun
        obs=np.maximum(sub,0)
        v=np.array([obs[0]-obs[1],obs[2]-obs[3],obs[4]-obs[5]])
        v=rodrigues([1,1,1],10 if j==0 else -10)@v
        v=v/(np.linalg.norm(v)+1e-12)
        out.append(dict(id=j,seq=int(t*10),millis=int(t*1000),adc=dd,vec=v,flags=0,valid=True,received=time.monotonic()))
    return out

class SunState:
    def __init__(self):
        self.last={}
        self.bare={'kind':'bare','detector_radius':2.0,'h':0,'aperture_radius':100,'offset':0}
        self.trees={b:lookup_tree(self.bare,22000,b) for b in [None,0,1]}
    def ingest(self,packet):self.last[packet['id']]=packet
    def compute(self):
        now=time.monotonic();available=[i for i in (0,1) if i in self.last and now-self.last[i]['received']<1.2]
        if not available:return None,'NO DATA',[]
        board=None if len(available)==2 else available[0]
        full=np.zeros((1,12))
        warnings=[]
        for id in available:
            p=self.last[id];counts=p['adc']
            R10=np.full(6,25000.);gam=np.full(6,.60)
            # Demo nominal values. Replace with fitted per-channel calibration.
            lux=adc_to_flux(counts[None,:],R10,gam)[0]
            # Ambient tare must be measured; do not subtract an invented value.
            full[0,id::2]=np.maximum(lux,0)
            if p['flags']:warnings.append(f'Board {id} rail flags: 0x{p["flags"]:02X}')
        est,fit=predict(self.trees[board],full,board)
        va=est[0]
        if len(available)==2:
            x,y=self.last[0]['vec'],self.last[1]['vec']
            disagree=np.rad2deg(np.arccos(np.clip(float(x@y),-1,1)))
            if disagree>15:warnings.append(f'Controller disagreement {disagree:.1f} deg')
        else: warnings.append(f'DEGRADED: only controller {available[0]} online')
        warnings.append('UNVALIDATED: nominal calibration + optical response')
        return va,f'fit residual {fit[0]:.3f}',warnings

def main():
    p=argparse.ArgumentParser();p.add_argument('--port-a');p.add_argument('--port-b');p.add_argument('--demo',action='store_true');p.add_argument('--seconds',type=float,default=0)
    p.add_argument('--headless',action='store_true');p.add_argument('--log',default='sun_telemetry.csv');args=p.parse_args()
    if not args.demo and not(args.port_a or args.port_b):p.error('Set --demo or at least one serial port')
    serials={}
    if not args.demo:
        import serial
        for b,port in [(0,args.port_a),(1,args.port_b)]:
            if port:serials[b]=serial.Serial(port,115200,timeout=.03)
    state=SunState();start=time.monotonic()
    if not args.headless:
        import matplotlib.pyplot as plt
        plt.ion();fig=plt.figure(figsize=(7,6));ax=fig.add_subplot(111,projection='3d')
    with open(args.log,'w',newline='') as ff:
        w=csv.writer(ff);w.writerow(['t','board','seq','millis','adc0','adc1','adc2','adc3','adc4','adc5','xcoarse','ycoarse','zcoarse','flags','valid'])
        lastdraw=0
        try:
            while args.seconds<=0 or time.monotonic()-start<args.seconds:
                t=time.monotonic()-start
                arr=demo_packets(t) if args.demo else []
                for b,s in serials.items():
                    line=s.readline().decode('ascii',errors='ignore')
                    pkt=parse_packet(line)
                    if pkt and pkt['id']==b:arr.append(pkt)
                for pkt in arr:
                    state.ingest(pkt)
                    w.writerow([round(t,3),pkt['id'],pkt['seq'],pkt['millis'],*pkt['adc'].tolist(),*pkt['vec'].tolist(),pkt['flags'],int(pkt['valid'])])
                if t-lastdraw>=.25:
                    v,status,warnings=state.compute();lastdraw=t
                    if args.headless:
                        print(f'{t:.1f}s Sun={np.round(v,3) if v is not None else "none"} | {status} | {"; ".join(warnings)}')
                    else:
                        ax.cla();ax.set(xlim=(-1,1),ylim=(-1,1),zlim=(-1,1),xlabel='Body X',ylabel='Body Y',zlabel='Body Z')
                        if v is not None:ax.quiver(0,0,0,*v,length=1,color='#196ea6',arrow_length_ratio=.18)
                        ax.set_box_aspect((1,1,1));ax.set_title('Provisional Sun vector\n'+status+'\n'+'; '.join(warnings),fontsize=9)
                        plt.pause(.001)
                time.sleep(.02)
        except KeyboardInterrupt:pass
    for s in serials.values():s.close()
    print('Saved telemetry to',args.log)
if __name__=='__main__':main()
