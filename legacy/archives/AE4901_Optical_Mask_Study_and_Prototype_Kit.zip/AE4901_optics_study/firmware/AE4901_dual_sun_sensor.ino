/* AE4901 Sun Sensor - 6 GL5537-1 LDRs per Arduino (2026 design starter)
   Flash one board with BOARD_ID=0 (A) and the other with BOARD_ID=1 (B).
   Channel order is +X,-X,+Y,-Y,+Z,-Z. Each pair is opposite CubeSat faces.
   Sensors are oriented by +/-10 degree rotations about [1,1,1].
   Circuit per channel: +5V--30k fixed resistor--A0..A5--LDR--GND.
   IMPORTANT: This firmware's approximate lux conversion and cosine reconstruction
   are placeholders until real GL5537-1 and angular calibration are completed.
   USB and 5V rails are NOT independent controller-failure tolerant power supplies.
*/
#include <Arduino.h>
#ifdef __AVR__
#include <avr/wdt.h>
#endif

#define BOARD_ID 0  // CHANGE TO 1 ON SECOND CONTROLLER
const uint8_t pins[6]={A0,A1,A2,A3,A4,A5};
const float fixedR[6]={30000,30000,30000,30000,30000,30000};
const float r10[6]={25000,25000,25000,25000,25000,25000}; // CALIBRATE individually
const float gammaLDR[6]={.60,.60,.60,.60,.60,.60}; // CALIBRATE individually
const float ambientLux[6]={0,0,0,0,0,0}; // set from dark baseline measurements
const unsigned long SAMPLE_MS=100; // 10 Hz output, sensor response ~30 ms
unsigned long lastSample=0;
uint32_t sequence=0;

void setup(){
 Serial.begin(115200);
 analogReference(DEFAULT); // both Vref and divider are Vcc, ratiometric
 for (int i=0;i<6;i++) pinMode(pins[i],INPUT);
#ifdef __AVR__
 wdt_enable(WDTO_2S);
#endif
}

int medianOf5(int pin){
 int v[5];
 for(int i=0;i<5;i++){
   analogRead(pin); // discard first result after multiplexer change
   delayMicroseconds(150); // extra settling time for high-resistance channels
   v[i]=analogRead(pin);
 }
 for(int i=1;i<5;i++){
   int x=v[i],j=i-1;
   while(j>=0 && v[j]>x){v[j+1]=v[j]; j--;}
   v[j+1]=x;
 }
 return v[2];
}
float adcToLux(int adc,int i){
 float c=constrain(adc,1,1022);
 float resistance=fixedR[i]*c/(1023.0f-c);
 float illuminance=10.0f*powf(resistance/r10[i],-1.0f/gammaLDR[i]);
 return max(0.0f,illuminance-ambientLux[i]);
}
void normalize(float v[3]){
 float n=sqrtf(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
 if(n>1e-8f){for(int i=0;i<3;i++)v[i]/=n;}
 else {v[0]=v[1]=v[2]=0;}
}
void rotateDiagonal(float v[3]){
 // Rodrigues rotation about normalized [1,1,1] by +/-10 degrees.
 const float k=0.57735026919f;
 const float cs=.98480775301f;
 float sn=.17364817767f*(BOARD_ID==0?1.0f:-1.0f);
 float dot=k*(v[0]+v[1]+v[2]);
 float cross[3]={k*(v[2]-v[1]),k*(v[0]-v[2]),k*(v[1]-v[0])};
 for(int i=0;i<3;i++)v[i]=cs*v[i]+sn*cross[i]+k*dot*(1-cs);
}
void loop(){
#ifdef __AVR__
 wdt_reset();
#endif
 unsigned long now=millis();
 if(now-lastSample<SAMPLE_MS)return;
 lastSample=now;
 int adc[6]; float lux[6];uint16_t flags=0;
 for(int i=0;i<6;i++){
   adc[i]=medianOf5(pins[i]);
   lux[i]=adcToLux(adc[i],i);
   // rail warning, not proof of a failed sensor. Dark LDR can approach high rail.
   if(adc[i]<=3 || adc[i]>=1020)flags|=(1<<i);
 }
 float local[3]={lux[0]-lux[1],lux[2]-lux[3],lux[4]-lux[5]};
 float amplitude=sqrtf(local[0]*local[0]+local[1]*local[1]+local[2]*local[2]);
 bool valid=(amplitude>2.0f);
 normalize(local);
 rotateDiagonal(local);
 // Packet: SUN,id,seq,millis,adc0..adc5,x,y,z,rail_flags,coarse_valid
 Serial.print("SUN,");Serial.print(BOARD_ID);Serial.print(',');
 Serial.print(sequence++);Serial.print(',');Serial.print(now);
 for(int i=0;i<6;i++){Serial.print(',');Serial.print(adc[i]);}
 for(int i=0;i<3;i++){Serial.print(',');Serial.print(local[i],5);}
 Serial.print(',');Serial.print(flags);Serial.print(',');Serial.println(valid?1:0);
}
