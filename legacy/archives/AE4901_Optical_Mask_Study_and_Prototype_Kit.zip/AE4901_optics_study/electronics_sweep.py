#!/usr/bin/env python3
"""Illustrative LDR divider transfer from manufacturer gamma near 10/100 lux.
Extrapolations outside that datasheet region must not be treated as validated.
"""
from pathlib import Path
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).parent/'results'
E=np.logspace(-1,5,650)
fig,ax=plt.subplots(figsize=(9,4.4),layout='constrained')
for r in (330,3000,30000,100000):
 R=25000*(E/10)**(-.6)
 adc=1023*R/(R+r)
 ax.plot(E,adc,label=f'{r/1000:g} kOhm fixed')
ax.axvspan(10,100,color='gray',alpha=.08,label='Nominal datasheet gamma calibration region')
ax.set(xscale='log',xlabel='Incident illuminance, lux (hypothetical extrapolation)',ylabel='10-bit ADC counts',ylim=(0,1030),title='GL5537-1 divider range: using one resistor for all light levels is risky')
ax.grid(alpha=.2);ax.legend(fontsize=8,ncol=2)
fig.savefig(O/'divider_dynamic_range.png',dpi=170);plt.close(fig)
for lux in (1,10,20,80,100,100000):
 R=25000*(lux/10)**(-.6)
 print(f'{lux} lux: R~{R:.1f} ohms, 30k divider reading~{1023*R/(R+30000):.1f}/1023 (nominal extrapolation)')
