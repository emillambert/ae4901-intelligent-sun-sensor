#!/usr/bin/env python3
"""AE4901 12-GL5537-1 sun-sensor passive-baffle feasibility study.

Independent, explicitly hypothetical optical and electrical models. This is NOT
experimental validation, nor a prediction of the real packaged LDR response.

Assumptions:
  * each face has one sensor per Arduino; axes are +/-10 degree rigid rotation
    about spacecraft [1,1,1] (optical tilt 8.16 degrees from face normal).
  * point-source irradiance ~ cos(theta)^1.15, opaque CubeSat face back-shadow.
  * a printed cap is modelled as a zero-thickness circular aperture at depth h
    above a uniformly responding circular detector, using exact two-circle overlap.
    Real printed rims, epoxy, scattering, finite sun/lamp source and stray rays
    are NOT accurately predicted.
  * GL5537-1 approx R(E)=R10*(E/10lux)^(-gamma) with 25 kOhm @10 lux,
    gamma 0.6, 30 kOhm fixed resistor, 10-bit Arduino ADC.
  * calibrated decoder knows individual R10/gamma and nominal optical model;
    adversarial tests vary optical axes, aperture dimensions and response exponent.
  * full-sky direction estimated with nearest-response normalized lookup table;
    this is a different algorithm from prior full-rank linear least-squares model.

Usage: python optics_study.py --out results
"""
import argparse, csv, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

FACES=np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],float)
FACE_NAMES=['+X','-X','+Y','-Y','+Z','-Z']
NCHAN=12

def sphere(k, offset=0.0):
    i=np.arange(k,dtype=float)+offset
    z=1.-2.*(i+0.5)/k
    t=i*np.pi*(3-np.sqrt(5))
    a=np.sqrt(np.maximum(0,1-z*z))
    return np.column_stack((a*np.cos(t),a*np.sin(t),z))

def rodrigues(axis, deg):
    u=np.asarray(axis,float);u/=np.linalg.norm(u)
    K=np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]])
    t=np.deg2rad(deg)
    return np.eye(3)+np.sin(t)*K+(1-np.cos(t))*(K@K)

R=rodrigues([1,1,1],10)
NOM_N=np.array([a@face for face in FACES for a in (R,R.T)])
FACE_N=np.repeat(FACES,2,axis=0)

# Consistent tangent axes for normal-space offset aperture A(+), B(-)
def basis_for(normals):
    out1=[];out2=[]
    for i,n in enumerate(normals):
        a=FACE_N[i].copy()
        seed=np.array([0.,0.,1.]) if abs(n[2])<.8 else np.array([0.,1.,0.])
        u=np.cross(seed,n);u/=np.linalg.norm(u)
        v=np.cross(n,u)
        out1.append(u);out2.append(v)
    return np.asarray(out1),np.asarray(out2)

U,V=basis_for(NOM_N)


def circle_overlap(a,r,d):
    """Area of overlap of projected circular aperture (a) and detector disk (r).
    Supports vectorized arrays and broadcastable geometry.
    """
    a=np.broadcast_to(np.asarray(a,float),np.shape(d))
    r=np.broadcast_to(np.asarray(r,float),np.shape(d))
    d=np.asarray(d,float)
    area=np.zeros_like(d)
    inside=d<=np.abs(a-r)
    area[inside]=np.pi*np.minimum(a[inside],r[inside])**2
    part=(d>np.abs(a-r))&(d<a+r)
    x=d[part];aa=a[part];rr=r[part]
    ta=np.arccos(np.clip((x*x+aa*aa-rr*rr)/(2*x*aa),-1,1))
    tr=np.arccos(np.clip((x*x+rr*rr-aa*aa)/(2*x*rr),-1,1))
    area[part]=aa*aa*ta+rr*rr*tr-.5*np.sqrt(np.maximum(0,(-x+aa+rr)*(x+aa-rr)*(x-aa+rr)*(x+aa+rr)))
    return area/(np.pi*r*r)


def response(sun, spec, normals=NOM_N, exponent=1.15, cap_perturb=None):
    """Normalized direct-light responses, shape [sun directions, 12]."""
    s=np.asarray(sun,float)
    normal=np.asarray(normals,float)
    co=s@normal.T
    facevis=(s@FACE_N.T)>0
    positive=np.maximum(co,0)
    if np.ndim(exponent): p=np.asarray(exponent)[None,:]
    else:p=exponent
    out=positive**p
    if spec['kind']!='bare':
        h=np.full(12,spec['h'],float)
        a=np.full(12,spec['aperture_radius'],float)
        offs=np.full(12,spec.get('offset',0.0),float)*np.where(np.arange(12)%2==0,1,-1)
        if cap_perturb is not None:
            h+=cap_perturb['height'];a+=cap_perturb['radius'];offs+=cap_perturb['offset']
        c=np.maximum(co,1e-8)
        x=h[None,:]*(s@U.T)/c-offs[None,:]
        y=h[None,:]*(s@V.T)/c
        displacement=np.hypot(x,y)
        T=circle_overlap(a[None,:],spec['detector_radius'],displacement)
        if 'board_mask' in spec:
            # Hybrid: keep six bare reference sensors and mask only one Arduino's six.
            T[:,np.arange(12)%2!=spec['board_mask']]=1.0
        out*=T
    out*=facevis & (co>0)
    return out


def fov_fraction(spec):
    """Approximate diffuse light attenuation for a uniform hemispherical field.
    This is not a validated stray-light model; only used in sensitivity testing.
    """
    dirs=sphere(2500,.19)
    bare=response(dirs,{'kind':'bare'})
    masked=response(dirs,spec)
    return np.sum(masked,axis=0)/(np.sum(bare,axis=0)+1e-9)

# Realistic _electrical_ transfer approximation, not fitted LDR angular response.
# LDR to ground, reference resistor to Vcc. ADC =1023*Rldr/(Rldr+Rfixed)
# In bright light resistance decreases, so ADC decreases.
def flux_to_adc(flux, r10, gamma, rfixed=30000):
    Rldr=r10[None,:]*(np.maximum(flux,.06)/10.)**(-gamma[None,:])
    Rldr=np.minimum(Rldr,2e6)
    return 1023*Rldr/(Rldr+rfixed)

def adc_to_flux(counts, r10,gamma,rfixed=30000):
    y=np.clip(counts,1,1022.0)
    Rldr=rfixed*y/(1023-y)
    return 10.*(Rldr/r10[None,:])**(-1./gamma[None,:])


def measurements(sun,spec,rng,scenario,brightness=80,keep=None, actual_normals=None):
    """Convert hypothetical point-source lux to noisy 10-bit ADC and back after calibration."""
    R10=25000*rng.lognormal(0,.08,12)
    gamma=np.clip(.60+rng.normal(0,.035,12),.48,.72)
    noise_lux=0.0
    cap_perturb=None
    exp=1.15
    if scenario=='mismatch':
        exp=np.clip(rng.normal(1.15,.10,12),.80,1.50)
        cap_perturb={'height':rng.normal(0,.12,12),'radius':rng.normal(0,.11,12),'offset':rng.normal(0,.10,12)}
        normal=actual_normals if actual_normals is not None else perturb_normals(NOM_N,rng,1.0)
        noise_lux=.7
    elif scenario=='nominal': normal=NOM_N
    elif scenario=='ideal': normal=NOM_N
    else: raise ValueError(scenario)
    g=response(sun,spec,normal,exp,cap_perturb)
    # diffuse background around source and per-channel uncontrolled residual, in lux
    diffuse_ratio=fov_fraction(spec)
    flux=brightness*g + 2.*diffuse_ratio[None,:]
    if noise_lux: flux+=rng.normal(0,noise_lux,(len(sun),12))
    # independent lamp flicker / sensor noise
    flux=flux*(1+rng.normal(0,.012,flux.shape))
    adcc=flux_to_adc(np.maximum(flux,.04),R10,gamma)
    adcc=np.clip(np.rint(adcc+rng.normal(0,1.,adcc.shape)),1,1022)
    # Individual electrical calibration recovers the light level; ambient tare measured separately
    E=adc_to_flux(adcc,R10,gamma)-2.*diffuse_ratio[None,:]
    E=np.maximum(0,E)
    if keep is not None: E[:,~keep]=0
    return E


def perturb_normals(normals,rng,sigma_deg):
    Rn=normals.copy()
    for i,n in enumerate(normals):
        k=rng.normal(size=3);k-=k.dot(n)*n;k/=np.linalg.norm(k)
        v=n*np.cos(np.deg2rad(sigma_deg))+k*np.sin(np.deg2rad(sigma_deg))
        Rn[i]=v/np.linalg.norm(v)
    return Rn


def lookup_tree(spec,npts,board=None):
    sky=sphere(npts,.013)
    y=response(sky,spec)
    if board is not None:y=y[:,np.arange(12)%2==board]
    norms=np.linalg.norm(y,axis=1)
    valid=norms>1e-8
    patterns=y[valid]/norms[valid,None]
    return cKDTree(patterns,balanced_tree=True),sky[valid]


def predict(tree_data,obs,board=None):
    tree,sky=tree_data
    if board is not None:obs=obs[:,np.arange(12)%2==board]
    norm=np.linalg.norm(obs,axis=1)
    nn=np.zeros_like(obs)
    good=norm>1e-6
    nn[good]=obs[good]/norm[good,None]
    d,ind=tree.query(nn,k=1,workers=-1)
    estimated=sky[ind]
    return estimated,d


def metric(est,gt,dist=None):
    e=np.rad2deg(np.arccos(np.clip(np.sum(est*gt,axis=1),-1,1)))
    return {'median_deg':round(float(np.median(e)),3),
            'p95_deg':round(float(np.quantile(e,.95)),3),
            'p99_deg':round(float(np.quantile(e,.99)),3),
            'within_5_pct':round(float(100*np.mean(e<=5)),2),
            'above_15_pct':round(float(100*np.mean(e>15)),2),
            'fit_p95':round(float(np.quantile(dist,.95)),4) if dist is not None else None}


def run_design(spec,test_sun,scenario,sky_n=30000,seed=2026, brightness=80,board=None):
    rr=np.random.default_rng(seed)
    keep=(np.arange(12)%2==board) if board is not None else None
    y=measurements(test_sun,spec,rr,scenario,brightness,keep)
    tr=lookup_tree(spec,sky_n,board)
    estimate,dist=predict(tr,y,board)
    return metric(estimate,test_sun,dist)


def shortlist():
    out=[{'name':'BARE','kind':'bare','h':0.,'aperture_radius':np.inf,'offset':0.,'detector_radius':2.0}]
    for h in [.6,1.2,1.8,2.5,3.5]:
        for a in [2.4,2.8,3.2,3.6]:
            out.append({'name':f'circular_h{h:.1f}_a{a:.1f}','kind':'round','h':h,'aperture_radius':a,'offset':0.,'detector_radius':2.0})
    # Asymmetric A/B top aperture offset: only informative if direct response is not cosine-symmetric
    for h,a,off in [(1.2,2.8,.5),(1.8,3.2,.6),(2.5,3.2,.8)]:
        out.append({'name':f'offset_h{h:.1f}_a{a:.1f}_o{off:.1f}','kind':'offset','h':h,'aperture_radius':a,'offset':off,'detector_radius':2.0})
    return out


def main(out):
    out.mkdir(parents=True,exist_ok=True)
    # Internal verification of circular optical mask model and basic LDR math
    assert abs(circle_overlap(np.array([3.]),2.,np.array([0.]))[0]-1)<1e-12
    assert abs(circle_overlap(np.array([1.]),2.,np.array([0.]))[0]-.25)<1e-12
    assert circle_overlap(np.array([2.]),2.,np.array([4.1]))[0]==0
    assert np.allclose(np.linalg.eigvalsh(NOM_N.T@NOM_N),[4,4,4],atol=1e-10)
    e=np.array([[1.,10.,100.] + [10.]*9]);rr=np.full(12,25000.);ga=np.full(12,.6)
    assert np.allclose(adc_to_flux(flux_to_adc(e,rr,ga),rr,ga),e,rtol=1e-10)
    candidates=shortlist()
    # Phase A optimization from data independent of final evaluation test vectors
    train_sun=sphere(2600,.217)
    rows=[]
    for i,spec in enumerate(candidates):
        summary=run_design(spec,train_sun,'ideal',sky_n=17000,seed=12345,brightness=80)
        row={'name':spec['name'],'type':spec['kind'],'depth_mm':spec['h'], 'opening_radius_mm':spec['aperture_radius'] if np.isfinite(spec['aperture_radius']) else 0,
            'opening_offset_mm':spec['offset'],'diffuse_fraction':round(float(np.mean(fov_fraction(spec))),3),**summary}
        rows.append(row)
        print(f"Scan {i+1}/{len(candidates)} {spec['name']}: p95 {summary['p95_deg']}°, <=5 {summary['within_5_pct']}%",flush=True)
    rank=pd.DataFrame(rows)
    rank['score']=rank.p95_deg+(.1*(100-rank.within_5_pct))+rank.above_15_pct*.05
    rank=rank.sort_values('score').reset_index(drop=True)
    rank.to_csv(out/'mask_parameter_search.csv',index=False)
    # Shortlist 3 distinct geometries plus bare, including a deliberate narrow high depth contrast
    chosen=[candidates[0]]
    for _,row in rank.iterrows():
        s=next(x for x in candidates if x['name']==row['name'])
        if s['kind']=='bare':continue
        if all(abs(s['h']-x['h'])>.25 or abs(s['aperture_radius']-x['aperture_radius'])>.25 or s['kind']!=x['kind'] for x in chosen):
            chosen.append(s)
        if len(chosen)==4:break
    deep=next(x for x in candidates if x['name']=='circular_h3.5_a2.4')
    if deep not in chosen:chosen.append(deep)
    off=next(x for x in candidates if x['name']=='offset_h1.8_a3.2_o0.6')
    if off not in chosen:chosen.append(off)
    # Save chosen config for printable CAD
    (out/'selected_masks.json').write_text(json.dumps(chosen,indent=2))
    # Phase B independent held-out directions, multiple levels / model mismatch / failures
    heldout=sphere(4300,.74321)
    tests=[]
    for s in chosen:
        for scenario,level,board in [
            ('ideal',80,None),('ideal',20,None),('mismatch',80,None),('mismatch',20,None),
            ('ideal',80,0),('ideal',80,1),('mismatch',80,0),('mismatch',80,1)
        ]:
            # exact same source of random between designs for fair comparison
            m=run_design(s,heldout,scenario,sky_n=70000,seed=1742+(level*10)+(1 if scenario=='mismatch' else 0),brightness=level,board=board)
            tests.append({'name':s['name'],'scenario':scenario,'brightness_lux':level,'board':('Both' if board is None else 'A only' if board==0 else 'B only'),**m})
            print('Final',s['name'],scenario,level,board,m['p95_deg'],m['within_5_pct'],flush=True)
    results=pd.DataFrame(tests)
    results.to_csv(out/'independent_holdout_results.csv',index=False)
    # sensitivity to nonlinear optical exponent under varied amplitude (not a real measured device)
    # demonstrate field-angle / intensity map for bare and chosen best
    fig, ax=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    top=rank.head(11).sort_values('score')
    ax[0].barh(top['name'][::-1],top['p95_deg'][::-1])
    ax[0].set_xlabel('Angular p95 (degrees), synthetic 80-lux test');ax[0].set_title('Training/selection subset, not independent validation')
    selection=results[(results.scenario=='ideal')&(results.brightness_lux==80)&(results.board=='Both')]
    base=selection.loc[selection.name=='BARE','p95_deg'].iloc[0]
    xx=np.arange(len(selection))
    ax[1].bar(xx,selection['p95_deg']);ax[1].axhline(base,ls='--',lw=1,color='black',label='Bare reference')
    ax[1].set_xticks(xx,selection['name'],rotation=60,ha='right',fontsize=7)
    ax[1].set(ylabel='p95 angular error (degrees)',title='Independent directions, calibrated model')
    ax[1].legend(fontsize=8)
    fig.savefig(out/'mask_comparison.png',dpi=170)
    plt.close(fig)
    # reliability plot: optional vs source brightness
    comp=results[(results.scenario=='mismatch')&(results.brightness_lux==80)]
    fig,ax=plt.subplots(figsize=(10,5),layout='constrained')
    cols={'Both':'#277da1','A only':'#e09f3e','B only':'#a05195'}
    grp=[*comp['name'].unique()]
    xx=np.arange(len(grp));w=.24
    for j,(b,cc) in enumerate(cols.items()):
        ss=comp[comp.board==b].set_index('name').reindex(grp)
        ax.bar(xx+(j-1)*w,ss['within_5_pct'],width=w,color=cc,label=b)
    ax.set_xticks(xx,grp,rotation=25,ha='right',fontsize=8)
    ax.set(ylabel='Directions reconstructed within 5° (%)',ylim=(0,103),title='Robustness when optical model differs from actual device')
    ax.legend();fig.savefig(out/'controller_failover.png',dpi=170);plt.close(fig)
    # A small model figure with ray path and aperture overlap at 0,30,50 deg
    fig,ax=plt.subplots(1,3,figsize=(10,3.6),layout='constrained')
    s=chosen[1]
    a=s['aperture_radius'];h=s['h'];r=s['detector_radius']
    for p,ang in zip(ax,[0,30,50]):
        shift=h*np.tan(np.deg2rad(ang))
        p.add_patch(plt.Circle((0,0),r,fill=True,color='#b3cde3',alpha=.7,label='LDR active disk'))
        p.add_patch(plt.Circle((shift,0),a,fill=False,ec='#eb6d49',lw=2,label='Projected aperture'))
        trans=circle_overlap(np.array([a]),r,np.array([shift]))[0]
        p.set(xlim=(-5,5),ylim=(-5,5),aspect='equal',title=f'{ang}°: {trans:.0%} clear area')
        p.axis('off')
    fig.suptitle('Idealized circular opening projected onto the LDR plane (not a ray-traced package)')
    fig.savefig(out/'mask_optical_principle.png',dpi=170);plt.close(fig)
    report={
      'selected':chosen,
      'best_ranked':rank[['name','p95_deg','within_5_pct','score']].head(8).to_dict('records'),
      'holdout':tests,
      'assumptions':{'sensor_model':'cos(theta)^1.15 face-shadowed; 5 mm packaged LDR represented by 4.0 mm uniform active disk',
          'optoelectronics':'R10=25 kOhm nominal, gamma=0.6, 30k fixed resistor, 10-bit ADC, 1 LSB noise',
          'mask_model':'circular-aperture geometric overlap, black nonreflective optical cavity; no actual light ray trace',
          'optical_exponent_uncertainty':'per channel sigma 0.10 in mismatch scenario; per-channel cap dimensions sigma 0.1 mm',
          'ambient':'2 lux diffuse ambient; uncertainty sigma 0.7 lux in mismatch scenario',
          'heldout':'4300 deterministic quasi-uniform directions not used in mask selection',
          'estimator':'direction nearest-match normalized optical-response lookup; brightness is a nuisance amplitude; lookup resolution 70,000 directions'}
    }
    (out/'run_metadata.json').write_text(json.dumps(report,indent=2))
    print('\nTOP OPTIMIZATION\n',rank[['name','p95_deg','within_5_pct','score']].head(8).to_string(index=False))
    print('\nHOLDOUT\n',results[(results.brightness_lux==80)&(results.board=='Both')][['name','scenario','p95_deg','within_5_pct','above_15_pct']].to_string(index=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='results')
    args=parser.parse_args();main(Path(args.out))
