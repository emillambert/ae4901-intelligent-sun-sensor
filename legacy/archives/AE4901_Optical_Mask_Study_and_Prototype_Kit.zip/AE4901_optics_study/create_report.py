from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

ROOT=Path(__file__).parent; O=ROOT/'results'
OUT=ROOT/'AE4901_optics_research_report.pdf'
pdfmetrics.registerFont(TTFont('Lato','/usr/share/fonts/truetype/lato/Lato-Regular.ttf'))
pdfmetrics.registerFont(TTFont('LatoB','/usr/share/fonts/truetype/lato/Lato-Bold.ttf'))
NAVY=HexColor('#162A3B');BLUE=HexColor('#20607C');GREY=HexColor('#5A6974');BORDER=HexColor('#E1E8EB');LIGHT=HexColor('#F1F6F8');RED=HexColor('#9A4438')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleX',fontName='LatoB',fontSize=22,leading=26,textColor=NAVY,spaceAfter=10))
styles.add(ParagraphStyle(name='SubX',fontName='Lato',fontSize=10.2,leading=15,textColor=GREY,spaceAfter=16))
styles.add(ParagraphStyle(name='SecX',fontName='LatoB',fontSize=13.3,leading=16,textColor=NAVY,spaceBefore=15,spaceAfter=8))
styles.add(ParagraphStyle(name='BodyX',fontName='Lato',fontSize=9.2,leading=13,textColor=NAVY,spaceAfter=7))
styles.add(ParagraphStyle(name='SmallX',fontName='Lato',fontSize=8.1,leading=10.9,textColor=GREY,spaceAfter=5))
styles.add(ParagraphStyle(name='TblX',fontName='Lato',fontSize=8.4,leading=11.5,textColor=NAVY))
styles.add(ParagraphStyle(name='TblHeadX',fontName='LatoB',fontSize=8.4,leading=11,textColor=NAVY))
styles.add(ParagraphStyle(name='LeadX',fontName='LatoB',fontSize=11.8,leading=16,textColor=BLUE,spaceAfter=12))

W,H=A4

def draw_page(canv,doc):
 canv.saveState()
 canv.setStrokeColor(BORDER);canv.setLineWidth(.6)
 canv.line(42,38,W-42,38)
 canv.setFont('Lato',8);canv.setFillColor(GREY)
 canv.drawString(42,26,'AE4901  |  Computational optics feasibility study  |  21 Nov 2026')
 canv.drawRightString(W-42,26,str(doc.page))
 canv.restoreState()

doc=SimpleDocTemplate(str(OUT),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=41,bottomMargin=50)
flow=[]
P=lambda s,kind='BodyX':Paragraph(s,styles[kind])

def sec(title):flow.append(P(title,'SecX'))
def para(s):flow.append(P(s))
def tab(headers,rows,widths):
 data=[[P(x,'TblHeadX') for x in headers]]+[[P(str(x),'TblX') for x in row] for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT),('GRID',(0,0),(-1,-1),.38,BORDER),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
 flow.append(t)

def img(name,width=500):
 from PIL import Image as PILImage
 im=PILImage.open(O/name)
 ratio=im.height/im.width
 flow.append(Image(str(O/name),width=width,height=width*ratio))

flow.append(P('AE4901 / INTELLIGENT SUN SENSOR','SubX'))
flow.append(P('Do 3D-printed optical masks improve a 12-LDR Sun sensor?','TitleX'))
flow.append(P('Numerical optimization, error-budget review, printable design files and physical validation plan','SubX'))
flow.append(P('Finding: the bare-LDR layout performed better than the tested masks in the principal simulation and additional robustness tests.','LeadX'))
para('We modeled the agreed six-face, twelve-LDR and dual-controller architecture, with two sensing sets rotated ±10 degrees about the CubeSat [1,1,1] diagonal (each optical axis 8.1615 degrees from the face normal). We screened 23 printed-aperture configurations plus the bare reference, including shallow, deep and laterally offset openings. Evaluation used held-out Sun directions not used for optimization.')
para('<b>Scope:</b> This is computational verification of a proposed design, not physical sensor validation. The true GL5537-1 angular response, effective active area, light-scattering behaviour, electrical noise and printed dimensional accuracy remain unmeasured.')
sec('Key comparative results')
tab(['Scenario, 80 lux unless shown','Bare LDR','Shallow mask 0.6 mm / 3.6 mm radius'],[
('Ideal model, held-out p95 angular error','<b>0.87°</b>','1.57°'),
('Ideal model, directions within 5°','<b>100.00%</b>','99.56%'),
('Optical/calibration mismatch, p95 error','<b>3.04°</b>','4.43°'),
('Low light (20 lux) + mismatch, p95','<b>5.09°</b>','6.56°'),
('Only Arduino A operating, p95','<b>2.68°</b>','9.22°'),
('Second directional source at 10% strength, p95','<b>5.53°</b>','6.21°')],[230,100,181])
flow.append(Spacer(1,12))
para('<b>Decision:</b> retain the unmasked sensors as the implementation baseline; print a few mask prototypes as a controlled engineering experiment. Do not adopt a mask for all twelve sensors unless measured, independently held-out data establish a useful improvement without unacceptable coverage or failover losses.')

flow.append(PageBreak())
flow.append(P('A controlled search, not a promising-model selection','TitleX'))
img('mask_comparison.png',505)
flow.append(Spacer(1,8))
sec('What was searched')
para('Centered circular openings used aperture radii 2.4, 2.8, 3.2 and 3.6 mm with 0.6, 1.2, 1.8, 2.5 and 3.5 mm recess depths. Three asymmetric offset-opening designs were added. One design was selected based on the optimization sample, then compared with other candidates on 4,300 independent sphere directions. The best model from the search was the <b>bare opening</b>.')
sec('Optical reason')
para('An aperture attenuates oblique illumination. That can sharpen the response of a single detector within a restricted field, but a full-sphere, six-face system needs oblique light to maintain enough informative channels. A single LDR integrates spatial light into one scalar; unlike a quadrant photodiode or imaging-array sensor, it cannot read a positional light-spot pattern behind a coded mask.')
img('mask_optical_principle.png',430)
flow.append(P('Simplified top-opening / 4 mm active-disk overlap. Real packaged LDRs and FDM printing may differ.','SmallX'))

flow.append(PageBreak())
flow.append(P('Stress tests and limitations','TitleX'))
img('controller_failover.png',490)
sec('Meaning of the numerical error values')
para('The modeled LDR uses an assumed direct-light angular response proportional to max(0,cos θ)^1.15, conservative face self-shadowing, a uniformly sensitive circular active area, and circular-aperture geometric overlap. The electronic model assumes a 25 kOhm LDR at 10 lux, gamma 0.6, a 30 kOhm fixed resistor and a 10-bit ADC. Simulated readout noise, background and per-channel variations were introduced. This is not a measured noise model or an empirically fitted GL5537-1 optical model.')
para('For inference we used a normalized light-pattern lookup table over 70,000 directions, so overall source brightness is an unknown amplitude. That differs from the earlier three-dimensional full-rank least-squares estimator. Consequently, its error and coverage statistics must not be directly compared with the previous simulation study.')
sec('Important unmodeled failure modes')
para('Printed surface reflections, cap misalignment, LDR epoxy scattering, color/spectral dependence, sensor ageing, beam-size/parallax effects, nonuniform ambient light, thermal drift, strong outdoor sunlight and supply/power-system faults. The model explores only a few generic perturbations; it is not a Monte Carlo qualification of the real parts.')
sec('A second light source does not rescue the masks')
tab(['Additional directional source','Bare p95','Shallow mask p95'],[
('10% of primary beam','5.53°','6.21°'),
('30% of primary beam','20.85°','23.61°'),
('60% of primary beam','50.75°','51.41°')],[241,130,140])
para('The hybrid six-bare/six-masked case marginally improved one mismatch run (4.04° to 3.96° p95), while making the masked controller much weaker after failover. That is neither a robust nor a credible benefit without hardware measurements.')
flow.append(PageBreak())
flow.append(P('Electronics and physical error budget','TitleX'))
sec('Electrical dynamic range could be the larger problem')
img('divider_dynamic_range.png',475)
para('The manufacturer specifies R at 10 lux and the gamma relation over 10 to 100 lux; values plotted far outside this range are illustrative extrapolations. For the nominal 30 kOhm divider the predicted ADC level becomes very small under intense sunlight, so select the laboratory illumination range before fixing the analog design.')
sec('Proposed single-channel circuit')
para('<b>5V -> 30 kOhm fixed resistor -> Arduino ADC A0-A5 -> GL5537-1 LDR -> GND.</b> One such divider per LDR; six inputs per Arduino. The ADC reference follows the 5V supply, making the divider ratiometric. Measure actual resistor values and ADC reference behaviour; a source impedance approaching 30 kOhm warrants ADC settling tests. The supplied fixed resistors may differ from the proposed nominal 30 kOhm.')
sec('What is required before claiming accuracy')
para('The simulated sensor assumes a uniform 4 mm photosensitive disk, whereas the physical component is a nominal 5 mm package with unknown effective geometry. A small lamp 2 m away creates about 1.43° of geometric parallax across 5 cm of sensor position offset. Choose a controlled source, measured mechanics and real LDR calibration before comparing 1-2° estimator differences.')
para('The Arduino firmware and Python host monitor included in the package are working design starters. Hardware compilation, power-rail isolation, true sensor-fault isolation and the final estimator have not yet been validated.')

flow.append(PageBreak())
flow.append(P('Print, calibrate, decide','TitleX'))
sec('What has already been generated')
para('STL and OpenSCAD models: bare reference collar, two shallow circular caps, a deliberately deep cap, a lateral-offset cap, and an 8.1615-degree angled socket. All STL files were programmatically confirmed as watertight manifold solids. Fit, optical opacity and print quality have not been verified on real hardware.')
sec('Minimum practical experimental sequence')
tab(['Stage','Physical measurement','Decision enabled'],[
('1. Electronics','Check resistor/ADC transfer and dark noise on 3 real LDRs at multiple lamp intensities.','Choose range and fixed resistor; avoid clipping.'),
('2. Angular response','Measure bare LDR signal at 0° to 80° and several lamp levels, including azimuth variation.','Replace assumed cosine exponent with empirical response.'),
('3. Mask A/B','On the same physical sensor, compare bare vs shallow vs deep cap with controlled mechanical seating and identical light.','Does any mask improve usable response without excessive vignetting?'),
('4. System calibration','Calibrate 12 channels; build the six-face assembly; verify sensor axes.','Calibrated Sun-vector reconstruction.'),
('5. Held-out trials','Random independent Sun directions, controller failover, sensor disconnection, intensity and interference changes.','Full-sphere angular error distributions and fault tolerance.'),
('6. Decision gate','Bootstrap paired p95 error differences by matching identical physical test poses.','Adopt only if improvement is real and worthwhile.')],[77,267,167])
sec('Suggested pass/fail rule for adopting masks')
para('At least a 20% reduction in held-out p95 angular error relative to bare, no more than a 2 percentage-point loss in directions with ≤5° error, and no material degradation under one-controller operation or low-light conditions. Treat these as proposed engineering criteria, not existing AE4901 requirements.')
sec('Critical geometry note')
para('At 2 m source distance a 5 cm offset from the reference center creates approximately arctan(0.05/2) = 1.43 degrees of angular parallax, even for an ideal point source. Use a sufficiently distant/narrow source, a calibrated positional model, or a collimating optical setup; otherwise this can dominate simulated sub-degree error figures.')
sec('Research references')
flow.append(P('Senba GL5537-1: nysenba.com/cds/5mm.html; HERMES 2023: pmc.ncbi.nlm.nih.gov/articles/PMC10007507/; UPMSat-2: pmc.ncbi.nlm.nih.gov/articles/PMC8309943/; NASA Small Spacecraft GNC: nasa.gov/smallsat-institute/sst-soa/guidance-navigation-and-control/; AE4901 Manual, 11 November 2026, Assignment 3.','SmallX'))
flow.append(P('Companion files: Python simulation, complete CSV outputs and diagrams, printed CAD models, six-channel-per-board Arduino sketch, monitoring demo, calibration templates and scripts.','SmallX'))

doc.build(flow,onFirstPage=draw_page,onLaterPages=draw_page)
print(str(OUT))
