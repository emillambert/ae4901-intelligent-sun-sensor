#!/usr/bin/env python3
"""Fast independent invariants; full numeric simulation run is in optics_study.py."""
import sys,glob
from pathlib import Path
import numpy as np
import trimesh,pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import optics_study as o

assert np.allclose(np.linalg.norm(o.NOM_N,axis=1),1)
assert np.allclose(o.NOM_N.T@o.NOM_N,4*np.eye(3))
for f in range(6):
 assert o.NOM_N[2*f]@o.FACES[f]>.98
 assert o.NOM_N[2*f+1]@o.FACES[f]>.98
s=o.sphere(1000,.031)
for c in o.shortlist():
 y=o.response(s,c)
 assert np.all(np.isfinite(y)) and np.all(y>=0) and np.all(y<=1.001)
# Apertures cannot increase a direct optical signal (under no-scattering ideal model)
base=o.response(s,o.shortlist()[0])
for c in o.shortlist()[1:]:assert np.all(o.response(s,c)<=base+1e-10)
r10=np.full(12,25000.);gamma=np.full(12,.6)
e=np.exp(np.linspace(np.log(.25),np.log(250),12))[None,:]
assert np.allclose(o.adc_to_flux(o.flux_to_adc(e,r10,gamma),r10,gamma),e,rtol=1e-10)
for path in glob.glob(str(Path(__file__).resolve().parents[1]/'cad/*.stl')):
 mesh=trimesh.load(path,force='mesh')
 assert mesh.is_watertight and mesh.is_volume,(path,'bad STL')
results=pd.read_csv(Path(__file__).resolve().parents[1]/'results/independent_holdout_results.csv')
s=results[(results.scenario=='ideal') & (results.board=='Both') & (results.brightness_lux==80)]
bare=float(s[s.name=='BARE'].p95_deg.iloc[0]);assert bare < s[s.name!='BARE'].p95_deg.min()
print('PASS: geometry, aperture transmission, electronics, 6 STL meshes, recorded best-bare result')
