#!/usr/bin/env python3
import sys
from pathlib import Path
import numpy as np,pandas as pd
sys.path.insert(0,str(Path(__file__).parent))
import optics_study as o
O=Path(__file__).parent/'results'
S=o.sphere(4300,.834)
base=o.shortlist()[0]
cands=[base]
for name,h,a,offset in [('Hybrid shallow',.6,3.6,0),('Hybrid medium',1.2,3.2,0),('Hybrid offset',1.8,3.2,.6),('Hybrid deep',2.5,2.8,0)]:
 cands.append({'name':name,'kind':'offset' if offset else 'round','h':h,'aperture_radius':a,'offset':offset,'detector_radius':2.0,'board_mask':1})
rows=[]
for spec in cands:
 for scenario in ['ideal','mismatch']:
  for board in [None,0,1]:
   m=o.run_design(spec,S,scenario,sky_n=70000,seed=1743,brightness=80,board=board)
   rows.append({'name':spec['name'],'scenario':scenario,'board':('Both' if board is None else 'A only' if board==0 else 'B only'),**m})
   print(spec['name'],scenario,board,m['p95_deg'],m['within_5_pct'],flush=True)
pd.DataFrame(rows).to_csv(O/'hybrid_bare_mask_results.csv',index=False)
