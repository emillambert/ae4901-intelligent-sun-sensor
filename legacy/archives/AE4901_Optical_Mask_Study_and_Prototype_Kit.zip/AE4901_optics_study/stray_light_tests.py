#!/usr/bin/env python3
"""Independent two-source stray-light sensitivity test for shortlisted masks.
Assumes secondary directional light source of known ratio and random direction;
reconstruction assumes just one source. The secondary source is NOT measured.
"""
import json,sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0,str(Path(__file__).parent))
import optics_study as o
O=Path(__file__).parent/'results'
specs=json.loads((O/'selected_masks.json').read_text())
S=o.sphere(4300,.634)
# Deterministic secondary direction, independent of Sun direction.
T=o.sphere(4300,.919)[::-1]
rows=[]
for spec in specs:
  tree=o.lookup_tree(spec,70000)
  src=o.response(S,spec)
  other=o.response(T,spec)
  for ratio in [0.,.10,.30,.60]:
    rng=np.random.default_rng(717)
    # normalized irradiance with secondary source; independent 1%-of-direct additive noise
    observed=np.maximum(0,src+ratio*other+rng.normal(0,.009,src.shape))
    est,_=o.predict(tree,observed)
    m=o.metric(est,S)
    rows.append({'name':spec['name'],'secondary_to_primary_ratio':ratio,**m})
    print(spec['name'],ratio,m['p95_deg'],m['within_5_pct'],flush=True)
pd.DataFrame(rows).to_csv(O/'directional_stray_light.csv',index=False)
