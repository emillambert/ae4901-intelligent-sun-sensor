#!/usr/bin/env python3
"""Fit per-LDR R10/gamma and angular cosine exponent from ACTUAL measurements.
Do not fabricate data: provide CSV with columns below, e.g.:
 sensor_id,mask_id,source_lux,ambient_lux,angle_deg,azimuth_deg,adc,trial
LDR-to-GND, 30k-to-5V assumed. source_lux = normal-incidence meter reading.
At least three distinct light levels at theta=0 are needed for R10/gamma fit.
"""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import linregress

def main():
    p=argparse.ArgumentParser();p.add_argument('measurements');p.add_argument('--out',default='fitted_sensor_parameters.json');p.add_argument('--rfixed',type=float,default=30000)
    args=p.parse_args();df=pd.read_csv(args.measurements)
    needed=['sensor_id','mask_id','source_lux','ambient_lux','angle_deg','azimuth_deg','adc','trial']
    missing=[x for x in needed if x not in df.columns]
    if missing:raise ValueError('Missing columns: '+', '.join(missing))
    if df.empty:raise ValueError('No real data yet. Fill calibration CSV after physical measurements.')
    out={}
    for (id,mask),g in df.groupby(['sensor_id','mask_id']):
        g=g.copy();g['E_norm']=g['source_lux']+g['ambient_lux']
        g=g[(g.adc>2)&(g.adc<1021)&(g.E_norm>0)]
        if len(g)<8:continue
        adc=g.adc.to_numpy();R=args.rfixed*adc/(1023-adc)
        g['R_ohm']=R
        a=g[(g.angle_deg.abs()<1.0)&(g.source_lux>0)]
        if a['source_lux'].nunique()<3:continue
        x=np.log((a.source_lux+a.ambient_lux).to_numpy()/10)
        y=np.log(a.R_ohm.to_numpy())
        fit=linregress(x,y)
        gamma=-float(fit.slope);r10=float(np.exp(fit.intercept))
        # Illumination inferred from calibrated electrical response (includes ambient)
        measured_lux=10*np.exp(-np.log(g.R_ohm.to_numpy()/r10)/gamma)
        effective=np.maximum(.01,measured_lux-g.ambient_lux.to_numpy())
        norm=np.clip(np.cos(np.deg2rad(g.angle_deg.to_numpy())),.05,1)
        # Angular exponent fit assumes a bare sensor and near-axis response;
        # mask data requires a separate geometric aperture model, not cos^p alone.
        sel=(g.angle_deg>=5)&(g.angle_deg<=65)&(g.source_lux>0)
        p_angular=None
        if (mask=='BARE' or str(mask).lower()=='bare') and sum(sel)>=8:
            aa=np.log(norm[sel]);bb=np.log(effective[sel]/g.source_lux.to_numpy()[sel]);p_angular=float(np.dot(aa,bb)/np.dot(aa,aa))
        out[f'{id}:{mask}']={'r10_ohm':round(r10,2),'gamma':round(gamma,5),'angular_cos_exponent':round(p_angular,4) if p_angular else None,
                             'n_samples':len(g),'n_at_zero':len(a),'r10_gamma_fit_r2':round(float(fit.rvalue**2),4),
                             'warning':'cos exponent only meaningful for unmasked single-source responses; check fit residuals and azimuth dependence'}
    if not out:raise ValueError('Insufficient valid measurements for any sensor: need multiple normal-incidence lux levels and multiple repeats.')
    Path(args.out).write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
