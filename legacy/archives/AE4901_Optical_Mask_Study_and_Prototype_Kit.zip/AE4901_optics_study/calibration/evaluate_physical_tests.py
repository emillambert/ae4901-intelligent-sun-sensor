#!/usr/bin/env python3
"""Evaluate MEASURED angular errors from a paired validation campaign.
Input columns: condition,case_id,mask_id,true_x,true_y,true_z,pred_x,pred_y,pred_z,controller_mode
Fields must be actual physical test results; does not generate fictitious measurements.
For paired improvement analysis case_id and condition/controller_mode must match.
"""
import argparse
from pathlib import Path
import numpy as np,pandas as pd

def main():
 p=argparse.ArgumentParser();p.add_argument('test_data');p.add_argument('--out',default='measured_performance.csv');args=p.parse_args()
 df=pd.read_csv(args.test_data)
 cols=['condition','case_id','mask_id','true_x','true_y','true_z','pred_x','pred_y','pred_z','controller_mode']
 if df.empty:raise ValueError('No physical validation data recorded.')
 if not set(cols)<=set(df):raise ValueError(f'Missing required columns: {set(cols)-set(df)}')
 truth=df[['true_x','true_y','true_z']].to_numpy(float)
 pred=df[['pred_x','pred_y','pred_z']].to_numpy(float)
 truth/=np.maximum(np.linalg.norm(truth,axis=1,keepdims=True),1e-10)
 pred/=np.maximum(np.linalg.norm(pred,axis=1,keepdims=True),1e-10)
 df['error_deg']=np.rad2deg(np.arccos(np.clip(np.sum(truth*pred,axis=1),-1,1)))
 rows=[]
 for (mask,cond,board),g in df.groupby(['mask_id','condition','controller_mode']):
  e=g.error_deg.to_numpy()
  rows.append(dict(mask=mask,condition=cond,controller_mode=board,n=len(e),median_deg=np.median(e),p95_deg=np.quantile(e,.95),p99_deg=np.quantile(e,.99),within_5_pct=100*np.mean(e<=5)))
 results=pd.DataFrame(rows);results.to_csv(args.out,index=False)
 print(results.to_string(index=False))
 # Paired bootstrap of p95 mask-vs-BARE difference, by exact same case IDs.
 for name in sorted(set(df.mask_id)-{'BARE'}):
  base=df[df.mask_id=='BARE'].set_index(['condition','case_id','controller_mode']).error_deg
  alt=df[df.mask_id==name].set_index(['condition','case_id','controller_mode']).error_deg
  both=pd.concat([base.rename('bare'),alt.rename('alt')],axis=1).dropna()
  if len(both)<100:print(f'{name}: insufficient paired cases ({len(both)}); need >=100');continue
  rng=np.random.default_rng(4901);arr=both[['bare','alt']].to_numpy()
  diff=[]
  for _ in range(1000):
   v=arr[rng.integers(0,len(arr),len(arr))]
   diff.append(np.quantile(v[:,1],.95)-np.quantile(v[:,0],.95))
  print(f'{name}: paired p95 difference (mask-minus-bare)={np.quantile(arr[:,1],.95)-np.quantile(arr[:,0],.95):.3f} deg; 95% bootstrap interval={np.quantile(diff,[.025,.975])}')
if __name__=='__main__':main()
